#include <iostream>

/* TODO:
 *
 * Test on syccuxas01
 * Submit project
 *
*/

//    bool debug = true;
    bool debug = false;

//using namespace std; // Temp

bool ifOnlyIf(bool p, bool q)
{
    // Evaluates inputs (q if and only if p) and returns result, do not edit this function!

    if ((p == 1 && q == 1) || (p == 0 && q == 0))
        return true;
    else
        return false;
}

bool ifThen(bool p, bool q)
{
    // Evaluates inputs (if p then q) and returns result, do not edit this function!
    
    if ((p == 1 && q == 1) || (p == 0 && q == 1) || (p == 0 && q == 0))
        return true;
    else
        return false;
}

bool conclusion (bool p, bool q, bool r)
{
    // Evaluates conclusion of argument entered below if if statement, edit this function.
    
//    if ( ENTER CONCLUSION HERE ) // <-- Edit this to change conclusion 
    if (p || r) // Conclusion: (P v R), comment out after adding conclusion above
        return true;
    else
        return false;
}

bool premise (bool p, bool q, bool r)
{
    // Evaluates premise of argument entered below in return statement, edit this function.
    
//    std::cout << "\nP = " << p << std::endl;
//    std::cout << "Q = " << q << std::endl;
//    std::cout << "R = " << r << std::endl;
//    std::cout << "P v Q = " << (p | q) << std::endl;
//    std::cout << "P ^ R = " << (p & r) << std::endl;
//    std::cout << "R ^ Q = " << (r & q) << std::endl;
//    std::cout << "Q -> R = " << (ifThen(q,r)) << std::endl;
//    std::cout << "P <-> Q = " << (ifOnlyIf(p,q)) << std::endl;
//    std::cout << "(P v Q) ^ (Q -> R) = " << ((p | q) & (ifThen(q,r))) << std::endl;
//    std::cout << "((P v Q) ^ (Q -> R)) XOR (P ^ R) = " << (((p | q) & (ifThen(q,r))) ^ (p & r)) << std::endl;
//    std::cout << "(((P v Q) ^ (Q -> R)) XOR (P ^ R)) <-> (R ^ Q) = " << ifOnlyIf((((p | q) & (ifThen(q,r))) ^ (p & r)),(r & q)) << std::endl;

//    return ( ENTER PREMISE HERE ); // <-- Edit this to change premise

    return (ifOnlyIf((((p | q) & (ifThen(q,r))) ^ (p & r)),(r & q))); // Premise: (((P v Q) ^ (Q -> R)) XOR (P ^ R)) <-> (R ^ Q), comment out after adding conclusion above

}

int main () // Do not edit anything in main
{
    bool p [8] = {1,1,1,1,0,0,0,0};
    bool q [8] = {1,1,0,0,1,1,0,0};
    bool r [8] = {1,0,1,0,1,0,1,0};
    bool prem [8] = {0};
    bool concl [8] = {0};
    bool argInvalid = 0;

    std::cout << "Welcome to lab 2!\n " << std::endl;
    
    if (debug == true)
    {
        std::cout << "\np = " << p << std::endl;
        std::cout << "q = " << q << std::endl;
        std::cout << "r = " << r << std::endl;
        std::cout << "prem = " << prem << std::endl;
        std::cout << "concl = " << concl << std::endl;
    }

    for (int i = 0; i < 8; i++)
    {
        prem[i] = premise(p[i],q[i],r[i]);
        concl[i] = conclusion(p[i],q[i],r[i]);
        
        if (prem[i] == 1 && concl[i] == 0)
        {
            std::cout << "The argument is invalid in row " << i << std::endl;
            argInvalid = 1;
        }
    }

    if (argInvalid == 0)
        std::cout << "\nThe argument is valid. " << std::endl;

    std::cout << "Row";
    std::cout << "\tP";
    std::cout << "\tQ";
    std::cout << "\tR";
    std::cout << "\tPrem";
    std::cout << "\tConcl" << std::endl;

    for (int i = 0; i < 8; i++)
    {
        std::cout << i;
        std::cout << "\t" << p[i];
        std::cout << "\t" << q[i];
        std::cout << "\t" << r[i];
        std::cout << "\t" << prem[i];
        std::cout << "\t" << concl[i] << std::endl;
    }

    std::cout << "\n";
    
    return 0;
}
