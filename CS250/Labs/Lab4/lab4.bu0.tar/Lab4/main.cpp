/*
 *
 * NAME:        Jaime Landers
 * CRN:         43753 
 * ASSIGNMENT:  Lab 4
 * SOURCES:     None
 *
*/

#include <iostream>
#include <vector>

int main ()
{
    bool isPrime = true;
    int n = 0;
    int userNum = 45;
    std::vector<int> primeFactors;
    std::vector<int>::iterator it;// = 0;

    std::cout << "Welcome to lab 4!\n " << std::endl;

    // Ask for user input    
    
    std::cout << "userNum = " << userNum << std::endl;

    n = userNum;

//    it = primeFactors.begin();

    std::cout << "n = " << n  << std::endl;

    for (int i = 2; i <= n; i++)
    {
        if (n % i == 0)
        {
            std::cout << "i = " << i << std::endl;
            n = n / i;
//            std::cout << "n = " << n << std::endl;
            primeFactors.push_back(i);
//            primeFactors.insert(it, n);
            isPrime = false;
//            it++;
            i--;
        }

    }

    if (isPrime == true)
        std::cout << "\n" << userNum << " is prime. " << std::endl;
    else
    {
        std::cout << "\n" << userNum << " is not prime. " << std::endl;
        std::cout << "factors: " << std::endl;
        for (it = primeFactors.begin(); it < primeFactors.end(); it++)
            std::cout << primeFactors[*it] << std::endl;
    }

    return 0;
}
