/*
 *
 * NAME:        Jaime Landers
 * CRN:         43753 
 * ASSIGNMENT:  Lab 5
 * SOURCES:     None
 *
*/

#include <iostream>
#include <limits>

void div (long long x, long long y, long long * q, long long * r)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\ndiv " << std::endl;
        std::cout << "x = " << x << std::endl;
        std::cout << "y = " << y << std::endl;
    }

    long long quotient = 0;
    long long remainder = x;

    while (remainder >= y)
    {
        remainder = remainder - y;
        quotient = quotient + 1;

        if (debug == true)
        {
            std::cout << "quotient = " << quotient << std::endl;
            std::cout << "remainder = " << remainder << std::endl;
        }
    }

    *q = quotient;
    *r = remainder;

    if (debug == true)
    {
        std::cout << "q = " << *q << std::endl;
        std::cout << "r = " << *r << std::endl;
    }

    return;
}

int gcd (long long x, long long y, long long * q, long long * r)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "\ngcd " << std::endl;
        std::cout << "x = " << x << std::endl;
        std::cout << "y = " << y << std::endl;
    }

    long long a = x;
    long long b = y;
    long long result = 0;

    *q = 0;
    r = &y;

    while (b != 0)
    {
        div(a,b,q,r);
        a = b;
        b = *r;

        if (debug == true)
        {
            std::cout << "a = " << a << std::endl;
            std::cout << "b = " << b << std::endl;
            std::cout << "r = " << *r << std::endl;
        }
    }

    result = a;

    if (debug == true)
    {
        std::cout << "result = " << result << std::endl;
    }

    return result;
}

int main ()
{
    bool debug = false;
//    bool debug = true;

    long long cd = 0;
    long long quotient = 0;
    long long remainder = 0;
    long long * q  = new long long;
    long long * r  = new long long;
    long long x = 0;
    long long y = 0;

    std::cout << "\nWelcome to lab 5! \n" << std::endl;

    for (int i = 0; i < 4; i++)
    {

        while (x <= 1)
        {
            std::cout << "Enter a number (x) between 1 and 2^63 (exclusive): ";
            std::cin >> x;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');

            if (debug == true)
                std::cout << "x = " << x << std::endl;
        }
        while (y < 1 || y > x)
        {
            std::cout << "Enter a number (y) between 1 and " << x << " (inclusive): ";
            std::cin >> y;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');

            if (debug == true)
                std::cout << "y = " << y << std::endl;
        }

        if (debug == true)
        {
            std::cout << "x = " << x << std::endl;
            std::cout << "y = " << y << std::endl;
        }

        div(x, y, q, r);
        quotient = *q;
        remainder = *r;
        cd = gcd(x, y, q, r);

        std::cout << "The quotient and remainder of " << x << " and " << y << " is ";
        std::cout << quotient << " and " << remainder << std::endl;
        std::cout << "The gcd of " << x << " and " << y << " is " << cd << std::endl;
        std::cout << "\n";

        if (debug == true)
        {
            std::cout << "x/d = " << x/y << std::endl;
            std::cout << "x%d = " << x%y << std::endl;
        }

        x = 0;
        y = 0;

    }

    delete q;
    delete r;
//    delete s;
//    delete t;

    return 0;
}
