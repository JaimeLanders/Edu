/*
 *
 * NAME:        Jaime Landers
 * CRN:         43753 
 * ASSIGNMENT:  Lab 6
 * SOURCES:     None
 *
*/

#include <iostream>
#include <limits>
//#include <list>
#include <vector>

std::vector<int> numList;
std::vector<int>::iterator it;
//std::list<int> numList;
//std::list<int>::iterator it;

void div (long long x, long long y, long long * q, long long * r)
{
    long long quotient = 0;
    long long remainder = x;

    while (remainder >= y)
    {
        remainder = remainder - y;
        quotient = quotient + 1;
    }

    *q = quotient;
    *r = remainder;

    return;
}

void decToBi (int n, int m[])
//void decToBi (int n)
//std::vector<int> decToBi (int n)
{
    bool debug = false;
//    bool debug = true;

    if (debug == true)
    {
        std::cout << "decToBi " << std::endl;
        std::cout << "n = " << n << std::endl;
    }

    long long * q  = new long long;
    long long * r  = new long long;
//    std::vector<int> numList;
    long long i = 0;
    long long j = n;
//    int i = 0;
//    int j = n;

    while (i == 0 || j != 0)
    {
        if (debug == true)
        {
            std::cout << "i = " << i << std::endl;
            std::cout << "j = " << j << std::endl;
        }

       div(j,2, q, r); 

        m[i] = *r;
        if (debug == true)
            std::cout << "m[" << i << "] = " << m[i] << std::endl;
//        numList.push_back(*r);
//        numList.push_front(*r);
        j = *q;
//        numList.push_front(j % 2);
//        j = j / 2;
        i = i + 1;
    }
    
    return;
//    return numList;

}

int main ()
{
//    long long x = 9223372036854775807;
    long long x = 0;
    
//    int bits [64] = new int [64];
    int bits [64] = {0};
//    int bits [64] = {'\0'};
    bool leadBit = false;

    std::cout << "\nWelcome to lab 6! \n" << std::endl;

//    for (int i = 0; i < 4; i++)
//    {

//        while (x <= 1 && x > 9223372036854775807)
        while (x <= 1)
        {
            std::cout << "Enter a number between 1 and 922,3372,0368,5477,5807 (inclusive): ";
            std::cin >> x;
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        }

        decToBi(x, bits);
//        decToBi(x);

        std::cout << x << " in binary is ";

        for (int i = 63; i >= 0; i--)
        {
//        for (int i = 0; i < 64; i++)
//            std::cout << numList[i];
            if (bits[i] == 1)
                leadBit = true;

            if (leadBit == true)
            {
//                std::cout << "i = " << std::endl;

                if ((i + 1) % 4 == 0)
                    std::cout << " ";

                std::cout << bits[i];
            }
        }
        std::cout << "\n";

//        for (it = numList.end(); it != numList.begin(); it--)
//        for (it = numList.begin(); it != numList.end(); it++)
//            std::cout << *it; 

//    } // for loop

    return 0;
}
