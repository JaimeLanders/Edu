/*
 *
 * NAME:        Jaime Landers
 * CRN:         43753 
 * ASSIGNMENT:  Lab 3
 * SOURCES:     None
 *
 * TODO:
 * Test on syccuxas01
 * Submit to dropbox
*/

#include <iostream>
//#include <stdio.h>
//#include <fstream>
#include <string.h>
//#include <string>

int STRINGSIZE = 9;

int * halfSum = new int;
int * halfCarry = new int;
int * carryOut = new int;
int * sumOut = new int;

void halfAdder (int p, int q)// Half adder
{
//    std::cout << "\np = " << p << std::endl;
//    std::cout << "q = " << q << std::endl;
    *halfSum = (p ^ q);
    *halfCarry = (p & q);
}

void fullAdder (int p, int q, int r)// Full adder
{
    int carry1;
    int carry2;
    int sum1;
    int sum2;

    halfAdder(p, q);
    sum1 = *halfSum;
    carry1 = *halfCarry; 

//    std::cout << "sum1 = " << sum1 << std::endl;
//    std::cout << "carry1 = " << carry1 << std::endl;

    halfAdder(sum1, r);
    sum2 = *halfSum;
    carry2 = *halfCarry;

//    std::cout << "sum2 = " << sum2 << std::endl;
//    std::cout << "carry2 = " << carry2 << std::endl;

    *carryOut = (carry1 | carry2); 
    *sumOut = sum2; 

    std::cout << "The bits are " << p << " and " << q << ".";
    std::cout << "  The carry in is " << r << ".";
    std::cout << "  The sum is " << *sumOut << ".";
    std::cout << "  The carry out is " << *carryOut << std::endl; 

}

int main ()
{
    char a [STRINGSIZE] = {'0','0','0','0','0','0','0','0','\0',};
    char b [STRINGSIZE] = {'0','0','0','0','0','0','0','0','\0',};
    char sum [STRINGSIZE] = {'0','0','0','0','0','0','0','0','\0',};
//    char a [STRINGSIZE] = {'\0'};
//    char b [STRINGSIZE] = {'\0'};
    char userIn[30];
//    char sum [STRINGSIZE] = {'\0'};
    int c = 0b1;

    std::cout << "Welcome to lab 3!\n " << std::endl;

//    for (int l = 0; l < 4; l++)
//    {

        *halfSum = 0;
        *halfCarry = 0;
        *sumOut = 0;
        *carryOut = 0;

        bool valid  = 0;

        while(valid == 0) 
        {
            std::cout << "Enter binary number 1: ";
            std::cin.getline(userIn,30,'\n');
//            std::cout << "userIn size = " << strlen(userIn) << std::endl;
//            std::cout << "userIn = " << atoi(userIn) << std::endl;

            if (strlen(userIn) < STRINGSIZE)
            {
                for(int i = 0; i < strlen(userIn); i++)
                {
//                    std::cout << "userIn[" << i << "] = " << userIn[i] << std::endl;
                    if ((userIn[i] - '0' == 0) || (userIn[i] - '0' == 1))
                    {
//                        std::cout << "valid " << std::endl;
                        a[7-i] = userIn[i];
                        valid = 1;
                    }
                    else
                    {
                        valid = 0;
                        break;
                    }
                }
           }

           if (valid == 0)
               std::cout << "Please enter a valid 8 bit binary number " << std::endl;
//           else
//               std::cout << "valid " << std::endl;
        }

        valid = 0;

        while(valid == 0) 
        {
            std::cout << "Enter binary number 2: ";
            std::cin.getline(userIn,30,'\n');
//            std::cout << "userIn size = " << strlen(userIn) << std::endl;
//            std::cout << "userIn = " << atoi(userIn) << std::endl;

            if (strlen(userIn) < STRINGSIZE)
            {
                for(int i = 0; i < strlen(userIn); i++)
                {
//                    std::cout << "userIn[" << i << "] = " << userIn[i] << std::endl;
                    if ((userIn[i] - '0' == 0) || (userIn[i] - '0' == 1))
                    {
//                        std::cout << "valid " << std::endl;
                        b[7-i] = userIn[i];
                        valid = 1;
                    }
                    else
                    {
                        valid = 0;
                        break;
                    }
                }
           }
           if (valid == 0)
               std::cout << "Please enter a valid 8 bit binary number " << std::endl;
//           else
//               std::cout << "valid " << std::endl;
        }      
        
/*        for(int i = STRINGSIZE - 2; i >= 0; i--)
        {
            std::cout << "a[" << i << "] = " << a[i] << std::endl;
            if (a[i] == '\0')
//            if (a[i] != 1 || a[i] != 0)
                a[i] == 0;
//            if (b[i] != 1 || b[i] != 0)
//                b[i] == 0;
        }
*/
        std::cout << "\nThe numbers to be added are " << a << " and " << b << std::endl;
        
        for (int i = STRINGSIZE - 2; i >= 0; i--)
        {
            fullAdder(a[i]-'0',b[i]-'0',*carryOut);
            sum[i] = *sumOut + '0';
        }

        std::cout << "The answer is " << sum << "\n" << std::endl; 
//    }

    return 0;
}
