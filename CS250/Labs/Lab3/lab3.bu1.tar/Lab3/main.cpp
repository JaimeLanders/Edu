/*
 *
 * NAME:        Jaime Landers
 * CRN:         43753 
 * ASSIGNMENT:  Lab 3
 * SOURCES:     None
 *
 * TODO:
 * Test on syccuxas01
 * Submit to dropbox
*/

#include <iostream>
//#include <stdio.h>
//#include <fstream>
#include <string.h>
//#include <string>

int STRINGSIZE = 9;

int * halfSum = new int;
int * halfCarry = new int;
int * carryOut = new int;
int * sumOut = new int;

void halfAdder (int p, int q)// Half adder
{
//    std::cout << "\np = " << p << std::endl;
//    std::cout << "q = " << q << std::endl;
    *halfSum = (p ^ q);
    *halfCarry = (p & q);
}

void fullAdder (int p, int q, int r)// Full adder
{
    int carry1;
    int carry2;
    int sum1;
    int sum2;

    halfAdder(p, q);
    sum1 = *halfSum;
    carry1 = *halfCarry; 

//    std::cout << "sum1 = " << sum1 << std::endl;
//    std::cout << "carry1 = " << carry1 << std::endl;

    halfAdder(sum1, r);
    sum2 = *halfSum;
    carry2 = *halfCarry;

//    std::cout << "sum2 = " << sum2 << std::endl;
//    std::cout << "carry2 = " << carry2 << std::endl;

    *carryOut = (carry1 | carry2); 
    *sumOut = sum2; 

    std::cout << "The bits are " << p << " and " << q << ".";
    std::cout << "  The carry in is " << r << ".";
    std::cout << "  The sum is " << *sumOut << ".";
    std::cout << "  The carry out is " << *carryOut << std::endl; 

}

int main ()
{
    char a [STRINGSIZE] = {'\0'};
    char b [STRINGSIZE] = {'\0'};
    char userIn[30];
    char sum [STRINGSIZE] = {'\0'};
    int c = 0b1;

    std::cout << "Welcome to lab 3!\n " << std::endl;

//    for (int l = 0; l < 4; l++)
//    {

        *halfSum = 0;
        *halfCarry = 0;
        *sumOut = 0;
        *carryOut = 0;

        bool error = 1;

        while(error == 1) 
        {
            std::cout << "Enter binary number 1: ";
            std::cin.getline(userIn,30,'\n');
//            std::cin.getline(a,STRINGSIZE,'\n');
//            a[STRINGSIZE] = '\0';
            std::cout << "userIn size = " << strlen(userIn) << std::endl;
            std::cout << "userIn = " << atoi(userIn) << std::endl;
//            std::cout << "a size = " << strlen(a) << std::endl;

            if (strlen(userIn) < STRINGSIZE)
            {
                for(int i = 0; i < strlen(userIn); i++)
                {
//                  std::cout << "userIn[i] = " << userIn[i] << std::endl;
                    if ((userIn[i] - '0' < 0) || (userIn[i] - '0' > 1))
                        error = 1;
                    else
                        error = 0;

                }
            }

           if (error == 0)
//           if ((strlen(userIn) < STRINGSIZE) && (atoi(userIn) <= 255) && (atoi(userIn) >= 0))
//           if ((strlen(userIn) < STRINGSIZE) && (atoi(userIn) <= 0b11111111) && (atoi(userIn) >= 0b00000000))
//           if ((atoi(a) <= 0b11111111) || (atoi(a) >= 0b00000000))
           {
               std::cout << "valid " << std::endl;
//               std::cout << "a = " << atoi(a) << std::endl;
//           if (strlen(a) <= STRINGSIZE)
//                error = 0;
           }
           else
               std::cout << "Please enter a valid 8 bit binary number " << std::endl;
        }

/*        bool error = 1;

        std::cout << "Enter binary number 2: ";
        std::cin.getline(b,STRINGSIZE,'\n');
//        b[STRINGSIZE] = '\0';


        std::cout << "\nThe numbers to be added are " << a << " and " << b << std::endl;
        
        for (int i = STRINGSIZE - 2; i >= 0; i--)
        {
            fullAdder(a[i]-'0',b[i]-'0',*carryOut);
            sum[i] = *sumOut + '0';
        }

        std::cout << "The answer is " << sum << "\n" << std::endl; 
//    }
*/
    return 0;
}
