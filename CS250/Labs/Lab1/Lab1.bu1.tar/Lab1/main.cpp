#include <fstream>
#include <iostream>
#include <list>
#include <set>
#include <string>

/* TODO:
 *
 * Fix dataList insert
 * Fix extra data read
 * Write sorting algorithim (ASCII)
 * Cleanup code
 * Test on syccuxas01
 * Submit project
 *
*/

//using namespace std; // Temp

int main ()
{
    char fileName[30]; 
//    string fileName;
    bool debug = true;
//    bool debug = false;
    std::list<char *> dataList;
    std::list<char *>::iterator it;
//    std::set<char *> dataSet;

    std::cout << "Welcome to lab 1! " << std::endl;

    // Prompt user for file to open
    std::cout << "\nFile location to read: ";// << std::endl;
    std::cin >> fileName;// >> std::endl; 

    if (debug == true)
        std::cout << "fileName = " << fileName << std::endl;

    // Open file 
    bool fileOpen = false;

    std::ifstream inFile;
    inFile.open(fileName);

    if (inFile.is_open())
    {
        std::cout << "\n" << fileName << " opened " << std::endl;
        fileOpen = true;
    }
    else
    {
        std::cout << "\n" << "Could not open " << fileName << std::endl;
    }

    // Read data and add to list
//    char * tempString;
    char tempString[30];

    it = dataList.begin();

//    while (it.hasnext() != inFile.eof())
    while (!inFile.eof())
    {
        inFile >> tempString;

        if (debug == true);
            std::cout << "tempString = " << tempString << std::endl;

//        dataList.insert(it, &tempString);
        dataList.insert(it, tempString);
//        dataSet.insert(tempString);

        it++;
    }

    if (debug == true);
        std::cout << "dataList size = " << dataList.size() << std::endl;
//        std::cout << "dataSet size = " << dataSet.size() << std::endl;

    // Close file
    inFile.close();

    // Output list
    if (fileOpen == true)
    {
        std::cout << "\nWords in the file: " << std::endl;

        for(it = dataList.begin(); it != dataList.end(); it++)
//        for(int i = 0; i < dataList.size(); i++)
//        for(int i = 0; i < dataSet.size(); i++)
        {
//            if (debug == true);
//                std::cout << "i = " << i << std::endl;
            
            std::cout << *it << std::endl;
        }

        std::cout << "\n";
    }

    return 0;
}
