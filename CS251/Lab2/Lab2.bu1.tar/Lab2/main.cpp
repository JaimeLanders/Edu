/*
 * NAME:        Jaime Landers
 * CRN:         13759          
 * ASSIGNMENT:  Lab 2
 * SOURCES:     None
 *
 * TODO:
 *
*/

#include <iostream>
//#include <vector>

void div (long long x, long long y, long long * q, long long * r)
{
    long long quotient = 0;
    long long remainder = x;

    while (remainder >= y)
    {
        remainder = remainder - y;
        quotient = quotient + 1;
    }

    *q = quotient;
    *r = remainder;

    return;
}

void decToBi (long long n, int m[])
{
    long long * q  = new long long;
    long long * r  = new long long;
    long long i = 0;
    long long j = n;

    while (i == 0 || j != 0)
    {

       div(j,2, q, r); 

       m[i] = *r;
       j = *q;
       i = i + 1;
    }
    
    delete q;
    delete r;

    return;
} 

int residue (int x, int a, int n)
{
    std::cout << "\nresidue " << std::endl;

    std::cout << "a = " << a << std::endl;
    std::cout << "n = " << n << std::endl;
    std::cout << "x = " << x << std::endl;

    int residue = 0;
    int res[100];
    int rn = 0;
    int bits [64] = {0};
    bool leadBit = false;

    long long *q = new long long;
    long long *r = new long long;

    *r = x;
    std::cout << "r initial = " << *r << std::endl;

    // Convert exponent (a) to binary
    decToBi(a, bits);

    std::cout << a << " in binary is ";

    for (int i = 63; i >= 0; i--)
    {
        if (bits[i] == 1)
        {
            leadBit = true;
        }

        if (leadBit == true)
        {
            if ((i + 1) % 4 == 0)
                std::cout << " ";

            std::cout << bits[i];
        }
    }
    std::cout << "\n";
    leadBit = false;

    int a_i = 0;

    for (int i = 0; i < 63; i++)
//    for (int i = 63; i >= 0; i--)
    {
        a_i = 1;

        if (bits[i] == 1)
        {
            leadBit = true;
        }

        if (leadBit == true)
        {
//            if ((i + 1) % 4 == 0)
//                std::cout << " ";

//            std::cout << bits[i];
            if (bits[i] == 1)
            {
//                a_i = 1;
                for (int j = 0; j < i; j++)
                {
                    a_i *= 2;
                
                }
                std::cout << "\na_i = " << a_i << std::endl; 

                *r = x;
                std::cout << "r initial = " << *r << std::endl;

//                for (int j = 1; j <= (a_i / 2); j *= 2)
                for (int j = 1; j <= a_i; j *= 2)
                {
                    std::cout << "\nj = " << j << std::endl;

//                    if (a_i != 1)
//                        a_i /= 2;

                    if (j != 1)
//                    if(a_i % 2 == 0)
                        *r *= *r;
//                    x *= x;

                    div(*r, n, q, r);
//                    div(x, n, q, r);

//                    std::cout << "\nafter div: " << std::endl;
                    std::cout << "q = " << *q << std::endl;
                    std::cout << "r = " << *r << std::endl;

//                    std::cout << "\n";
                }
//                div(*r, n, q, r);
//                std::cout << "\nafter for: " << std::endl;
                std::cout << "r = " << *r << std::endl; 
                res[rn] = *r;
                rn++;

            }
        }
    }
    std::cout << "\n";

    // Final step, calculate final residue
    residue = 1;
    for (int i = 0; i < rn; i++)
    {
        std::cout << "res[" << i << "] = " << res[i] << std::endl;
        residue *= res[i];
    }
//    residue = *r;

    div(residue,n,q,r);
    residue = *r;
    std::cout << "residue = " << residue << std::endl; 
    leadBit = false;

    std::cout << "\n";
/*
//    div(x,n,q,r);

//    if (bits[0] == 0)
//    if (*r == 0)
//    {
//        std::cout << "a is a power of 2 " << std::endl;

//        *q = 0;
        *r = x;
//        *r = 0;
        a /= 2;

        for (int i = 0; i <= a; i += 2)
        {
            std::cout << "\ni = " << i << std::endl;

            *r *= *r;
//            x *= x;

            div(*r, n, q, r);
//            div(x, n, q, r);

            std::cout << "q = " << *q << std::endl;
            std::cout << "r = " << *r << std::endl;

            std::cout << "\n";
        }
*//*    }
    else
    {
        std::cout << "a is not a power of 2 " << std::endl;
    }
*/
//    residue = *r;

    delete q;
    delete r;

    return residue;
}

int main ()
{

    std::cout << "Welcome to Lab 2 " << std::endl;

//    for (int i = 0; i < 4; i++)
//    {

        int a = 1; 
        int n = 5;
        int x = 12;
/*
        int a = 43; 
        int n = 713;
        int x = 12;

        int a = 35; 
        int n = 11;
        int x = 17;

        int a = 13; 
        int n = 9;
        int x = 7;

        int a = 27; 
        int n = 55;
        int x = 17;
       
        int a = 11; 
        int n = 5;
        int x = 13;

        int a = 12;
        int n = 6;
        int x = 8;

        int a = 4;
        int n = 713;
        int x = 144;
*/
        // Get user input for x, a and n
/*        while (x <= 1)
        {
            std::cout << "Enter a positive integer (x): ";
            std::cin >> x;
            std::cin.clear();
//            std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        }
        while (a <= 1)
        {
            std::cout << "Enter a positive integer (a): ";
            std::cin >> a;
            std::cin.clear();
//            std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        }
        while (n <= 1)
        {
            std::cout << "Enter a positive integer (n): ";
            std::cin >> n;
            std::cin.clear();
//            std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        }
*/
        std::cout << "a = " << a << std::endl;
        std::cout << "n = " << n << std::endl;
        std::cout << "x = " << x << std::endl;
        std::cout << "x^a mod n -> " << x << "^" << a << " mod " << n << std::endl;

        std::cout << "residue = " << residue(x, a, n) << std::endl;

//    } // for loop 

    std::cout << "\n";

    return 0;
}
