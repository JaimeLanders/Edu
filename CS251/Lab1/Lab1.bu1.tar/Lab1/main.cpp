#include <iostream>
#include <vector>

int main ()
{
    std::string a;
    std::string b;
    int cardinality = 0;
    int setSize = 200;
    int stringSize = 0;
    std::vector<std::string> setA;
//    std::string setA[setSize] = {"\0"};
    std::vector<std::string> setB;
//     std::string setB[setSize] = {"A", "B", "C", "D", "E"};
//     std::string setB[setSize] = {"\0"};

    std::cout << "Welcome to Lab 1 " << std::endl;

    //Get set A and read into array A
    std::cout << "\nEnter set A: ";
    std::getline(std::cin, a);
    std::cin.clear();
    std::cout << "a = " << a << std::endl;
      stringSize = a.size();
    std::cout << "a size = " << stringSize << std::endl;

//    size_t end = 0;
    int end = 0;
    int i = 0;
    std::string::iterator it = a.begin();

//    std::cout << "a[0] = " << a.at(0) <<std::endl;
//    std::cout << "a[1] = " << a.at(1) <<std::endl;
    std::cout << "a.at(end) = " << a.at(end) <<std::endl;
    
    while ((it != a.end()) && (end >= 0) && (end < stringSize))
//    while ((it != a.end()) && (end >= 0))
//    while (it != a.end())// && i < setSize)
    {
//        size_t begin = end; 
        int begin = end; 
//        int elementSize = 0;
//        std::cout << "begin = " << begin << std::endl;
        end = a.find(" ", end);
//        std::cout << "end = " << end << std::endl;
        std::string element = a.substr(begin, end - begin);
//        std::cout << "element = " << element << std::endl;
        if (element != " ") // temp fix
            setA.push_back(element);
//        std::cout << "element size = " << elementSize << std::endl;
        i++;
        it++;
        if (end <= stringSize && end >= 0)
            end += element.size();
//        std::cout << "=====" << std::endl;
    }

    //Get set B and read into array B

    std::cout << "\nEnter set B: ";
    std::getline(std::cin, b);
    std::cin.clear();
    std::cout << "b = " << b << std::endl;
    stringSize = b.size();
    std::cout << "b size = " << stringSize << std::endl;

//    size_t end = 0;
    end = 0;
    i = 0;
    it = b.begin();

    std::cout << "b.at(end) = " << b.at(end) <<std::endl;
    
    while ((it != b.end()) && (end >= 0) && (end < stringSize))
    {
        int begin = end; 
//        int elementSize = 0;
//        std::cout << "begin = " << begin << std::endl;
        end = b.find(" ", end);
//        std::cout << "end = " << end << std::endl;
        std::string element = b.substr(begin, end - begin);
//        std::cout << "element = " << element << std::endl;
        if (element != " ") // temp fix
            setB.push_back(element);
//        std::cout << "element size = " << elementSize << std::endl;
        i++;
        it++;
        if (end <= stringSize && end >= 0)
            end += element.size();
//        std::cout << "=====" << std::endl;
    }

    std::cout << "\nSet A: {";
    for(std::vector<std::string>::iterator it = setA.begin(); it != setA.end() ; it++)
    {
        std::cout << *it;
        std::cout << ", ";
    }
    std::cout << "}\n";

    std::cout << "Set B: {";
    for(std::vector<std::string>::iterator it = setB.begin(); it != setB.end() ; it++)
    {
        std::cout << *it;
        std::cout << ", ";
    }
    std::cout << "}\n";

    //Print cardinality and roster of the intersection of sets A and B
    
    std::cout << "\nRoster of intesection of A and B: " << std::endl;
    std::cout << "{";
    for(std::vector<std::string>::iterator itA = setA.begin(); itA != setA.end(); itA++)
//    for(int i = 0; i < setSize; i++)
    {
//        std::cout << "\nitA = " << *itA << std::endl;
//        std::cout << "i = " << i << std::endl;

        for(std::vector<std::string>::iterator itB = setB.begin(); itB != setB.end(); itB++)
//        for(int j = 0; j < setSize; j++)
        {
//            std::cout << "\nitB = " << *itB << std::endl;
//        std::cout << "j = " << j << std::endl;

//        if(!setA[i].compare(setB[i]))
            if(*itA == *itB)
//            if(setA[i] == setB[j])
            {
                std::cout << *itA;
//                std::cout << setA[i];
                cardinality++;

                if((itA + 1 != setA.end()))
//                if((j + 1 < setSize) && (setA[i + 1] != "\0") && (setB[j + 1] != "\0"))
//                {
                    std::cout << ", ";
//                }
            }
        }
    }   
    std::cout << "}" << std::endl;

    std::cout << "The cardinality of the intersection of A and B is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the union of sets A and B
    
/*    std::cout << "\nRoster of union of A and B: " << std::endl;
    std::cout << "{";
    for(int i = 0; i < setSize; i++)
    {
//        if(!setA[i].compare(setB[i]))
        if(setA[i] != setB[i])
        {
            bool found = false;

            for(int j = 0; j < setSize; j++)
            {
                if (setA[i] == setB[j])
                {
                    found = true;
                }
            }

            if (found == false)
            {
                std::cout << setA[i];
                cardinality++;

//                if(setA[i + 1] != "/0")
//                {
                    std::cout << ", ";
//                }

            }

            std::cout << setB[i];
            cardinality++;

            if((i + 1 < setSize) && (setA[i + 1] != "\0") && (setB[i + 1] != "\0"))
            {
                std::cout << ", ";
            }
        }
        else
        {
            std::cout << setA[i];
            cardinality++;

            if((i + 1 < setSize) && (setA[i + 1] != "\0") && (setB[i + 1] != "\0"))
            {
                std::cout << ", ";
            }
        }
    }   
    std::cout << "}" << std::endl;

    std::cout << "The cardinality of the union of A and B is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the relative complement of sets A and B (A - B)
    
    std::cout << "\nRoster of relative complement of A and B (A - B): " << std::endl;
    std::cout << "{";
    for(int i = 0; i < setSize; i++)
    {
        bool found = false;

        for(int j = 0; j < setSize; j++)
        {
            if (setA[i] == setB[j])
            {
                found = true;
            }
        }

        if (found == false)
        {
            std::cout << setA[i];
            cardinality++;

            if((i + 1 < setSize) && (setA[i + 1] != "\0") && (setB[i + 1] != "\0"))
            {
                std::cout << ", ";
            }
        }
    }   
    std::cout << "}" << std::endl;   

    std::cout << "The cardinality of the complement of A and B is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the relative complement of sets B and A (B - A)
    
    std::cout << "\nRoster of relative complement of B and A (B - A): " << std::endl;
    std::cout << "{";
    for(int i = 0; i < setSize; i++)
    {
        bool found = false;

        for(int j = 0; j < setSize; j++)
        {
            if (setB[i] == setA[j])
            {
                found = true;
            }
        }

        if (found == false)
        {
            std::cout << setB[i];
            cardinality++;

            if((i + 1 < setSize) && (setB[i + 1] != "\0"))
            {
                std::cout << ", ";
            }
        }
    }   
    std::cout << "}" << std::endl;

    std::cout << "The cardinality of the complement of B and A is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the cross product of sets A and B (A - B)
    
    std::cout << "\nRoster of cross product of A and B: " << std::endl;
    std::cout << "{";
    for(int i = 0; i < setSize; i++)
    {
        std::cout << "(";
        std::cout << setA[i];
        std::cout << ", ";
        std::cout << setB[i];
        std::cout << ")";
        if((i + 1 < setSize) && (setB[i + 1] != "\0"))
        {
            std::cout << ", ";
        }
        cardinality++;
    }   
    std::cout << "}" << std::endl;

    std::cout << "The cardinality of the cross product of A and B is: " << cardinality << std::endl;
//    cardinality = 0;

    //Print cardinality power set of the cross product of sets A and B (A - B)
    
    int powerCard = 2;

    for(int i = 0; i < cardinality; i++)
    {
        powerCard = powerCard * 2;
                
    }

    std::cout << "\nThe cardinality of the power set of the cross product of A and B is: " << powerCard << std::endl;
    cardinality = 0;
*/
    std::cout << "\n"; // Temp

    return 0;
}
