#include <iostream>
#include <vector>

int main ()
{
    std::string a;
    std::string b;
    long long cardinality = 0;
//    int cardinality = 0;
    int setSize = 0;
    int stringSize = 0;
    std::vector<std::string> setA;
    std::vector<std::string> setB;

    std::cout << "Welcome to Lab 1 " << std::endl;

    //Get set A and read into array A
    
    std::cout << "\nEnter set A: ";
    std::getline(std::cin, a);
    std::cin.clear();
    std::cout << "a = " << a << std::endl;
      stringSize = a.size();
    std::cout << "a size = " << stringSize << std::endl;

    int end = 0;
    int i = 0;
    std::string::iterator it = a.begin();

    std::cout << "a.at(end) = " << a.at(end) <<std::endl;
    
    while ((it != a.end()) && (end >= 0) && (end < stringSize))
    {
        int begin = end; 
        int elementSize = 0;
//        std::cout << "begin = " << begin << std::endl;
        end = a.find(" ", end);
//        std::cout << "end = " << end << std::endl;
        std::string element = a.substr(begin, end - begin);
//        std::cout << "element = " << element << std::endl;
        if (element != " ") // temp fix
            setA.push_back(element);
        elementSize = element.size();
//        std::cout << "element size = " << elementSize << std::endl;
        i++;
        it++;
//        setSize++;
        if (end <= stringSize && end >= 0)
        {
            end += 1;
//            end += element.size();
        }
//        std::cout << "=====" << std::endl;
    }

    //Get set B and read into array B

    std::cout << "\nEnter set B: ";
    std::getline(std::cin, b);
    std::cin.clear();
    std::cout << "b = " << b << std::endl;
    stringSize = b.size();
    std::cout << "b size = " << stringSize << std::endl;

    end = 0;
    i = 0;
    it = b.begin();

    std::cout << "b.at(end) = " << b.at(end) <<std::endl;
    
    while ((it != b.end()) && (end >= 0) && (end < stringSize))
    {
        int begin = end; 
//        std::cout << "begin = " << begin << std::endl;
        end = b.find(" ", end);
//        std::cout << "end = " << end << std::endl;
        std::string element = b.substr(begin, end - begin);
//        std::cout << "element = " << element << std::endl;
        if (element != " ") // temp fix
            setB.push_back(element);
//        std::cout << "element size = " << elementSize << std::endl;
        i++;
        it++;
        if (end <= stringSize && end >= 0)
        {
            end += 1;
//            end += element.size();
        }
//        std::cout << "=====" << std::endl;
    }
    i = 0;

    std::cout << "\nSet A: {";
    for(std::vector<std::string>::iterator it = setA.begin(); it != setA.end() ; it++)
    {
        std::cout << *it;
        if(setA[i + 1] != "\0")
        {
            std::cout << ", ";
        }
        i++;
        cardinality++;
    }
    std::cout << "}\n";
    std::cout << "cardinality of Set A: " << cardinality << std::endl;
    i = 0;
    cardinality = 0;

    std::cout << "Set B: {";
    for(std::vector<std::string>::iterator it = setB.begin(); it != setB.end() ; it++)
    {
        std::cout << *it;
        if(setB[i + 1] != "\0")
        {
            std::cout << ", ";
        }
        i++;
        cardinality++;
    }
    std::cout << "}\n";
    std::cout << "cardinality of Set B: " << cardinality << std::endl;
    i = 0;
    cardinality = 0;

    // Set arraySize to be equal to cardinality of smallest set (if differenct cardinalities)
    
    if (setA.size() <= setB.size())
    {
        setSize = setA.size();
    }
    else
    {
        setSize = setB.size();
    }
    

    //Print cardinality and roster of the intersection of sets A and B
    
    std::cout << "\nRoster of intesection of A and B: " << std::endl;
    std::cout << "{";
    for(std::vector<std::string>::iterator itA = setA.begin(); itA != setA.end(); itA++)
    {
//        std::cout << "\nitA = " << *itA << std::endl;

        for(std::vector<std::string>::iterator itB = setB.begin(); itB != setB.end(); itB++)
        {
//            std::cout << "\nitB = " << *itB << std::endl;

            if(*itA == *itB)
            {
                std::cout << *itA;

                i++;
                cardinality++;

                if((i < setSize) && ((itA + 1 != setA.end()) || (itB + 1 != setB.end()))) // Extra comma when not last element (Set1)
//                if((j + 1 < setSize) && (setA[i + 1] != "\0") && (setB[j + 1] != "\0"))
               {
                    std::cout << ", ";
                }
            }
        }
    }   
    std::cout << "}" << std::endl;
    i = 0;

    std::cout << "The cardinality of the intersection of A and B is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the union of sets A and B
    
    std::cout << "\nRoster of union of A and B: " << std::endl;
    std::cout << "{";
//    for(std::vector<std::string>::iterator itA = setA.begin(); itA != setA.end(); itA++)
    for(int i = 0; i < setSize; i++)
    {

//        std::cout << "\ni = " << i << std::endl;

        bool found = false;

//        for(std::vector<std::string>::iterator itB = setB.begin(); itB != setB.end(); itB++)
//        {
//        if(*itA != *itB)
//        if(*itA != *itB)
        if(setA[i] != setB[i])
        {
//            bool found = false;

            for(int j = 0; j < setSize; j++)
            {
//                if (*itA == *itB)
//                if (setA[j] == setB[i])
                if (setA[i] == setB[j])
                {
                    found = true;
                    break; //temp
                }
            }
///        }

            if (found == false)
            {
//                std::cout << *itA;
                std::cout << setA[i];
//                std::cout << ", ";
//                std::cout << *itB;
                cardinality++;

                if((setA[i + 1] != "/0") || (setB[i + 1] != "/0"))
                {
                    std::cout << ", ";
                }
//
//                itB++; // temp
//                break; // temp

            }

            std::cout << setB[i];
            cardinality++;

            if((i + 1 < setSize) && ((setA[i + 1] != "\0") || (setB[i + 1] != "\0")))
            {
                std::cout << ", ";
            }
        }
        else
        {
            std::cout << setA[i];
            cardinality++;

            if((i + 1 < setSize) && ((setA[i + 1] != "\0") || (setB[i + 1] != "\0")))
            {
                std::cout << ", ";
            }
        }
//    }   
    }
    std::cout << "}" << std::endl;

    std::cout << "The cardinality of the union of A and B is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the relative complement of sets A and B (A - B)
    
    std::cout << "\nRoster of relative complement of A and B (A - B): " << std::endl;
    std::cout << "{";
    for(int i = 0; i < setSize; i++)
    {
        bool found = false;

        for(int j = 0; j < setSize; j++)
        {
            if (setA[i] == setB[j])
            {
                found = true;
            }
        }

        if (found == false)
        {
            std::cout << setA[i];
            cardinality++;

            if((i + 1 < setSize) && ((setA[i + 1] != "\0") || (setB[i + 1] != "\0")))
            {
                std::cout << ", ";
            }
        }
    }   
    std::cout << "}" << std::endl;   

    std::cout << "The cardinality of the complement of A and B is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the relative complement of sets B and A (B - A)
    
    std::cout << "\nRoster of relative complement of B and A (B - A): " << std::endl;
    std::cout << "{";
    for(int i = 0; i < setSize; i++)
    {
        bool found = false;

        for(int j = 0; j < setSize; j++)
        {
            if (setB[i] == setA[j])
            {
                found = true;
            }
        }

        if (found == false)
        {
            std::cout << setB[i];
            cardinality++;

            if((i + 1 < setSize) && ((setA[i + 1] != "\0") || (setB[i + 1] != "\0")))
            {
                std::cout << ", ";
            }
        }
    }   
    std::cout << "}" << std::endl;

    std::cout << "The cardinality of the complement of B and A is: " << cardinality << std::endl;
    cardinality = 0;

    //Print cardinality and roster of the cross product of sets A and B (A - B)
    
    std::cout << "\nRoster of cross product of A and B: " << std::endl;
    std::cout << "{";
    for(int i = 0; i < setSize; i++)
    {
        for(int j = 0; j < setSize; j++)
        {
        std::cout << "(";
        std::cout << setA[i];
        std::cout << ", ";
        std::cout << setB[j];
//        std::cout << setB[i];
        std::cout << ")";
        if(setB[j + 1] != "\0")
        {
            std::cout << ", ";
        }
        cardinality++;
        }
    }   
    std::cout << "}" << std::endl;

    std::cout << "The cardinality of the cross product of A and B is: " << cardinality << std::endl;
//    cardinality = 0;

    //Print cardinality power set of the cross product of sets A and B (A - B)
    
    int powerCard = 1;

    for(int i = 0; i < cardinality; i++)
    {
        powerCard = powerCard * 2;
                
    }

    std::cout << "\nThe cardinality of the power set of the cross product of A and B is: " << powerCard << std::endl;
    cardinality = 0;

    std::cout << "\n"; // Temp

    return 0;
}
