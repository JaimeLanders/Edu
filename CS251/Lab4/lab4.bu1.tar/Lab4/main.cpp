/*
 * NAME:        Jaime Landers
 * CRN:         13759          
 * ASSIGNMENT:  Lab 4
 * SOURCES:     None
 *
*/

#include <algorithm>
#include <iostream>
#include <set>
#include <vector>

int main ()
{
//    std::pair<int, int> edge;
    std::pair<int, std::pair<int, int>> p;
//    std::pair<int, std::pair<int, int>> p;
//    std::set<int> E;// = 0;
//    std::set<int>::iterator setIt;// = 0;
//    std::vector<int> E;// = 0;
//    int G [8][8] =
//    std::vector<std::vector <int>> G;
    std::vector<std::vector <int>> G =
        { 
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0}
        };
  /*  std::vector<std::vector <int>> G =
        { 
        {0,0,355,0,695,0,0,0},
        {0,0,74,0,0,348,0,0},
        {355,74,0,262,0,269,0,0},
        {0,0,262,0,0,242,0,0},
        {695,0,0,0,0,151,0,0},
        {0,348,269,242,151,0,83,306},
        {0,0,0,0,0,83,0,230},
        {0,0,0,0,0,306,230,0},
        };
 */   std::vector<std::vector <int>> T;
    std::vector<std::pair<int, std::pair<int, int>>> E;
//    std::vector<std::vector <int>> E;
    std::vector<std::pair<int, std::pair<int, int>>>::iterator setIt;// = 0;
//    std::vector<std::vector<int>>::iterator setIt;// = 0;
//    int T = 0;
//    int e = 0;
    int n = 12;
    int weight = 0;
    int maxSize = 12;
    std::string userIn;

    std::cout << "Welcome to Lab 4 " << std::endl;

/*    for (int i = 0; i < maxSize; i++)
    {
        for (int j = 0; j < maxSize; j++)
        {
            G[i][j] = 0;
        }
    }
*/
    // Get user input
    int run = 1;
    int col = 0;

    std::cout << "Enter WAM: " << std::endl;
    while (col < n) 
//    while (run < n) 
    {
    std::string sub;
    std::size_t pos = 0, end = 0;
    std::getline(std::cin, userIn);// << std::endl; 
//    std::cin >> userIn;// << std::endl; 
    std::cout << "userIn = " << userIn << std::endl;

    std::string::iterator strIt = userIn.begin();
    size_t strSize = userIn.size();

    int row = 0;

//    std::vector<std::vector <int>> G(12, (12, 0));

    while (strIt != userIn.end() && end < strSize)
    {
//        std::string::size_type sz;
        pos = end;
        end = userIn.find(" ", end);
        sub = userIn.substr(pos, end - pos);
/*        if (sub.compare(" ") != 0)
        {
            n += 1;
        }
*/
        if (run == 1)
        {
            n = std::count(userIn.begin(), userIn.end(), ' ') + 1;
            std::cout << "n = " << n << std::endl;
        }

        std::cout << "sub = " << sub << std::endl;
//        G.push_back(std::stoi(sub,&sz));
        G[col][row] = std::stoi (sub);

        strIt++;
//        n += 1;
        row += 1;

        if (end <= strSize)
        {
            end += 1;
        }
    }
        col += 1;
        run +=1;
    }

    setIt = E.begin();
    std::cout << "\nThe WAM is: " << std::endl;
    for (int i = 0; i < n; i++) // Print row
    {
        for (int j = 0; j < n; j++)
        {
            std::pair<int, std::pair<int, int>> temp;
            temp = std::make_pair(G[i][j], std::make_pair(j + 1, i + 1));
            std::vector<std::pair<int, std::pair<int, int>>>::iterator it = std::find(E.begin(), E.end(), temp);

            std::cout << G[i][j] << "\t ";
//
            if(G[i][j] > 0 && it == E.end())
//            if(G[i][j] > 0)
            {
                p = std::make_pair(G[i][j], std::make_pair(i + 1, j + 1));
                E.push_back(p);
// xxxx           E.insert(setIt, p);
            }
//            std::make_pair();
//            E.insert(setIt, std::make_pair(i,std::make_pair(j,G[i][j])));
//            E.insert(setIt, G[i][j]);
        }
        std::cout << "\n";
    }
    std::cout << "\n";
    sort(E.begin(), E.end());
//    unique(E.begin(), E.end());

    std::cout << "E = " << std::endl;
    for(setIt = E.begin(); setIt != E.end(); setIt++)
    {
//        std::cout << *setIt << ", ";
        std::cout << setIt->first << ", " << setIt->second.first << ", " << setIt->second.second << std::endl;; 
    }
    std::cout << "\n";// << std::endl;;

    // Kruskal's Algorithm
    // 1. Initialize T to have all the vertices of G and no edges
    T = G;
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            T[i][j] = 0;
        }
    }
    
    // 2. Let E be the set of all edges of G, and let m = 0;
    
    int m = 0;

    //3. 
    setIt = E.begin();
    while (m < n - 1) 
    {
        int e = setIt->first;
//        int e = *setIt;
//        std::cout << "m = " << m << std::endl;
//        std::cout << "e = " << e << std::endl;
        
        //3a. Find an edge e in E of least weight
        std::cout << setIt->first << std::endl;
//        std::cout << *setIt << std::endl;

        //3b. Delete e from E
//        E.erase(setIt);
        
        //3c. If addition of e to the edge set of T does not produce a circuit
        
//        int u, v = 0;
/*        std::vector<std::pair<int, std::pair<int, int>>>::iterator u, v; 
        for(int i = 0; i < n; i++)
        {
            u = std::find(T.begin(), T.end(), *setIt); 
        }
*/        
        
              // Then add e to the edge set of T and set m = m + 1
//        std::cout << "weight = " << setIt->first << std::endl;;
//        std::cout << "row = " << setIt->second.first << std::endl;;
//        std::cout << "collumn = " <<  setIt->second.second << std::endl;;
        T[setIt->second.first - 1][setIt->second.second - 1] = setIt->first;            
        T[setIt->second.second - 1][setIt->second.first - 1] = setIt->first;            
//        std::cout << "check " << std::endl;
        m += 1;
        weight += setIt->first;

        setIt++;
//        std::cout << "=====" << std::endl;
    }

    // Output T (miniumum spanning tree for G)
    std::cout << "\nThe output from Kruskal's Algorithm is: " << std::endl;
    for (int i = 0; i < n; i++) // Print row
    {
        for (int j = 0; j < n; j++)
        {
            std::cout << T[i][j] << "\t ";
        }
        std::cout << "\n";
    }

    std::cout << "\nThe total weight of the graph is " << weight << std::endl; 

    // Prim's Algorithm

    return 0;
}
