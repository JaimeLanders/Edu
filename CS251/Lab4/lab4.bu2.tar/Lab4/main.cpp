/*
 * NAME:        Jaime Landers
 * CRN:         13759          
 * ASSIGNMENT:  Lab 4
 * SOURCES:     None
 *
*/

#include <algorithm>
#include <iostream>
#include <set>
#include <vector>

int main ()
{
    std::pair<int, std::pair<int, int>> p;
    std::vector<std::vector <int>> G =
        { 
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,0,0,0,0,0}
        };
    std::vector<std::vector <int>> T;
    std::vector<std::pair<int, std::pair<int, int>>> E;
    std::vector<std::pair<int, std::pair<int, int>>>::iterator setIt;// = 0;
    int n = 12;
    int weight = 0;
    int maxSize = 12;
    std::string userIn;

    std::cout << "Welcome to Lab 4 " << std::endl;

    // Get user input
    int run = 1;
    int col = 0;

    std::cout << "Enter WAM: " << std::endl;
    while (col < n) 
    {
        std::string sub;
        std::size_t pos = 0, end = 0;
        std::getline(std::cin, userIn);// << std::endl; 
//        std::cout << "userIn = " << userIn << std::endl;

        std::string::iterator strIt = userIn.begin();
        size_t strSize = userIn.size();

        int row = 0;

        while (strIt != userIn.end() && end < strSize)
        {
            pos = end;
            end = userIn.find(" ", end);
            sub = userIn.substr(pos, end - pos);

            if (run == 1)
            {
                n = std::count(userIn.begin(), userIn.end(), ' ') + 1;
                std::cout << "n = " << n << std::endl;
            }

//            std::cout << "sub = " << sub << std::endl;
            G[col][row] = std::stoi (sub);

            strIt++;
            row += 1;

            if (end <= strSize)
            {
                end += 1;
            }

            run +=1;
        }

        col += 1;
    }

    setIt = E.begin();

    std::cout << "\nThe WAM is: " << std::endl;
    for (int i = 0; i < n; i++) // Print row
    {
        for (int j = 0; j < n; j++)
        {
            std::pair<int, std::pair<int, int>> temp;
            temp = std::make_pair(G[i][j], std::make_pair(j + 1, i + 1));
            std::vector<std::pair<int, std::pair<int, int>>>::iterator it = std::find(E.begin(), E.end(), temp);

            std::cout << G[i][j] << "\t ";

            if(G[i][j] > 0 && it == E.end())
            {
                p = std::make_pair(G[i][j], std::make_pair(i + 1, j + 1));
                E.push_back(p);
            }
        }
        std::cout << "\n";
    }
    std::cout << "\n";

    // Sort E by increasing weight
    sort(E.begin(), E.end());
/*
    std::cout << "E = " << std::endl;
    std::cout << "src\tdest\tweight " << std::endl;
    for(setIt = E.begin(); setIt != E.end(); setIt++)
    {
        char src  = 96, dest = 96;
        src += setIt->second.first;
        dest += setIt->second.second;
        std::cout << src << "\t" << dest << "\t" << setIt->first << std::endl;; 
//        std::cout << setIt->second.first << "\t" << setIt->second.second << "\t" << setIt->first << std::endl;; 
    }
    std::cout << "\n";// << std::endl;;
*/
    // Kruskal's Algorithm
    // 1. Initialize T to have all the vertices of G and no edges
    T = G;
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            T[i][j] = 0;
        }
    }
    
    // 2. Let E be the set of all edges of G, and let m = 0;
    
    int m = 0;

    //3. 
    setIt = E.begin();
    std::vector<std::pair<int, std::pair<int, int>>> t;
//    std::vector<std::pair<int, std::pair<int, int>>>::iterator tIt;

//    std::cout << "n = " <<  n << std::endl;

//    while (m < n - 1 || m < maxSize)
//    while (m < n - 1 || m < maxSize || setIt != E.end()) 
    while (m < n - 1) 
    {
//        std::cout << "\ncheck " << std::endl;
        std::pair<int, std::pair<int, int>> e = *setIt;
        std::cout << "\nm = " << m << std::endl;
        std::cout << "e.first = " << e.first << std::endl;
        
        //3a. Find an edge e in E of least weight
//        std::cout << setIt->first << std::endl;

        //3b. Delete e from E
//        E.erase(setIt);
        
        //3c. If addition of e to the edge set of T does not produce a circuit
              // Then add e to the edge set of T and set m = m + 1
              
//        while(tIt != t.end())
//        while(setIt != E.end())
//        {

//            tIt = std::find(t.begin(), t.end(), e.second.second);
//            tIt = std::find(t.begin(), t.end(), e);
            
//            std::cout << "check " << std::endl;

            if(t.empty())
            {
                std::cout << "t is empty" << std::endl;
                t.push_back(e);
                std::cout << "t.begin()->first = " << t.begin()->first << std::endl;
                std::cout << "t.end()->first = " << t.end()->first << std::endl;
                T[e.second.first - 1][e.second.second - 1] = e.first;            
                T[e.second.second - 1][e.second.first - 1] = e.first;            
//                m += 1;
                weight += e.first;
            }
            else
            {
                t.push_back(e);
                T[e.second.first - 1][e.second.second - 1] = e.first;            
                T[e.second.second - 1][e.second.first - 1] = e.first;            
                weight += e.first;
            }
            
/*            for(std::vector<std::pair<int, std::pair<int, int>>>::iterator tIt = t.begin(); tIt != t.end(); ++tIt)
//            for(tIt = t.begin(); tIt != t.end(); tIt++)
            {
                if (tIt != t.begin())
                        std::cout << "tIt++ " << std::endl;

                std::cout << "tIt address = " << &tIt << std::endl;
                std::cout << "tIt->first = " << tIt->first << std::endl;
                std::cout << "tIt->second.first = " << tIt->second.first << std::endl;
                std::cout << "tIt->second.second = " << tIt->second.second << std::endl;
                std::cout << "tIt.end()->first = " << t.end()->first << std::endl;
//                std::cout << "m = " << m << std::endl;
                
                if(tIt->second.second == e.second.second)
                {
                    std::cout << "match" << std::endl;
//                    E.erase(setIt);
                    break;
                }
                else if (tIt++ == t.end())
//                else
                {
                    std::cout << "pushing e to t" << std::endl;
                    t.push_back(e);
                    m += 1;
                    T[e.second.first - 1][e.second.second - 1] = e.first;            
                    T[e.second.second - 1][e.second.first - 1] = e.first;            
                    weight += setIt->first;
//                    break;
                }
                    if (m >= maxSize)
                        break;
            }
*/                    m += 1; // temp

//            }


//            if(tIt == t.end())
//            {
//                t.push_back(e);
        
//        int u, v = 0;
/*        std::vector<std::pair<int, std::pair<int, int>>>::iterator u, v; 
        for(int i = 0; i < n; i++)
        {
            u = std::find(T.begin(), T.end(), *setIt); 
        }
*/        
        
//        std::cout << "weight = " << setIt->first << std::endl;;
//        std::cout << "row = " << setIt->second.first << std::endl;;
//        std::cout << "collumn = " <<  setIt->second.second << std::endl;;

//        T[e.second.first - 1][e.second.second - 1] = e.first;            
//        T[e.second.second - 1][e.second.first - 1] = e.first;            
//        T[setIt->second.first - 1][setIt->second.second - 1] = setIt->first;            
//        T[setIt->second.second - 1][setIt->second.first - 1] = setIt->first;            
//
//    }
//        m += 1;
//        weight += setIt->first;

//                }
//            }
//}
//        m += 1;
        setIt++;
        std::cout << "=====" << std::endl;
//        }
    }

    // Output T (miniumum spanning tree for G)
    std::cout << "\nThe output from Kruskal's Algorithm is: " << std::endl;
    for (int i = 0; i < n; i++) // Print row
    {
        for (int j = 0; j < n; j++)
        {
            std::cout << T[i][j] << "\t ";
        }
        std::cout << "\n";
    }

    std::cout << "\nThe total weight of the graph is " << weight << std::endl; 
    std::cout << "\nThe number of edges  of the graph is " << m << std::endl; 

    // Prim's Algorithm

    return 0;
}
