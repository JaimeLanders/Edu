/*
 * NAME:        Jaime Landers
 * CRN:         13759          
 * ASSIGNMENT:  Lab 3
 * SOURCES:     None
 *
*/

#include <fstream>
#include <iostream>
#include <list>

void div (long long x, long long y, long long * q, long long * r)
{
    long long quotient = 0;
    long long remainder = x;

    while (remainder >= y)
    {
        remainder = remainder - y;
        quotient = quotient + 1;
    }

    *q = quotient;
    *r = remainder;

    return;
}

void decToBi (long long n, int m[])
{
    long long * s  = new long long;
    long long * t  = new long long;
    long long i = 0;
    long long j = n;

    while (i == 0 || j != 0)
    {
       div(j,2, s, t); 

       m[i] = *t;
       j = *s;
       i = i + 1;
    }
    
    delete s;
    delete t;

    return;
} 

int residue (int x, int a, int n)
{
/*    std::cout << "\nresidue " << std::endl;

    std::cout << "x = " << x << std::endl;
    std::cout << "a = " << a << std::endl;
    std::cout << "n = " << n << std::endl;
*/
    long long residue = 0;
//    int residue = 0;
    int res[100];
    int rn = 0;
    int bits [64] = {0};
    bool leadBit = false;

    long long *q = new long long;
    long long *r = new long long;

    *r = x;
//    std::cout << "r initial = " << *r << std::endl;

    // Convert exponent (a) to binary
    decToBi(a, bits);

/*    std::cout << a << " in binary is ";

    for (int i = 63; i >= 0; i--)
    {
        if (bits[i] == 1)
        {
            leadBit = true;
        }

        if (leadBit == true)
        {
            if ((i + 1) % 4 == 0)
                std::cout << " ";

            std::cout << bits[i];
        }
    }
    std::cout << "\n";
    leadBit = false;
*/
    // Calculate residues for all powers of 2
    int a_i = 0;

    for (int i = 0; i < 63; i++)
    {
        a_i = 1;

        if (bits[i] == 1)
        {
            leadBit = true;
        }

        if (leadBit == true)
        {

            if (bits[i] == 1)
            {
                for (int j = 0; j < i; j++)
                {
                    a_i *= 2;
                
                }
//                std::cout << "\na_i = " << a_i << std::endl; 

                *r = x;
//                std::cout << "r initial = " << *r << std::endl;

                for (int j = 1; j <= a_i; j *= 2)
                {
//                    std::cout << "\nj = " << j << std::endl;


                    if (j != 1)
                    {
                        *r *= *r;
                    }

                    div(*r, n, q, r);

//                    std::cout << "q = " << *q << std::endl;
//                    std::cout << "r = " << *r << std::endl;

                }

//                std::cout << "r = " << *r << std::endl; 
                res[rn] = *r;
//                std::cout << "res[" << rn << "] = " << res[rn] << std::endl; 
                rn++;

            }
        }
    }
//    std::cout << "\n";

    // Final step, calculate final residue
    residue = 1;
    for (int i = 0; i < rn; i++)
    {
//        std::cout << "res[" << i << "] = " << res[i] << std::endl;
        residue *= res[i];
    }

//    std::cout << "residue (before div) = " << residue << std::endl; 
    div(residue,n,q,r);
    residue = *r;
//    std::cout << "residue = " << residue << std::endl; 
    leadBit = false;

//    std::cout << "\n";

    delete q;
    delete r;

    return residue;
}

int main ()
{
    std::string fileName;
    std::list<int> dataList;
//    std::list<std::string> dataList;
    std::list<int>::iterator it;
//    std::list<std::string>::iterator it;
    int n = 323; // pq
//    int e = 35;
    int d = 107;

    int messageSize = 6;
//    int message[2] = {17, 14};
    int message[6] = {81, 23, 314, 314, 321, 23};

    std::cout << "Welcome to Lab 2 " << std::endl;

    // Get filename from user

    // Prompt user for file to open
    std::cout << "\nFile location to read: ";
    std::cin >> fileName;

    // Open file 
    bool fileOpen = false;

    std::ifstream inFile;
    inFile.open(fileName);

    if (inFile.is_open())
    {
        std::cout << "\n" << fileName << " opened " << std::endl;
        fileOpen = true;
    }
    else
    {
        std::cout << "\n" << "Could not open " << fileName << std::endl;
    }

    // Read data and add to list
    int newString;
//    std::string newString;

    while (inFile >> newString)
//    while (!inFile.eof() && !inFile.fail())
    {
        int tempString;
//        std::string tempString;

//        inFile >> newString;

        it = dataList.begin();

        dataList.push_back (newString);

/*        if (dataList.empty()) // Case 1: List empty
        {
            dataList.insert(it, newString);
        }
        else // Case 2: List not empty
        {
            while (it != dataList.end())
            {
                tempString = *it;       
        
                if (newString < tempString) // Case 2a: newString before it
                {
                    dataList.insert(it, newString);
                    break;
                }
                else if (newString > tempString && (next(it) != dataList.end())) // Case 2b: newString after it
                {
                    // Do nothing
                } 
                else if (newString == tempString) // Case 2c: newString already exists
                {
                    break;
                }
                else // Case 2d: newString at end of list
                {
                    dataList.push_back (newString);
                }

                ++it;
                
            }
        }
*/
    }

    // Close file
    inFile.close();

    // Output list
/*    if (fileOpen == true)
    {
        std::cout << "\nWords in the file: " << std::endl;

        for(it = dataList.begin(); it != dataList.end(); it++)
        {
            
            std::cout << *it << std::endl;
        }

//        std::cout << "\n";
    }
*/
    // Decrypt message
    
    std::cout << "\nDecrypting message, please wait... " << std::endl;
    
    std::cout << "\nThe secret message is: ";

//        std::cout << "\n=====\n" << std::endl; // Temp
    for (it = dataList.begin(); it != dataList.end(); it++)
//    for (int i = 0; i < messageSize; i++)
    {
        char M = 96;

        int C = *it;
//        int C = message[i];
//        std::cout << "C = " << C << std::endl; 
//        std::cout << "d = " << d << std::endl; 
//        std::cout << "n = " << n << std::endl; 

//        std::cout << residue(C, d, n);// << std::endl;;

//        M = residue(C, d, n);
        M += residue(C, d, n);
//        std::cout << "M = " << M << std::endl;

          
      if (M != 123)
      {
        std::cout << M;
      }
      else
      {
          std::cout << " ";
      }
//        std::cout << "\n=====\n" << std::endl; // Temp
    }

    std::cout << "\n";

    return 0;
}
