package locations;

public abstract class Location 
//    extends locations 
{
}
