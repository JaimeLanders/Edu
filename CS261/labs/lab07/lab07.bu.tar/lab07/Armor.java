package armor;

public abstract class Armor  
//    extends armor 
{
}
