package magic;

public abstract class MagicItem  
//    extends magic 
{
}
