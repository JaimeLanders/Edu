package weapons;

public abstract class Weapon 
//    extends weapons
{
}
