package locations.cities;

public abstract class City  
//    extends cities 
{
}
