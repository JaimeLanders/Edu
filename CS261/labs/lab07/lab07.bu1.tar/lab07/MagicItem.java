package magic;

public abstract class MagicItem  
{
}
