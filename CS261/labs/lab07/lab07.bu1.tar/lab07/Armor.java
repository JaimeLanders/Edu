package armor;

public abstract class Armor  
{
}
