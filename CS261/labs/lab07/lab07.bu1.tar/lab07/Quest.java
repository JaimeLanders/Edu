package quest;

public abstract class Quest  
{
}
