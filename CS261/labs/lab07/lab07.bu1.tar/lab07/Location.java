package locations;

public abstract class Location 
{
}
