This assignment includes several files:

- readme.txt 		 this file

- instructions.txt	 detailed assignment instructions

- background.txt 	 a (very) short story giving background and context
  			 for the assignment. 

- design_questions.txt	 the design questions that must be answered for the
  			 "design" portion of this assignment. 

- MissionCount.java	 the main driver for this program. You must use this 
  			 for your main().

- missionlog.txt 	 the data file that you should use to do the
  			 final test of your program.

- expected.txt		 the expected results when you use missionlog.txt
