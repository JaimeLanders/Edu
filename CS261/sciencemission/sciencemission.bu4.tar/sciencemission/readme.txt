This assignment includes several files:

- readme.txt 		   this file

- instructions.txt	   detailed assignment instructions

- background.txt 	   a (very) short story giving background and context
  			   for the assignment. 

- design_questions.txt	   the design questions that must be answered for the
  			   "design" portion of this assignment. 

- ScienceMissionMain.java  the main driver for this program. You must use this 
  			   for your main().

- Environment.java	   this class models the environment and changes to the
  			   environment. You don't need to modify this class.

- probedata.txt 	   the data file that you should use to do the
  			   final test of your program.

- expected.txt		   the expected results when you use missionlog.txt
