import java.util.Scanner;

public class Sensor
{
    private ElementType element;
//    private double value;

    public Sensor(Scanner sc)
    {
        System.out.println("\nSensor scanner constructor ");
        this.element = ElementType.valueOf(sc.next()); 
        System.out.println("element = " + this.element);
        this.element.setValue(sc.nextDouble());
        System.out.println("value = " + this.element.getValue());
//        this.element = ElementType.valueOf(sc.next()); 
//        System.out.println("element = " + element);
//        this.value = sc.nextDouble(); 
//        System.out.println("value = " + value);
    }

    public Sensor(ElementType elementIn, double valueIn)
    {
//        System.out.println("Sensor constructor ");
        this.element = elementIn;
//        this.value = valueIn; 
    }

    public ElementType getElement()
    {
        return this.element;
    }

/*    public double getValue()
    {
        return this.value;
    }
*/
    public void setElement(ElementType elementIn)
    {
        this.element = elementIn;
    }

/*    public void setValue (double valueIn)
    {
        this.value = valueIn;
    }
*/}
