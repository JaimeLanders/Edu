public enum ElementType
{
//    DILITHIUM_VAPOR,TRACE_TRILITHIUM_PARTICULATE, PROTOMATTER_DENSITY, NITRIUM_GAS, HEXAFLOURINE_GAS, HYDRAZINE
    DILITHIUM_VAPOR(0.0),
    TRACE_TRILITHIUM_PARTICULATE(0.0),
    PROTOMATTER_DENSITY(0.0),
    NITRIUM_GAS(0.0),
    HEXAFLOURINE_GAS(0.0),
    HYDRAZINE(0.0);

    private double value = 0.0;

    ElementType()
    {
    }
    
    ElementType(double valueIn)
    {
        this.value = valueIn;
    }

    public double getValue()
    {
        return this.value;
    }

    public void setValue(double valueIn)
    {
        this.value = valueIn;
    }
    
}

