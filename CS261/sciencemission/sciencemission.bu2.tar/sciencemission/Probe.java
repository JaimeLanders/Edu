import java.util.*;

public class Probe 
{
    private List<Sensor> sensorList = new LinkedList<>();
    private List<Emitter> emitterList = new LinkedList<>();
    
    private String probeName;

    public Probe(Scanner sc)
    {
//        System.out.println("Probe constructor ");

        while (sc.hasNext())
        {
            String temp = sc.next();
//            System.out.println("temp = " + temp);

            if(temp.equals("END"))
                break;

            if (temp.equals("SENSOR"))
            {
//                System.out.println("SENSOR ");
//                String sensor = sc.next(); 
//                ElementType element = ElementType.valueOf(sensor);
//                double value = sc.nextFloat(); 
                Sensor nSensor = new Sensor(sc);
//                Sensor nSensor = new Sensor(element, value);
                sensorList.add(nSensor);
//                System.out.println("element = " + element);
//                System.out.println("value = " + value);
            }
            if (temp.equals("EMITTER"))
            {
//                System.out.println("EMITTER ");
//                String emitter = sc.next(); 
//                ElementType element = ElementType.valueOf(emitter);
//                double value = sc.nextDouble(); 
                Emitter nEmitter = new Emitter(sc);
//                Emitter nEmitter = new Emitter(element, value);
                emitterList.add(nEmitter);
//                System.out.println("element = " + element);
//                System.out.println("value = " + value);
            }
        }
    }

    public void activateProbe(Environment envIn)
    {
        System.out.println("Probe " + this.probeName +  " starting ");
        System.out.println("Sensor reading's before emitting ");
        for (Sensor n : sensorList)
        {
            n.setValue(envIn.sense(n.getElement()));
//            n.value = envIn.sense(n.element);
            System.out.println("  Last reading for " + n.getElement() + ": " + n.getValue());
//            System.out.println("  Last reading for " + n.element + ": " + n.value);
        }
        for (Emitter n : emitterList)
        {
            System.out.println("  Emitting a burst of " + n.getValue() + "units of " + n.getElement());
//            System.out.println("  Emitting a burst of " + n.value + "units of " + n.element);
            envIn.emit(n.getElement(), n.getValue());
//            envIn.emit(n.element, n.value);
        }
            System.out.println("Sensor reading's after emitting ");
        for (Sensor n : sensorList)
        {
            n.setValue(envIn.sense(n.getElement()));
//            n.value = envIn.sense(n.element);
            System.out.println("  Last reading for " + n.getElement() + ": " + n.getValue());
//            System.out.println("  Last reading for " + n.element + ": " + n.value);
        }
        
    }

    public void launchProbe()
    {
        System.out.println("Launching Probe " + this.getName());
        System.out.println("------------------------------------------------ ");
    }

    public String getName()
    {
        return this.probeName;
    }

    public void recallProbe()
    {
        System.out.println("Recalling Probe " + this.getName());
    }

    public void setName(String probeIn)
    {
        this.probeName = probeIn;
    }

}
