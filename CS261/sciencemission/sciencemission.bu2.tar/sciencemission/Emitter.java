import java.util.Scanner;

public class Emitter 
{
    private ElementType element;
    private double value;

    public Emitter(Scanner sc)
    {
        System.out.println("Emitter scanner constructor ");
        this.element = ElementType.valueOf(sc.next());
        System.out.println("element = " + element);
        this.value = sc.nextDouble();
        System.out.println("value = " + value);
    }

    public Emitter(ElementType elementIn, double valueIn)
    {
//        System.out.println("Emitter constructor ");
        element = elementIn;
        value = valueIn;

    }

    public ElementType getElement()
    {
        return this.element;
    }

    public double getValue()
    {
        return this.value;
    }

    public void setElement(ElementType elementIn)
    {
        this.element = elementIn;
    }

    public void setValue (double valueIn)
    {
        this.value = valueIn;
    }
}
