import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.regex.Pattern;

public class ScienceMission
{
    private static List<Probe> probeList = new LinkedList<>();

    private static InputStream getFileInputStream(String fileName)// throws Exception
    {
	    InputStream inputStream;

	    try
        {
	        inputStream = new FileInputStream(new File(fileName));
	    }
	    catch (FileNotFoundException e)
        {
	        inputStream = null;
//	        throw new Exception("unable to open the file -- " + e.getMessage());
	    }
	    return inputStream;
    }

    ScienceMission(String filename)
    {

//        System.out.println("Science Mission constructor ");
//        System.out.println("filename = " + filename);

	    try
        {
	        InputStream log = getFileInputStream(filename);
	        Scanner sc = new Scanner(log);
	        sc.useDelimiter(Pattern.compile("\n"));
	        while (sc.hasNext())
		    {
		       String temp = sc.next(); 
//               System.out.println("\ntemp = " + temp);
//               System.out.println("");

//               if (probeList.size() == 0) 
//               {
//                   System.out.println("creating probeList ");

                   Probe nProbe = new Probe(sc);
                   nProbe.setName(temp);
                   probeList.add(nProbe);
//                   System.out.println("nProbe = " + nProbe.probeName);
//               }
/*               else
//               else if (temp.equals("END"))
               {
//                   System.out.println("adding to probeList ");
                   Probe nProbe = new Probe(sc);
                   nProbe.setName(temp);
                   probeList.add(nProbe);
//                   System.out.println("nProbe = " + nProbe.probeName);
               }
*/
            }


          sc.close();
        }
        
        catch (Exception e)
        {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public static void startMission(Environment envIn)
    {
//        System.out.println("Science Mission started ");
        for (Probe n : probeList)
        {
            n.launchProbe();
            n.activateProbe(envIn);
            n.recallProbe();
        }
    }
   
}
