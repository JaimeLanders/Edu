public class Emitter 
{
    public ElementType element;
    public double value;

    public Emitter(ElementType elementIn, double valueIn)
    {
//        System.out.println("Emitter constructor ");
        element = elementIn;
        value = valueIn;

    }
}
