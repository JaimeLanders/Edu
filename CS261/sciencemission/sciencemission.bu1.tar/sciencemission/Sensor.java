public class Sensor
{
    public ElementType element;
    public double value;

    public Sensor(ElementType elementIn, double valueIn)
    {
//        System.out.println("Sensor constructor ");
        element = elementIn;
        value = valueIn; 
    }
}
