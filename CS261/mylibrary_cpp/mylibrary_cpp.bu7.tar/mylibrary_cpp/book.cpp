#include "book.h"

Book::Book(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook Constructor " << std::endl;
    }
}

Book::Book(const Book& book) // Copy constructor needed?
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook copy constructor " << std::endl;
        std::cout << "book = \n" << &book << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    this->title = book.title;
    this->artist = book.artist;
    this->nItems = book.nItems;
    this->keywords = book.keywords;

}

Book& Book::operator=(const Item& book) // Assignment overload needed?
{

    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook assignment overload  " << std::endl;
        std::cout << "book = \n" << &book << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    delete this;

    this->title = book.getTitle();
    this->artist = book.getArtist();
    this->nItems = book.getNItems();
    this->keywords = book.getKeywords();

    return *this;
}

//Book * Book::clone() const
Item * Book::clone() const
{
    bool debug = true; 

    if (debug == true)
    {
        std::cout << "\nBook clone " << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    Book *nBook = new Book();

    nBook->title = this->getTitle();
    nBook->artist = this->artist;
    nBook->nItems = this->nItems;
    nBook->keywords = this->keywords;

    if (debug == true)
        std::cout << "nBook = \n" << nBook << std::endl;

    return nBook; // Returns new book
}

Book::~Book(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook Deconstructor " << std::endl;
    }
}

ostream& Book::print(ostream& out) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook print " << std::endl;
    }

    out << "-Book- \n";
    out << "author:   " << this->getArtist() << "\n";
    out << "# pages:  " << this->getNItems() << "\n";
    out << "title:    " << this->getTitle() << "\n";
    out << "keywords: ";
    set<string> tempSet = this->getKeywords();
    for(set<string>::iterator it=tempSet.begin(); it != tempSet.end(); ++it)
    {
        out << *it;
        set<string>::iterator it2 = it;
        ++it2;

        if (it2 != tempSet.end())
            out << ", ";
        else
            out << "\n";
    }
    out << "\n"; // Temp
    return out;

}
