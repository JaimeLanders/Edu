#include "movie.h"

Movie::Movie(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMovie Constructor " << std::endl;
    }
}

Movie::Movie(const Movie& movie) // Copy constructor needed?
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMovie copy constructor " << std::endl;
        std::cout << "movie = \n" << &movie << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    this->title = movie.getTitle();
    this->artist = movie.getArtist();
    this->nItems = movie.getNItems();
    this->keywords = movie.getKeywords();
}

Movie& Movie::operator=(const Item& movie) // Assignment overload needed?
{

    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMovie assignment overload  " << std::endl;
        std::cout << &movie << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    delete this;

    this->title = movie.getTitle();
    this->artist = movie.getArtist();
    this->nItems = movie.getNItems();
    this->keywords = movie.getKeywords();

    return *this;
}

Item * Movie::clone() const
{
    bool debug = true; 

    if (debug == true)
    {
        std::cout << "\nMovie clone " << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    Movie *nMovie = new Movie();

    nMovie->title = this->title;
    nMovie->artist = this->artist;
    nMovie->nItems = this->nItems;
    nMovie->keywords = this->keywords;

    if (debug == true)
        std::cout << "nMovie = \n" << this << std::endl;

    return nMovie;

}

Movie::~Movie(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMovie Deconstructor " << std::endl;
    }
}

ostream& Movie::print(ostream& out) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMovie print " << std::endl;
    }

    out << "-Movie- " << std::endl;
    out << "director: " << this->getArtist() << "\n";// std::endl; 
    out << "# scenes: " << this->getNItems() << "\n";// std::endl; 
    out << "cast:     ";
    set<string> tempSet = this->getCast();
    for(set<string>::iterator it=tempSet.begin(); it != tempSet.end(); ++it)
    {
        out << *it;
        set<string>::iterator it2 = it;
        ++it2;

        if (it2 != tempSet.end())
            out << ", ";
        else
            out << "\n";
    }
    out << "title:    " << this->getTitle() << "\n";//  std::endl; 
    out << "keywords: ";
    tempSet = this->getKeywords();
    for(set<string>::iterator it=tempSet.begin(); it != tempSet.end(); ++it)
    {
        out << *it;
        set<string>::iterator it2 = it;
        ++it2;

        if (it2 != tempSet.end())
            out << ", ";
        else
            out << "\n";
    }
    out << "\n"; // Temp
    return out;

}
const set<string> Movie::getCast(void) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMovie getCast " << std::endl;
    }
    
    return this->cast;
}

void Movie::setCast(const string& castIn)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMovie setCast " << std::endl;
        std::cout << "castIn = " << castIn << std::endl;
    }

    this->cast.insert(castIn);
}
