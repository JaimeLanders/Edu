#include "musicalbum.h"

MusicAlbum::MusicAlbum(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMusicAlbum Constructor " << std::endl;
    }
}

MusicAlbum::MusicAlbum(const MusicAlbum& album) // Copy constructor needed?
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMusicAlbum copy constructor " << std::endl;
        std::cout << "album = \n" << &album << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    this->title = album.getTitle();
    this->artist = album.getArtist();
    this->nItems = album.getNItems();
    this->keywords = album.getKeywords();
}

MusicAlbum& MusicAlbum::operator=(const Item& album) // Assignment overload needed?
{

    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nMusicAlbum assignment overload  " << std::endl;
        std::cout << &album << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    delete this;

    this->title = album.getTitle();
    this->artist = album.getArtist();
    this->nItems = album.getNItems();
    this->keywords = album.getKeywords();

    return *this;
}

Item * MusicAlbum::clone() const
{
    bool debug = true; 

    if (debug == true)
    {
        std::cout << "\nMusicAlbum clone " << std::endl;
        std::cout << "this = \n" << this << std::endl;
    }

    MusicAlbum *nMusicAlbum = new MusicAlbum();

    nMusicAlbum->title = this->title;
    nMusicAlbum->artist = this->artist;
    nMusicAlbum->nItems = this->nItems;
    nMusicAlbum->keywords = this->keywords;

    if (debug == true)
        std::cout << "nMusicAlbum = \n" << this << std::endl;

    return nMusicAlbum;

}

MusicAlbum::~MusicAlbum(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMusicAlbum Deconstructor " << std::endl;
    }
}

ostream& MusicAlbum::print(ostream& out) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nMusicAlbum print " << std::endl;
    }

    out << "-MusicAlbum- " << std::endl;
    out << "band:     " << this->getArtist() << "\n";// std::endl; 
    out << "# songs:  " << this->getNItems() << "\n";// std::endl; 
    out << "members:  ";
    set<string> tempSet = this->getMembers();
    for(set<string>::iterator it=tempSet.begin(); it != tempSet.end(); ++it)
    {
        out << *it;
        set<string>::iterator it2 = it;
        ++it2;

        if (it2 != tempSet.end())
            out << ", ";
        else
            out << "\n";
    }
    out << "title:    " << this->getTitle() << "\n";//  std::endl; 
    out << "keywords: ";
    tempSet = this->getKeywords();
    for(set<string>::iterator it=tempSet.begin(); it != tempSet.end(); ++it)
    {
        out << *it;
        set<string>::iterator it2 = it;
        ++it2;

        if (it2 != tempSet.end())
            out << ", ";
        else
            out << "\n";
    }
    out << "\n"; // Temp
    return out;

}
const set<string> MusicAlbum::getMembers(void) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nItem getMembers " << std::endl;
    }
    
    return this->members;
}

void MusicAlbum::setMembers(const string& memberIn)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nItem setMembers " << std::endl;
        std::cout << "memberIn = " << memberIn << std::endl;
    }

    this->members.insert(memberIn);
}
