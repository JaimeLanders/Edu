#include "book.h"
#include <iostream> 

/*Book::Book(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook Constructor " << std::endl;
    }
}

Book::Book(const string& titleIn, const string& authorIn, const int nPagesIn)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook Constructor " << std::endl;
        std::cout << "titleIn = " << titleIn << std::endl;
        std::cout << "artistIn = " << authorIn << std::endl;
        std::cout << "nPagesIn = " << nPagesIn << std::endl;
    }

    this->title = titleIn;
    this->author = authorIn;
    this->nPages = nPagesIn;

    if (debug == true)
    {
        std::cout << "this->title = " << this->title << std::endl;
        std::cout << "this->author = " << this->author << std::endl;
        std::cout << "this->nPages = " << this->nPages << std::endl;
    }

}
*/
Book::~Book(void)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook Deconstructor " << std::endl;
    }

//    delete this;
}

ostream& Book::print(ostream& out) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook print " << std::endl;
    }

    out << "-Book- " << std::endl;
    out << "author:   " << this->getArtist() << std::endl; 
    out << "# pages:  " << this->getNItems() << std::endl; 
    out << "title:    " << this->getTitle() << std::endl; 
    out << "keywords: ";
    set<string> tempSet = this->getKeywords();
    for(set<string>::iterator it=tempSet.begin(); it != tempSet.end(); ++it)
    {
        out << *it;

        if (std::next(it), 1)// == tempSet.end())
            out << ", ";
        else
            out << "\n";
    }
    out << "\n\n"; // Temp
    return out;

}

/*
const string Book::getAuthor()
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook getAuthor " << std::endl;
    }
    
    return this->author;
}

const string Book::getTitle()
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook getTitle " << std::endl;
    }
    
    return this->author;
}

int Book::getNPages()       
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook getNPages " << std::endl;
    }
    
    return this->nPages;
}

void Book::setAuthor(const string& authorIn)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook setAuthor " << std::endl;
        std::cout << "authroIn = " << authorIn << std::endl;
    }

    this->author = authorIn;
}

void Book::setNPages(const int nPagesIn)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook setNPages " << std::endl;
        std::cout << "nPagesIn = " << nPagesIn << std::endl;
    }

    this->nPages = nPagesIn;
}

void Book::setTitle(const string& titleIn) 
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook setTitle " << std::endl;
        std::cout << "titleIn = " << titleIn << std::endl;
    }

    this->author = titleIn;
}
*/
