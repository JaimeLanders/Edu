#pragma once

#include "item.h"

class Book : public Item
{
private:
//    string title; // Needed ??
//    string author; // Needed ??
//    int nPages; // Needed ??
public:
    Book(void);
    Book(const string& title, const string& author, const int nPages) : Item(title, author, nPages){};
//    Book(const string&, const string&, const int);
    ~Book(void);
    virtual ostream& print(ostream& out) const;
//    virtual ostream& operator<<(ostream& out, const Book* const book); // Needed ?
//    friend ostream& operator<<(ostream& out, const Book* const book); // Needed ?
/*    const string getAuthor(void);
    const string getTitle(void);
    int getNPages(void);
    void setAuthor(const string&);
    void setTitle(const string&);
    void setNPages(const int);
*/};

ostream& operator<<(ostream& out, const Book* const book); // Needed ?
