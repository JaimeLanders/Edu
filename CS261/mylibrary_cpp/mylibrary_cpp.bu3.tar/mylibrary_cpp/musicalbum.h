#pragma once

#include "item.h"

class MusicAlbum :
public Item
{
public:
    MusicAlbum(void);
    ~MusicAlbum(void);
};

