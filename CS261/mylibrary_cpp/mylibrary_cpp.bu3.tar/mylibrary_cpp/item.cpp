#include "item.h"
#include <iostream> 

Item::Item(const string& title, const string& artist, const int nItems)
//Item::Item(const string& title, const string& artist)
{
    // your code here
    bool debug = false; 

    if (debug == true)
    {
        std::cout << "\nItem Constructor" << std::endl;
        std::cout << "title = " << title <<  std::endl;
        std::cout << "artist = " << artist <<  std::endl;
        std::cout << "nItems = " << nItems <<  std::endl;
    }

    this->title = title;
    this->artist = artist;
    this->nItems = nItems;
//    this->keywords = NULL;
}

Item::Item()
{
    // your code here
    bool debug = false; 

    if (debug == true)
    {
        std::cout << "\nItem Constructor" << std::endl;
    }
}

Item::~Item()
{
    // your code here
    bool debug = true; 

    if (debug == true)
    {
         std::cout << "\nItem Deconstructor" << std::endl;
    }

//    delete this;
/*    this->setTitle(NULL);
    this->setArtist(NULL);
    this->setNItems(0);
    this->keywords.clear();
*/
//    this->deleteItem;
}

bool operator<(const Item& i1, const Item& i2)
{
    // your code here
    bool debug = false; 

    if (debug == true)
    {
        std::cout << "\nItem comparison overload" << std::endl;
    }

    if (i1.getTitle() < i2.getTitle()) 
//    if (i1 < i2) 
        return true;
    else
        return false;
}

bool operator<(const ItemPtr& ip1, const ItemPtr& ip2)
{
    // your code here
    bool debug = false; 

    if (debug == true)
    {
        std::cout << "\nItemPtr Comparison overload" << std::endl;
    }

    if (ip1.getPtr()->getTitle() < ip2.getPtr()->getTitle()) 
//    if (ip1.getPtr() < ip2.getPtr()) 
        return true;
    else
        return false;
}

ostream& operator<<(ostream& out, const Item* const item)
{
    // your code here
    bool debug = false; 

    if (debug == true)
    {
        std::cout << "\nitem << operator overload" << std::endl;
    }

    return item->print(out);
}

const string Item::getArtist() const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nItem getArtist " << std::endl;
        std::cout << "\nthis artist = " << this->artist << std::endl;
    }
    
    return this->artist;
}

const set<string> Item::getKeywords(void) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nItem getKeywords " << std::endl;
    }
    
    return this->keywords;
}

const string Item::getTitle() const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nItem getTitle " << std::endl;
        std::cout << "\nthis title = " << this->title << std::endl;
    }
    
    return this->title;
}

int Item::getNItems() const       
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nItem getNItems " << std::endl;
        std::cout << "\nthis nItems = " << this->nItems << std::endl;
    }
    
    return this->nItems;
}

ostream& Item::print(ostream& out) const
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nItem print" << std::endl;
    }

    return out;
}

void Item::setArtist(const string& artistIn)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nItem setArtist " << std::endl;
        std::cout << "artistIn = " << artistIn << std::endl;
    }

    this->artist = artistIn;
}

void Item::setKeywords(const string& keywordIn)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nItem setKeywords " << std::endl;
        std::cout << "keywordIn = " << keywordIn << std::endl;
    }

    this->keywords.insert(keywordIn);
}

void Item::setNItems(const int nItemsIn)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nItem setNItems " << std::endl;
        std::cout << "nItemsIn = " << nItemsIn << std::endl;
    }

    this->nItems = nItemsIn;
}

void Item::setTitle(const string& titleIn) 
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nItem setTitle " << std::endl;
        std::cout << "titleIn = " << titleIn << std::endl;
    }

    this->title = titleIn;
}
