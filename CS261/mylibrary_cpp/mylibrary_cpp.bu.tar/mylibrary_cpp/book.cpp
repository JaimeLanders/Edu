#include "book.h"

Book::Book(void)
{
}

Book::~Book(void)
{
}
