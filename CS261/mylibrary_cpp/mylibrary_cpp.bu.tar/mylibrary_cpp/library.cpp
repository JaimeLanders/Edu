#include <cstdarg>		// support macros for vararg
#include <iostream>
#include "library.h"

// general functions

void Library::addKeywordsForItem(const Item* const item, int nKeywords, ...)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddKeywordsForItem " << std::endl; 
        std::cout << "item = " << item << std::endl; 
        std::cout << "nKeywords = " << nKeywords << std::endl; 
    }
    
    // the code in this function demonstrates how to handle a vararg in C++

/*    va_list		keywords;
    char		*keyword;

    va_start(keywords, nKeywords);
    for (int i = 0; i < nKeywords; i++) {
	keyword = va_arg(keywords, char*);
	// do something with each keyword
    }
    va_end(keywords);
*/}

const ItemSet* Library::itemsForKeyword(const string& keyword) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nitemsForKeyword " << std::endl; 
        std::cout << "keyword = " << keyword << std::endl; 
    }

    return NULL;
}

// book-related functions

const Item* Library::addBook(const string& title, const string& author, const int nPages)
{
    // your code here
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\naddBook " << std::endl; 
        std::cout << "title = " << title << std::endl; 
        std::cout << "author = " << author << std::endl; 
        std::cout << "nPages = " << nPages << std::endl; 
    }

    return NULL;
}

const ItemSet* Library::booksByAuthor(const string& author) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nbooksByAuthor " << std::endl; 
        std::cout << "author = " << author << std::endl; 
    }

    return NULL;
}

const ItemSet* Library::books() const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nLibrary::books() " << std::endl; 
    }

    return NULL;
}

// music-related functions

const Item* Library::addMusicAlbum(const string& title, const string& band, const int nSongs)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddMusicAlbum " << std::endl; 
        std::cout << "title = " << title << std::endl; 
        std::cout << "band = " << band << std::endl; 
        std::cout << "nSongs = " << nSongs << std::endl; 
    }

    return NULL;
}

void Library::addBandMembers(const Item* const musicAlbum, const int nBandMembers, ...)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddBandMembers " << std::endl; 
        std::cout << "musicAlbum = " << musicAlbum << std::endl; 
        std::cout << "nBandMembers = " << nBandMembers << std::endl; 
    }
}

const ItemSet* Library::musicByBand(const string& band) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmusicByBand " << std::endl; 
        std::cout << "band = " << band << std::endl; 
    }

    return NULL;
}

const ItemSet* Library::musicByMusician(const string& musician) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmusicByMusician " << std::endl; 
        std::cout << "musicican = " << musician << std::endl; 
    }

    return NULL;
}

const ItemSet* Library::musicAlbums() const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmusicAlbums " << std::endl; 
    }

    return NULL;
}

// movie-related functions

const Item* Library::addMovie(const string& title, const string& director, const int nScenes)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddMovie " << std::endl; 
        std::cout << "title = " << title << std::endl; 
        std::cout << "director = " << director << std::endl; 
        std::cout << "nScenes = " << nScenes << std::endl; 
    }
    return NULL;
}

void Library::addCastMembers(const Item* const movie, const int nCastMembers, ...)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddCastMembers " << std::endl; 
        std::cout << "movie = " << movie << std::endl; 
        std::cout << "nCastMembers = " << nCastMembers << std::endl; 
    }
}

const ItemSet* Library::moviesByDirector(const string& director) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmoviesByDirector " << std::endl; 
        std::cout << "director = " << director << std::endl; 
    }

    return NULL;
}

const ItemSet* Library::moviesByActor(const string& actor) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmoviesByActor " << std::endl; 
        std::cout << "actor = " << actor << std::endl; 
    }

    return NULL;
}

const ItemSet* Library::movies() const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nLibrary::movies() " << std::endl; 
    }

    return NULL;
}

static void deleteMapContents(StringToItemSetMap& s2ism)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\ndeleteMapContents " << std::endl; 
//        std::cout << "s2ism = " << s2ism <<  std::endl; 
    }
}

static void deleteItemSetContents(ItemSet& itemSet)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\ndeleteItemSetContents " << std::endl; 
//        std::cout << "itemSet " << itemSet <<  std::endl; 
    }
}

Library::~Library()
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nLibrary deconstructor " << std::endl; 
    }
}
