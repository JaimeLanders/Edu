#pragma once

#include "item.h"

class Book :
public Item
{
public:
    Book(void);
    ~Book(void);
};

