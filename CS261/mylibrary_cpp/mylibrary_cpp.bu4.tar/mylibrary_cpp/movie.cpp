#include "movie.h"

Movie::Movie(void)
{
}

Movie::~Movie(void)
{
}
