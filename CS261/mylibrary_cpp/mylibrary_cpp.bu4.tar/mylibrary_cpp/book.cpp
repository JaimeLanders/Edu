#include "book.h"
#include <iostream> 

Book::Book(void)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook Constructor " << std::endl;
    }
}

Book::Book(const Book& book) // Copy constructor needed?
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook copy constructor " << std::endl;
//        std::cout << book << std::endl;
    }

    *this = book; 
}

Book& Book::operator=(const Item& book) // Assignment overload needed?
{

    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook assignment overload  " << std::endl;
//        std::cout << &book << std::endl;
    }

/*    this->title = book.title;
    this->artist = book.artist;
    this->artist = book.artist;
    this->keywords = book.keywords;
*/
    return *this;
}

//Book * Book::clone() const
Item * Book::clone() const
{
    bool debug = true; 

    if (debug == true)
    {
        std::cout << "\nBook clone " << std::endl;
//        std::cout << this << std::endl;
    }

//    Book *nBook = new Book(this->getTitle(), this->getArtist(), this->getNItems());
    Book *nBook = new Book(*this); // Calls book copy constructor
//    Book *nBook = new Book();
//    Item *nBook = new Book();

//    delete nBook; // Test
//    delete this;

/*    nBook->title = this->title;
    nBook->artist = this->artist;
    nBook->nItems = this->nItems;
    nBook->keywords = this->keywords;

*//*    nBook->title(this->title);
    nBook->setArtist(this->artist);
    nBook->setNItems(this->nItems);
//    nBook->keywords = this->keywords;

    nBook->setTitle(this->getTitle());
    nBook->setArtist(this->getArtist());
    nBook->setNItems(this->getNItems());
//    nBook->setKeywords(this->keywords);
*/
    return nBook; // Returns new book
//    return * this;
//    return NULL;

}

Book::~Book(void)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook Deconstructor " << std::endl;
    }
}

ostream& Book::print(ostream& out) const
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nBook print " << std::endl;
    }

    out << "-Book- " << std::endl;
    out << "author:   " << this->getArtist() << "\n";// std::endl; 
    out << "# pages:  " << this->getNItems() << "\n";// std::endl; 
    out << "title:    " << this->getTitle() << "\n";//  std::endl; 
    out << "keywords: ";
    set<string> tempSet = this->getKeywords();
    for(set<string>::iterator it=tempSet.begin(); it != tempSet.end(); ++it)
    {
        out << *it;
        set<string>::iterator it2 = it;
        ++it2;

        if (it2 != tempSet.end())
            out << ", ";
        else
            out << "\n";
    }
    out << "\n"; // Temp
    return out;

}
