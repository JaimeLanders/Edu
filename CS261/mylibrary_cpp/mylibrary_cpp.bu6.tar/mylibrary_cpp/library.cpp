#include <cstdarg>		// support macros for vararg
#include <iostream>
#include "library.h"

/* TODO:
 * xAdd book
 * xAdd keywords
 * xAdd music album
 * xAdd band members
 * xAdd movie
 * xAdd cast
 * xPrint items by title
 * xPrint items by keyword
 * xPrint books by author
 * xPrint albums by band
 * xPrint albums by member
 * xPrint movies by director
 * xPrint movies by cast 
 * xDelete set contents 
 * xDelete map contents
 * Fix dependence on casting in keywords
 * Fix dependence on casting in addBandMembers and addCast
 *
 *  Bugs:
 * xItems sorted by title
 * xExtra comma on keywords output
 *  Missing/extra newline when printing items
*/

// general functions
/*Library::Library() // Needed ?
{
    // your code here
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nLibrary constructor " << std::endl; 
    }
}
*/
Library::~Library()
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nLibrary deconstructor " << std::endl; 
    }

    deleteItemSetContents(AlbumSet);
    deleteItemSetContents(BookSet);
    deleteItemSetContents(MovieSet);
    deleteMapContents(ItemMapByKeyword);
    deleteMapContents(AlbumMapByBand);
    deleteMapContents(AlbumMapByMember);
    deleteMapContents(BookMapByAuthor);
    deleteMapContents(MovieMapByCast);
    deleteMapContents(MovieMapByDirector);
}

void Library::addKeywordsForItem(const Item* const item, int nKeywords, ...)
{
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddKeywordsForItem " << std::endl; 
        std::cout << "nKeywords = " << nKeywords << std::endl; 
    }
    
    // the code in this function demonstrates how to handle a vararg in C++

    va_list		keywords;
    char		*keyword;

    va_start(keywords, nKeywords);

// Place 1
/*    Item nItem  = Item(*item); // Calls copy constructor, not working
//    Item * nItem = new Item(*item); // Calls copy constructor, not working

    if (debug == true)
        std::cout << "nItem = " << &nItem << std::endl; 
*/
    for (int i = 0; i < nKeywords; i++)
    {
	    keyword = va_arg(keywords, char*);

	    // do something with each keyword
        if (debug == true)
            std::cout << "keyword = " << keyword << std::endl; 
        
        // Add keyword and item to map 
        
        Item * nItem;
//        Item * nItem = new Item(*item); // Calls copy constructor, not working
//          Item * nItem = new Item();
//        const ItemPtr * nPtr = item;

//        set<ItemPtr>::iterator it = BookSet.find(*nPtr); 
        nItem = const_cast<Item*>(item); // Temp fix

//        nItem.setKeywords(keyword);
        nItem->setKeywords(keyword);

        if (ItemMapByKeyword.find(keyword) == ItemMapByKeyword.end()) // Case 1 - keyword not mapped
        {
            if (debug == true)
                std::cout << keyword << " not mapped " << std::endl; 

//            Item  * tempItem = nItem;
//             Item  * tempItem = new Item (*nItem); // Calls copy constructor
//            Item * tempItem = new Item(*item); // Calls copy constructor

//            ItemSet * tempSet;
            ItemSet * tempSet = new ItemSet();

//            tempSet->insert(tempItem);
//            tempSet->insert(&nItem);
            tempSet->insert(nItem);

            ItemMapByKeyword.insert(std::make_pair(keyword, tempSet));
        }
        else // Case 2 - keyword already mapped
        {
            if (debug == true)
                std::cout << keyword << " already mapped " << std::endl; 

//            Item  * tempItem = nItem;
//            Item * tempItem = new Item(*nItem); // Calls copy constructor, needs keywords
//            Item * tempItem = new Item(*item); // Calls copy constructor, needs keywords

            ItemSet * tempSet = ItemMapByKeyword[keyword];

//            tempSet->insert(tempItem);
//            tempSet->insert(&nItem);
            tempSet->insert(nItem);

            ItemMapByKeyword.insert(std::make_pair(keyword, tempSet));

            if (debug == true)
                std::cout << "tempSet size = " <<  tempSet->size() << std::endl; 
        }

        if (debug == true)
        {
            std::cout << "ItemMapByKeyword size = " << ItemMapByKeyword.size() << std::endl; 
            std::cout << keyword << " values " << ItemMapByKeyword[keyword]->size() << std::endl; 
        }
    }

    va_end(keywords);

}

const ItemSet* Library::itemsForKeyword(const string& keyword) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nitemsForKeyword " << std::endl; 
        std::cout << "keyword = " << keyword << std::endl; 
    }
    
    const ItemSet * tempSet;

    if (ItemMapByKeyword.find(keyword) != ItemMapByKeyword.end())
    {
        if (debug == true)
            std::cout << keyword << " found " << std::endl; 

        tempSet = ItemMapByKeyword.at(keyword);

        return tempSet;
    }
    else
    {
        if (debug == true)
            std::cout << keyword << " not found " << std::endl; 
        return NULL;
    }
}

// book-related functions

const Item* Library::addBook(const string& title, const string& author, const int nPages)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddBook pre-op " << std::endl; 
        std::cout << "title = " << title << std::endl; 
        std::cout << "author = " << author << std::endl; 
        std::cout << "nPages = " << nPages << std::endl; 
    }

//    Item *nBook = new Book(title, author, nPages);
    Book *nBook = new Book(title, author, nPages); // Test
    BookSet.insert(nBook);
    
    if (BookMapByAuthor.find(author) == BookMapByAuthor.end()) // Case 1 - author not mapped
        {
            if (debug == true)
                std::cout << author << " not mapped " << std::endl; 

            ItemSet * tempSet = new ItemSet();
            tempSet->insert(nBook);
            BookMapByAuthor.insert(std::make_pair(author, tempSet));
        }
        else // Case 2 -  already mapped
        {
            if (debug == true)
                std::cout << author << " already mapped " << std::endl; 

            ItemSet * tempSet;
            tempSet = BookMapByAuthor[author];
            tempSet->insert(nBook);
            BookMapByAuthor.insert(std::make_pair(author, tempSet));

            if (debug == true)
                std::cout << "tempSet size = " <<  tempSet->size() << std::endl; 
        }

    if (debug == true)
    {
        std::cout << "\naddBook post-op " << std::endl; 
        std::cout << "BookSet size = " << BookSet.size() << std::endl; 
    }
/*
    Item *mBook = nBook; // Copy constructor test
    Item *oBook;
    oBook = nBook; // Assignment overload test
    std::cout << "mBook = \n " << mBook << std::endl;
    std::cout << "oBook = \n " << mBook << std::endl;
*/
    return nBook;
}

const ItemSet* Library::booksByAuthor(const string& author) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nbooksByAuthor " << std::endl; 
        std::cout << "author = " << author << std::endl; 
    }

    const ItemSet * tempSet;

    if (BookMapByAuthor.find(author) != BookMapByAuthor.end())
    {
        if (debug == true)
            std::cout << author << " found " << std::endl; 

        tempSet = BookMapByAuthor.at(author);

        return tempSet;
    }
    else
    {
        if (debug == true)
            std::cout << author << " not found " << std::endl; 
        return NULL;
    }
}

const ItemSet* Library::books() const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nLibrary::books() " << std::endl; 
    }

    return &BookSet;
}

// music-related functions

const Item* Library::addMusicAlbum(const string& title, const string& band, const int nSongs)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddMusicAlbum " << std::endl; 
        std::cout << "title = " << title << std::endl; 
        std::cout << "band = " << band << std::endl; 
        std::cout << "nSongs = " << nSongs << std::endl; 
    }

    Item *nAlbum = new MusicAlbum(title, band, nSongs);
    AlbumSet.insert(nAlbum);
    
    if (AlbumMapByBand.find(band) == AlbumMapByBand.end()) // Case 1 - band not mapped
        {
            if (debug == true)
                std::cout << band << " not mapped " << std::endl; 

            ItemSet * tempSet = new ItemSet();
            tempSet->insert(nAlbum);
            AlbumMapByBand.insert(std::make_pair(band, tempSet));
        }
        else // Case 2 -  already mapped
        {
            if (debug == true)
                std::cout << band << " already mapped " << std::endl; 

            ItemSet * tempSet;
            tempSet = AlbumMapByBand[band];
            tempSet->insert(nAlbum);
            AlbumMapByBand.insert(std::make_pair(band, tempSet));

            if (debug == true)
                std::cout << "tempSet size = " <<  tempSet->size() << std::endl; 
        }

    if (debug == true)
    {
        std::cout << "\naddAlbum post-op " << std::endl; 
        std::cout << "AlbumSet size = " << AlbumSet.size() << std::endl; 
    }

    return nAlbum;
}

void Library::addBandMembers(const Item* const musicAlbum, const int nBandMembers, ...)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddBandMembers " << std::endl; 
        std::cout << musicAlbum << std::endl; 
        std::cout << "nBandMembers = " << nBandMembers << std::endl; 
    }

    va_list members;
    char *member;

    va_start(members, nBandMembers);

    for (int i = 0; i < nBandMembers; i++)
    {
	    member = va_arg(members, char*);

	    // do something with each keyword
        if (debug == true)
            std::cout << "member = " << member << std::endl; 
        
        // Add keyword and musicAlbum to map 
        
        MusicAlbum * nMusicAlbum;
//        Item * nMusicAlbum;
//        ItemPtr * tempPtr;

//        nMusicAlbum = AlbumSet.find(tempPtr); // No matching member function
//        nMusicAlbum = AlbumSet.find(musicAlbum); // No matching member function
//        set<ItemPtr*>::iterator it = AlbumSet.find(musicAlbum); // No matching member function
//        nMusicAlbum = new MusicAlbum(musicAlbum); // Temp fix

        nMusicAlbum = (MusicAlbum*)musicAlbum; // Temp fix
//        nMusicAlbum = const_cast<MusicAlbum*>(musicAlbum); // Incompatable type
//        nMusicAlbum = const_cast<Item*>(musicAlbum); // Incompatable type 

//        musicAlbum.setMembers(member);
//        musicAlbum->setMembers(member);
//        nMusicAlbum.setMembers(member);
        nMusicAlbum->setMembers(member);

        if (AlbumMapByMember.find(member) == AlbumMapByMember.end()) // Case 1 - keyword not mapped
        {
            if (debug == true)
                std::cout << member << " not mapped " << std::endl; 

//            Item * tempMusicAlbum = nMusicAlbum;
//            MusicAlbum * tempMusicAlbum = nMusicAlbum;

            ItemSet * tempSet = new ItemSet();
            
            tempSet->insert(nMusicAlbum);
//            tempSet->insert(tempMusicAlbum);

            AlbumMapByMember.insert(std::make_pair(member, tempSet));
        }
        else // Case 2 - keyword already mapped
        {
            if (debug == true)
                std::cout << member << " already mapped " << std::endl; 

//            Item * tempMusicAlbum = nMusicAlbum;
//            Item * tempMusicAlbum = nMusicAlbum;
//            MusicAlbum * tempMusicAlbum = nMusicAlbum;

            ItemSet * tempSet = AlbumMapByMember[member];

            tempSet->insert(nMusicAlbum);
//            tempSet->insert(tempMusicAlbum);

            AlbumMapByMember.insert(std::make_pair(member, tempSet));

            if (debug == true)
                std::cout << "tempSet size = " <<  tempSet->size() << std::endl; 
        }

        if (debug == true)
        {
            std::cout << "AlbumMapByMember size = " << AlbumMapByMember.size() << std::endl; 
            std::cout << member << " values " << AlbumMapByMember[member]->size() << std::endl; 
        }
    }

    va_end(members);
}

const ItemSet* Library::musicByBand(const string& band) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmusicByBand " << std::endl; 
        std::cout << "band = " << band << std::endl; 
    }
    
    const ItemSet * tempSet;

    if (AlbumMapByBand.find(band) != AlbumMapByBand.end())
    {
        if (debug == true)
            std::cout << band << " found " << std::endl; 

        tempSet = AlbumMapByBand.at(band);

        return tempSet;
    }
    else
    {
        if (debug == true)
            std::cout << band << " not found " << std::endl; 
        return NULL;
    }
}

const ItemSet* Library::musicByMusician(const string& musician) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmusicByMusician " << std::endl; 
        std::cout << "musicican = " << musician << std::endl; 
    }

    const ItemSet * tempSet;

    if (AlbumMapByMember.find(musician) != AlbumMapByMember.end())
    {
        if (debug == true)
            std::cout << musician << " found " << std::endl; 

        tempSet = AlbumMapByMember.at(musician);

        return tempSet;
    }
    else
    {
        if (debug == true)
            std::cout << musician << " not found " << std::endl; 
        return NULL;
    }
}

const ItemSet* Library::musicAlbums() const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmusicAlbums " << std::endl; 
    }

    return &AlbumSet;
}

// movie-related functions

const Item* Library::addMovie(const string& title, const string& director, const int nScenes)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddMovie " << std::endl; 
        std::cout << "title = " << title << std::endl; 
        std::cout << "director = " << director << std::endl; 
        std::cout << "nScenes = " << nScenes << std::endl; 
    }

    Item *nMovie = new Movie(title, director, nScenes);
    MovieSet.insert(nMovie);
    
    if (MovieMapByDirector.find(director) == MovieMapByDirector.end()) // Case 1 - director not mapped
        {
            if (debug == true)
                std::cout << director << " not mapped " << std::endl; 

            ItemSet * tempSet = new ItemSet();
            tempSet->insert(nMovie);
            MovieMapByDirector.insert(std::make_pair(director, tempSet));
        }
        else // Case 2 -  already mapped
        {
            if (debug == true)
                std::cout << director << " already mapped " << std::endl; 

            ItemSet * tempSet;
            tempSet = MovieMapByDirector[director];
            tempSet->insert(nMovie);
            MovieMapByDirector.insert(std::make_pair(director, tempSet));

            if (debug == true)
                std::cout << "tempSet size = " <<  tempSet->size() << std::endl; 
        }

    if (debug == true)
    {
        std::cout << "\naddMovie post-op " << std::endl; 
        std::cout << "MovieSet size = " << MovieSet.size() << std::endl; 
    }

    return nMovie;
}

void Library::addCastMembers(const Item* const movie, const int nCastMembers, ...)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\naddCastMembers " << std::endl; 
        std::cout << "movie = " << movie << std::endl; 
        std::cout << "nCastcast = " << nCastMembers << std::endl; 
    }

    va_list cast;
    char *castMember;

    va_start(cast, nCastMembers);

    for (int i = 0; i < nCastMembers; i++)
    {
	    castMember = va_arg(cast, char*);

	    // do something with each keyword
        if (debug == true)
            std::cout << "castMember = " << castMember << std::endl; 
        
        // Add keyword and Movie to map 
        
        Movie * nMovie;

        nMovie = (Movie*)movie; // Temp fix

        nMovie->setCast(castMember);

        if (MovieMapByCast.find(castMember) == MovieMapByCast.end()) // Case 1 - keyword not mapped
        {
            if (debug == true)
                std::cout << castMember << " not mapped " << std::endl; 

            ItemSet * tempSet = new ItemSet();
            
            tempSet->insert(nMovie);

            MovieMapByCast.insert(std::make_pair(castMember, tempSet));
        }
        else // Case 2 - keyword already mapped
        {
            if (debug == true)
                std::cout << castMember << " already mapped " << std::endl; 

            ItemSet * tempSet = MovieMapByCast[castMember];

            tempSet->insert(nMovie);

            MovieMapByCast.insert(std::make_pair(castMember, tempSet));

            if (debug == true)
                std::cout << "tempSet size = " <<  tempSet->size() << std::endl; 
        }

        if (debug == true)
        {
            std::cout << "MovieMapByCast size = " << MovieMapByCast.size() << std::endl; 
            std::cout << castMember << " values " << MovieMapByCast[castMember]->size() << std::endl; 
        }
    }

    va_end(cast);
}

const ItemSet* Library::moviesByDirector(const string& director) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmoviesByDirector " << std::endl; 
        std::cout << "director = " << director << std::endl; 
    }

    const ItemSet * tempSet;

    if (MovieMapByDirector.find(director) != MovieMapByDirector.end())
    {
        if (debug == true)
            std::cout << director << " found " << std::endl; 

        tempSet = MovieMapByDirector.at(director);

        return tempSet;
    }
    else
    {
        if (debug == true)
            std::cout << director << " not found " << std::endl; 
        return NULL;
    }
}

const ItemSet* Library::moviesByActor(const string& actor) const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nmoviesByActor " << std::endl; 
        std::cout << "actor = " << actor << std::endl; 
    }

    const ItemSet * tempSet;

    if (MovieMapByCast.find(actor) != MovieMapByCast.end())
    {
        if (debug == true)
            std::cout << actor << " found " << std::endl; 

        tempSet = MovieMapByCast.at(actor);

        return tempSet;
    }
    else
    {
        if (debug == true)
            std::cout << actor << " not found " << std::endl; 
        return NULL;
    }
    return NULL;
}

const ItemSet* Library::movies() const
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\nLibrary::movies() " << std::endl; 
    }

// Place 2
    return &MovieSet;
}

static void deleteMapContents(StringToItemSetMap& s2ism)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\ndeleteMapContents pre-op " << std::endl; 
        std::cout << "s2ism size = " << s2ism.size() <<  std::endl; 
    }

    // Iterate through map
    for(std::map<string, ItemSet*>::iterator it = s2ism.begin(); it != s2ism.end(); )
    {
        if (debug == true)
            std::cout << "key = " << it->first << std::endl;

        // Iterate through set
        ItemSet *tempSet = it->second;

        for(std::set<ItemPtr>::iterator it2 = tempSet->begin(); it2 != tempSet->end(); )
        {
            if (debug == true)
            {
                std::cout << "tempSet size = " << tempSet->size() << std::endl;
                std::cout << it2->getPtr();// << endl;
            }

            // Delete item in set
//            Item *tempItem = it2->getPtr(); 
//            delete tempItem;
//            delete it2->getPtr(); // Seg faults after 1st deletion of item
//            delete &it2;
          
            if (next((it2),1) != tempSet->end())        
                it2 = tempSet->erase(it2);
            else
                ++it2;
        }

//        tempSet->clear();
          delete tempSet; // Test, put in item constructor?

//        if (debug == true)
//            std::cout << "tempSet size = " << tempSet->size() << std::endl;

        if (next((it),1) != s2ism.end())        
            it = s2ism.erase(it);
        else
            ++it;
    }
     
//    s2ism.clear();

    if (debug == true)
    {
        std::cout << "deleteMapContents post-op " << std::endl; 
        std::cout << "s2ism size = " << s2ism.size() <<  std::endl; 
    }
}

static void deleteItemSetContents(ItemSet& itemSet)
{
    // your code here
    bool debug = false;

    if (debug == true)
    {
        std::cout << "\ndeleteItemSetContents pre-op " << std::endl; 
        std::cout << "itemSet size " << itemSet.size() <<  std::endl; 
    }

    for(std::set<ItemPtr>::iterator it = itemSet.begin(); it != itemSet.end(); )
    {
        if (debug == true)
            std::cout << it->getPtr() << endl;

        delete it->getPtr();

        if (next((it),1) != itemSet.end())        
            it = itemSet.erase(it);
        else
            ++it;
    }

//    itemSet.clear();

    if (debug == true)
    {
        std::cout << "\ndeleteItemSetContents post-op " << std::endl; 
        std::cout << "itemSet size " << itemSet.size() <<  std::endl; 
    }
}
