#include "book.h"
#include <iostream> 

Book::Book(void)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook Constructor " << std::endl;
    }
}

Book::Book(const string& titleIn, const string& authorIn, const int nPagesIn)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook Constructor " << std::endl;
        std::cout << "titleIn = " << titleIn << std::endl;
        std::cout << "artistIn = " << authorIn << std::endl;
        std::cout << "nPagesIn = " << nPagesIn << std::endl;
    }

    this->title = titleIn;
    this->author = authorIn;
    this->nPages = nPagesIn;

    if (debug == true)
    {
        std::cout << "this->title = " << this->title << std::endl;
        std::cout << "this->author = " << this->author << std::endl;
        std::cout << "this->nPages = " << this->nPages << std::endl;
    }

}

Book::~Book(void)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook Deconstructor " << std::endl;
    }

    delete this;
}

ostream& operator<<(ostream& out, const Book* const book) // Needed?
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook << overload  " << std::endl;
    }
//    Book *nBook = new Book;
//    *nBook = item;

    out << "-Book- " << std::endl;
    out << "Title: \t" << std::endl; 
    out << "Author: \t" << std::endl; 
    out << "Pages: \t" << std::endl; 
    out << "Keywords: \t" << std::endl; 

    return out;
    
}

const string Book::getAuthor()
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook getAuthor " << std::endl;
    }
    
    return this->author;
}

const string Book::getTitle()
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook getTitle " << std::endl;
    }
    
    return this->author;
}

int Book::getNPages()       
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook getNPages " << std::endl;
    }
    
    return this->nPages;
}

void Book::setAuthor(const string& authorIn)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook setAuthor " << std::endl;
        std::cout << "authroIn = " << authorIn << std::endl;
    }

    this->author = authorIn;
}

void Book::setNPages(const int nPagesIn)
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook setNPages " << std::endl;
        std::cout << "nPagesIn = " << nPagesIn << std::endl;
    }

    this->nPages = nPagesIn;
}

void Book::setTitle(const string& titleIn) 
{
    bool debug = true;

    if (debug == true)
    {
        std::cout << "\nBook setTitle " << std::endl;
        std::cout << "titleIn = " << titleIn << std::endl;
    }

    this->author = titleIn;
}
