#pragma once

#include "item.h"

class Book : public Item
{
private:
    string title;
    string author;
    int nPages;
public:
    Book(void);
    Book(const string&, const string&, const int);
    ~Book(void);
    friend ostream& operator<<(ostream& out, const Book* const book); // Needed ?
    const string getAuthor(void);
    const string getTitle(void);
    int getNPages(void);
    void setAuthor(const string&);
    void setTitle(const string&);
    void setNPages(const int);
};
