#pragma once

#include "item.h"
#include <iostream> 

class Movie :
public Item
{
public:
    Movie(void);
    ~Movie(void);
};

