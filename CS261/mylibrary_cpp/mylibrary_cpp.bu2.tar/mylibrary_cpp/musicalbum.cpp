#include "musicalbum.h"

MusicAlbum::MusicAlbum(void)
{
}

MusicAlbum::~MusicAlbum(void)
{
}
