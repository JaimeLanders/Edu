#pragma once

#include "item.h"

class Movie :
public Item
{
public:
    Movie(void);
    ~Movie(void);
};

