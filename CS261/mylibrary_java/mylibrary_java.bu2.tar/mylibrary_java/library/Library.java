package library;

import java.io.PrintStream;
import java.util.Collection;
import java.util.*;

public class Library
{
//    Map<String, Item> library = new TreeMap<>();
    Map<String, TreeMap<String, Item>> library = new TreeMap<>();
    Map<String, Item> books = new TreeMap<>();
    Map<String, Item> musicAlbums = new TreeMap<>();
    Map<String, Item> movies = new TreeMap<>();

//    Set<Item> books = new TreeSet<>();
//    Set<Item> musicAlbums = new TreeSet<>();
//    Set<Item> movies = new TreeSet<>();

	// general methods
	
	// returns all of the items which have the specified keyword
	public Collection<Item> itemsForKeyword(String keyword)
	{
//        boolean debug = false;
        boolean debug = true;
        TreeMap<String, Item> tempMap = new TreeMap<>();
//        Map<String, TreeMap<String, Item>> tempMap = new TreeMap<>();
	
        if (debug == true)
        {
            System.out.println("itemsForKeyword ");
            System.out.println("keyword = " + keyword);
        }

        if (library.containsKey(keyword))
        {
            if (debug == true)
                System.out.println(keyword + " found\n");

            tempMap = library.get(keyword);
//            tempMap.put(keyword, library.get(keyword));
        }
        else 
        {
            if (debug == true)
                System.out.println(keyword + " not found\n");
        }

		return tempMap.values();
	}
	
	// print an item from this library to the output stream provided
	public void printItem(PrintStream out, Item item)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("printItem ");
        }

        System.out.println(item.toString());
	}
	
	// book-related methods
	
	// adds a book to the library
	public Item addBook(String title, String author, int nPages, String... keywords)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("addBook ");
            System.out.println("title = " + title);
            System.out.println("author = " + author);
            System.out.println("nPages = " + nPages);
            for(String n : keywords)
                System.out.println("keyword = " + n);
        }

        Item nBook = new Book(); 
        nBook.setTitle(title);
        nBook.setPerson(author);
        nBook.setNumberItems(nPages);
        nBook.setKeywords(keywords);

        if (debug == true)
        {
            System.out.println(nBook.toString());
        }

        for(String n : keywords)
        {
            if (!library.containsKey(n))
            {
                TreeMap<String, Item> nMap = new TreeMap<>();
                nMap.put(title, nBook);

                library.put(n, nMap);
            }
            else
            {
                TreeMap nMap = library.get(n);
                nMap.put(title, nBook);

                library.put(n, nMap);
            }

//            library.put(n, nBook);
        }

        books.put(title, nBook);
           
		return nBook;
	}
	
	// removes a book from the library
	public boolean removeBook(String title)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("removeBook ");
            System.out.println("title = " + title);
        }
		return false;
	}
	
	// returns all of the books by the specified author
	public Collection<Item> booksByAuthor(String author)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("booksByAuthor ");
            System.out.println("author = " + author);
        }

		return null;
	}
	
	// returns all of the books in the library
	public Collection<Item> books()
	{
//        boolean debug = false;
        boolean debug = true;

        if (debug == true)
        {
            System.out.println("books ");
        }

		return books.values();
	}
	
	// music-related methods
	
	// adds a music album to the library
	public Item addMusicAlbum(String title, String band, int nSongs, String... keywords)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("addMusicAlbum ");
            System.out.println("title = " + title);
            System.out.println("band = " + band);
            System.out.println("nSongs = " + nSongs);
            for(String n : keywords)
                System.out.println("keyword = " + n);
        }

        Item nAlbum = new MusicAlbum(); 
        nAlbum.setTitle(title);
        nAlbum.setPerson(band);
        nAlbum.setNumberItems(nSongs);
        nAlbum.setKeywords(keywords);

        if (debug == true)
        {
            System.out.println(nAlbum.toString());
        }

        for(String n : keywords)
        {
            if (!library.containsKey(n))
            {
                TreeMap<String, Item> nMap = new TreeMap<>();
                nMap.put(title, nAlbum);

                library.put(n, nMap);
            }
            else
            {
                TreeMap nMap = library.get(n);
                nMap.put(title, nAlbum);

                library.put(n, nMap);
            }

//           library.put(n, nAlbum);
        }

        musicAlbums.put(title, nAlbum);

		return nAlbum;
	}

	// adds the specified band members to a music album
	public void addBandMembers(Item album, String... members)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("addBandMembers ");
            System.out.println("album = " + album.getTitle());
            for(String n : members)
                System.out.println("member = " + n);
            System.out.println("");
        }

            MusicAlbum currAlbum = (MusicAlbum) album;
            currAlbum.setMembers(members);
	}
	
	// removes a music album from the library
	public boolean removeMusicAlbum(String title)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("removeMusicAlbum ");
            System.out.println("title = " + title);
        }

		return false;
	}

	// returns all of the music albums by the specified band
	public Collection<Item> musicByBand(String band)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("musicByBand ");
            System.out.println("band = " + band);
        }

		return null;
	}
	
	// returns all of the music albums by the specified musician
	public Collection<Item> musicByMusician(String musician)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("musicByMusician ");
            System.out.println("musician = " + musician);
        }

		return null;
	}
	
	// returns all of the music albums in the library
	public Collection<Item> musicAlbums()
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("musicAlbums ");
        }

		return musicAlbums.values();
	}
	
	// movie-related methods
	
	// adds a movie to the library
	public Item addMovie(String title, String director, int nScenes, String... keywords)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("addMovie ");
            System.out.println("title = " + title);
            System.out.println("director = " + director);
            System.out.println("nScenes = " + nScenes);
            for(String n : keywords)
                System.out.println("keyword = " + n);
        }

        Item nMovie = new Movie(); 
        nMovie.setTitle(title);
        nMovie.setPerson(director);
        nMovie.setNumberItems(nScenes);
        nMovie.setKeywords(keywords);

        if (debug == true)
        {
            System.out.println(nMovie.toString());
        }

        for(String n : keywords)
        {
            if (!library.containsKey(n))
            {
                TreeMap<String, Item> nMap = new TreeMap<>();
                nMap.put(title, nMovie);

                library.put(n, nMap);
            }
            else
            {
                TreeMap nMap = library.get(n);
                nMap.put(title, nMovie);

                library.put(n, nMap);
            }

//            library.put(n, nMovie);
        }

        movies.put(title, nMovie);

		return nMovie;
	}

	// adds the specified actors to a movie
	public void addCast(Item movie, String... members)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("addCast ");
            System.out.println("movie = " + movie.getTitle());
            for(String n : members)
                System.out.println("member = " + n);
            System.out.println("");
        }
            Movie currMovie = (Movie) movie;
            currMovie.setCast(members);
	}

	// removes a movie from the library
	public boolean removeMovie(String title)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("removeMovie ");
            System.out.println("title = " + title);
        }

		return false;
	}
	
	// returns all of the movies by the specified director
	public Collection<Item> moviesByDirector(String director)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("moviesByDirector ");
            System.out.println("director = " + director);
        }

		return null;
	}
	
	// returns all of the movies by the specified actor
	public Collection<Item> moviesByActor(String actor)
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("moviesByActor ");
            System.out.println("actor = " + actor);
        }

		return null;
	}
	
	// returns all of the movies in the library
	public Collection<Item> movies()
	{
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("movies ");
        }

		return movies.values();
	}	
}
