package library;
import java.util.*;

class Book
	extends Item
{

    public Book()
    {
        super();

        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("Book constructor ");

    }

    public String toString()
    {
        String text;

        text = "-Book-\n";
        text += "author: \t" + this.person + "\n";
        text += "# pages: \t" + this.numberItems + "\n";
        text += "title: \t\t" + this.title + "\n";
        text += "keywords: \t";
        for(String n : this.keywords)
        {
            text += n;
//            if n.hasNext();
                text += ", " ;
        }
        text += "\n";

        return text; 
    }

    public String[] getKeywords()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("Book getKeywords ");

        String[] temp = this.keywords.toArray(new String[this.keywords.size()]);
        return temp;
    }

    public int getNumberItems()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("Book getNumberItems ");

        return this.numberItems;
    }

    public String getPerson()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("Book getPerson ");

        return this.person;
    }

    public String getTitle()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("Book getTitle ");

        return this.title;
    }

    public void setKeywords(String... keywordsIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("Book setKeywords ");
            for(String n : keywordsIn)
                System.out.println("keyword = " + n);
        }

        this.keywords = new TreeSet<String>();
        for (String n : keywordsIn)
            this.keywords.add(n); 

    }
    public void setNumberItems(int numItemsIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("Book setNumberItems ");
            System.out.println("numItemsIn = " + numItemsIn);
        }

        this.numberItems = numItemsIn;
    }

    public void setPerson(String personIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("Book setPerson ");
            System.out.println("personIn = " + personIn);
        }

        this.person = personIn;
    }
  
    public void setTitle(String titleIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("Book setTitle ");
            System.out.println("titleIn = " + titleIn);
        }

        this.title = titleIn;
    }
}
