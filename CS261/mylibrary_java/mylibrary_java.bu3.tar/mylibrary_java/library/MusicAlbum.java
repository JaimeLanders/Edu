package library;
import java.util.*;

class MusicAlbum
	extends Item
{
    Set<String> members;// =  new TreeSet<>();

    public MusicAlbum()
    {
        super();

        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("MusicAlbum constructor ");

        members = null;

    }

    public String toString()
    {
        String text;

        text = "-Music Album-\n";
        text += "band: \t\t" + this.person + "\n";
        text += "# songs: \t" + this.numberItems + "\n";
        text += "members: \t";
        Iterator<String> it = this.members.iterator(); 
        while (it.hasNext())
        {
            String n = it.next();
            text += n;
            if (it.hasNext())
                text += ", " ;
        }
        text += "\n";
        text += "title: \t\t" + this.title + "\n";
        it = this.keywords.iterator(); 
        text += "keywords: \t";
        while (it.hasNext())
        {
            String n = it.next();
            text += n;
            if (it.hasNext())
                text += ", " ;
        }
        text += "\n";

        return text; 
    }

    public String[] getKeywords()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("MusicAlbum getKeywords ");

        String[] temp = this.keywords.toArray(new String[this.keywords.size()]);
        return temp;
    }

    public String[] getMembers()
    {
//        boolean debug = false;
        boolean debug = true;

        if (debug == true)
            System.out.println("MusicAlbum getMembers ");

        String[] temp = this.members.toArray(new String[this.members.size()]);
        return temp;
    }

    public int getNumberItems()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("MusicAlbum getNumberItems ");

        return this.numberItems;
    }

    public String getPerson()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("MusicAlbum getPerson ");

        return this.person;
    }

    public String getTitle()
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
            System.out.println("MusicAlbum getTitle ");

        return this.title;
    }

    public void setKeywords(String... keywordsIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("MusicAlbum setKeywords ");
            for(String n : keywordsIn)
                System.out.println("keyword = " + n);
        }

        this.keywords = new TreeSet<String>();
        for (String n : keywordsIn)
            this.keywords.add(n); 

    }

    public void setMembers(String... membersIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("MusicAlbum setMembers ");
            for(String n : membersIn)
                System.out.println("member = " + n);
            System.out.println("");
        }

        this.members = new TreeSet<String>();
        for (String n : membersIn)
            this.members.add(n); 

    }

    public void setNumberItems(int numItemsIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("MusicAlbum setNumberItems ");
            System.out.println("numItemsIn = " + numItemsIn);
        }

        this.numberItems = numItemsIn;
    }

    public void setPerson(String personIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("MusicAlbum setPerson ");
            System.out.println("personIn = " + personIn);
        }

        this.person = personIn;
    }
  
    public void setTitle(String titleIn)
    {
        boolean debug = false;
//        boolean debug = true;

        if (debug == true)
        {
            System.out.println("MusicAlbum setTitle ");
            System.out.println("titleIn = " + titleIn);
        }

        this.title = titleIn;
    }
}
