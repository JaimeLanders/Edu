This assignment includes several files:

- readme.txt 		   this file

- instructions.txt	   detailed assignment instructions

- design_questions.txt	   the design questions that must be answered for the
  			   "design" portion of this assignment. 

- MyLibrary.java  	   the main driver for this program. You must use this 
  			   for your main().

- library/*.java	   this starting java files for this assignment. See
  			   the instructions for more details on these files.

- expected.txt		   the expected results when you use the provided main.
