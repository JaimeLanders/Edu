package library;
import java.util.*;

class MusicAlbum
	extends Item
{
    Set<String> members = new TreeSet<>();     
//    List<String> keywords = new List<>();     

    private String band;
//    private String members;
    private int songNum;
    private String title;
//    private keywords; 

    public String getBand()
    {
        return this.band;
    }
    public Set getMembers()
    {
        return this.members;
    }
    public int getSongNum()
    {
        return this.songNum;
    }
    public String getTitle()
    {
        return this.title;
    }
    public void setMembers(String...membersIn)
    {
        for (String n : membersIn)
            members.add(n);            
    }
    public void setSongNum(int songNumIn)
    {
        this.songNum = songNumIn;
    }
    public void setTitle(String titleIn)
    {
        this.title = titleIn;
    }
}
