package library;
import java.util.*;

class Movie
	extends Item
{
    Set<String> cast = new TreeSet<>();     
//    List<String> keywords = new List<>();     

    private String director;
//    private String members;
    private int sceneNum;
    private String title;
//    private keywords; 

    public String getDirector()
    {
        return this.director;
    }
    public Set getCast()
    {
        return this.cast;
    }
    public int getSceneNum()
    {
        return this.sceneNum;
    }
    public String getTitle()
    {
        return this.title;
    }
    public void setCast(String...castIn)
    {
        for (String n : castIn)
            cast.add(n);            
    }
    public void setSceneNum(int sceneNumIn)
    {
        this.sceneNum = sceneNumIn;
    }
    public void setTitle(String titleIn)
    {
        this.title = titleIn;
    }
}
