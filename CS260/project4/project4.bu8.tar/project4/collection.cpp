/*******************
Privte data members:
treeNode * root;
hashNode ** table;
int treeSize;
int tableSize;

******************/

#include <iostream>
#include <cstring>
#include <fstream>
#include "collection.h"
#include "data.h"

using namespace std;


collection::collection() : capacity(DEFAULT_CAPACITY), head(NULL), root(NULL), treeSize(0), tableSize(0)
{
//	cout << "\ncollection default constuctor " << endl;

	initializeTable();
}

collection::collection(char * fileName) : capacity(DEFAULT_CAPACITY), head(NULL), root(NULL), treeSize(0), tableSize(0)
{
//	cout << "\ncollection initializer " << endl;
//	cout << "fileName = " << fileName << endl;

//	data currData;

	initializeTable();

	char name[100] = {'\0'};
	char events[100] = {'\0'};
	char number[100] = {'\0'};
	char products[100] = {'\0'};
	char tempString[100] = {'\0'};

	ifstream inFile;
	inFile.open(fileName);
	inFile.peek();

	while (!inFile.eof() && !inFile.fail())
	{
		inFile.getline(name, 100, ';');
//		cout << "name = " << name << endl;

		inFile.getline(number, 100, ';');
//		cout << "number = " << number << endl;

		inFile.getline(products, 100, ';');
//		cout << "products = " << products << endl;

		inFile.getline(events, 100, ';');
//		cout << "events = " << events << endl;

		inFile.ignore(100, '\n');

		data currData(name, number, products, events);
		insert(currData);

		inFile.peek();
	}

	inFile.close();
}

collection::collection(const collection& collectionIn) : head(collectionIn.head), root(collectionIn.root), table(collectionIn.table), capacity(collectionIn.capacity), treeSize(collectionIn.treeSize), tableSize(collectionIn.tableSize)
{
//	cout << "\ncollection copy constructor " << endl;

	copyTable(table, collectionIn.table); // Errors
	copyTree(root, collectionIn.root); //Issues with addTree

	*this = collectionIn; //Issues with addTree
}

collection::~collection()
{
//	cout << "\ncollection deconstructor " << endl;

	destroyTree(root);
	destroyTable();
}

const collection& collection::operator= (const collection& collectionIn)
{
//	cout << "\ncollection assignment overload " << endl;

	if (this != &collectionIn)
	{
		destroyTable();
		copyTable(table, collectionIn.table);
		
		destroyTree(root);
		copyTree(root, collectionIn.root);
	}

	return *this;
}


void collection::addTable(data * dataIn)
{
//	cout << "\ncollection addTable " << endl;
//	cout << "dataIn = " << dataIn << endl;

	char key[100] = {'\0'};
	char compKey[100] = {'\0'};
	dataIn->getProduct(key); // Seg faults
	int index = calculateHash(key);
//	cout << "index = " << index << endl;

	hashNode * currNode = NULL;
	hashNode * newNode = new hashNode(dataIn); 
//	cout << "newNode = " << newNode << endl;
	hashNode * prevNode = NULL;

	if (table[index] == NULL)
	{
//		cout << "index empty" << endl;
		table[index] = newNode;
//		cout << "table[index] = " << table[index] << endl;
		newNode->next = NULL;	
	}
	else
	{
//		cout << "index not empty " << endl;
	       	currNode = table[index];
//		cout << "currNode = " << currNode << endl;

		while (currNode != NULL)
		{
//			cout << "currNode = " << currNode << endl;
			currNode->vendorData->getProduct(compKey);
//			cout << "compKey = " << compKey << endl;

			if (strcmp(compKey,key) > 0 )
			{

//				cout << "newNode before currNode " << endl;
				newNode->next = currNode;

				if (prevNode != NULL)
				{
//					cout << "prevNode->next " << endl;
					prevNode->next = newNode;
					break;
				}
				else
				{
//					cout << "prevNode->next null " << endl;
					table[index] = newNode;
					break;
				}
			}
			else if (!currNode->next)
			{
//				cout << "end of index " << endl;
//				cout << "currNode->next = " << currNode->next << endl;

				currNode->next = newNode;
//				cout << "currNode->next after = " << currNode->next << endl;

				newNode->next = NULL;
//				cout << "newNode->next = " << newNode->next << endl;

				break;
			}
			else
			{
//				cout << "next " << endl;
				prevNode = currNode;
				currNode = currNode->next;
			}
		}
	}

	tableSize++;
//	cout << "tableSize = " << tableSize << endl;

	return;
}

void collection::addTree(data * dataIn)
{
//	cout << "\ncollection addTree " << endl;
//	cout << "dataIn = " << dataIn << endl;
//	cout << "root = " << root << endl;

	if (dataIn)
	{
		root = addTreeHelper(dataIn,root);
//		cout << "root return = " << root << endl;
//		cout << "root return vendorData =  treeIn <<" << root->vendorData << endl;

/*		if (root->left)
		{
			cout << "root->left return = " << root->left << endl;
			cout << "root->left->vendorData = " << root->left->vendorData << endl;

			cout << "root->left->right = " <<  root->left->right << endl;
		}

		if (root->right)
		{
			cout << "root->right return = " << root->right << endl;
			cout << "root->right->vendorData = " << root->right->vendorData << endl;
			cout << "root->right->left = " << root->right->left << endl;
			cout << "root->right->right = " << root->right->right << endl;
			
			if (root->right->right)
				cout << "root->right->right->vendorData = " << root->right->right->vendorData << endl;
		}
*/	}
	else
		return;
}

treeNode* collection::addTreeHelper(data * dataIn, treeNode*& treeIn)
{
//	cout << "\ncollection addTreeHelper " << endl;
//	cout << "dataIn = " << dataIn << endl;
//	cout << "root = " << root << endl;
//	cout << "treeIn = " << treeIn << endl;

	treeNode * currTree = NULL;

	char compStringA[100] = {'\0'};
	char compStringB[100] = {'\0'};

	if (!root)
	{
//		cout << "new tree " << endl;
		root = new treeNode(dataIn);
	//	cout << "+++root = " << root << "+++ " <<  endl;
		root->left = NULL;
		root->right = NULL;
		treeSize++;
//		cout << "treeSize = " << treeSize << endl;
		return root;
	}
	else
	{
//		cout << "Adding to tree " << endl;
		currTree = treeIn;
//		cout << "currTree = " << currTree << endl;
//		cout << "adding to tree " << endl;

		if (!currTree)
		{
//			cout << "leaf " << endl;
			currTree = new treeNode(dataIn);
//			cout << "currTree = " << currTree << endl;
//			cout << "dataIn = " << dataIn << endl;
			currTree->left = NULL;
			currTree->right = NULL;
//			cout << "currTree->left = " << currTree->right << endl;
//			cout << "currTree->right = " << currTree->right << endl;
			treeSize++;
//			cout << "treeSize = " << treeSize << endl;
//			cout << "currTree vendorData = " << currTree->vendorData << endl;
			return currTree;
		}
		else
		{
//			cout << "not leaf " << endl;

			data * currData = currTree->vendorData;
//			cout << "currData = " << currData << endl;

			dataIn->getName(compStringA);
			currData->getName(compStringB);
//			cout << "compStringA = " << compStringA << endl;
//			cout << "compStringB = " << compStringB << endl;

			if (strcmp(compStringA,compStringB) < 0)
			{
//				cout << "left " << endl;
				currTree->left = addTreeHelper(dataIn,currTree->left);
//				setRightChild(currTree, currTree->right); 

			}	
			else
			{
//				cout << "right " << endl;
				currTree->right = addTreeHelper(dataIn,currTree->right);
//				setLefttChild(currTree, currTree->left); 
			}

		}
	}
//			cout << "root = " << root << endl;
//			return root;
//			return currTree;
}

int collection::calculateHash(char * key) const
{
//	cout << "\ncollection calculateHash " << endl;
//	cout << "capacity = " << capacity << endl; 

	char * temp = key;
	int total = 0;

	while (*temp)
	{
		total = total + *temp;
		temp++;
	}

//	cout << "hash = " << total%capacity << endl;
	return total%capacity;
}

void collection::copyTable(hashNode ** newTable, hashNode ** tableIn)
{ 
//	cout << "\ncollection copyTable " << endl;
//	cout << "capacity = " << capacity << endl;

	newTable = new hashNode*[capacity];

	for (int i = 0; i < capacity; i++)
	{
		if (tableIn[i] == NULL)
		{
			newTable[i] = NULL;
		}
		else
		{
			newTable[i] = new hashNode(tableIn[i]->vendorData);
			hashNode * srcNode = tableIn[i]->next;
			hashNode * destNode = newTable[i];

			while (srcNode)
			{
				destNode->next = new hashNode(srcNode->vendorData);
				destNode = destNode->next;
				srcNode = srcNode->next;
			}

			destNode->next = NULL;
		}
	}
}

void collection::copyTree(treeNode *& newRoot, treeNode * treeIn)
{
//	cout << "\ncollection copyTree " << endl;

	if (treeIn)
	{
//		cout << "treeIn = " << treeIn << endl;
//		cout << "treeIn vendorData = " << treeIn->vendorData << endl;
		newRoot = new treeNode(treeIn->vendorData);
//		cout << "newRoot = " << newRoot << endl;
//		cout << "newRoot vendorData = " << newRoot->vendorData << endl;
		if (treeIn->left)
		{
//			cout << "left " << endl;
			copyTree(newRoot->left, treeIn->left);
		}
		if (treeIn->right)
		{
//			cout << "right " << endl;
			copyTree(newRoot->right, treeIn->right);
		}
	}
	else
	{
		newRoot = NULL;
	}
}

treeNode* collection::deleteNode(treeNode *& treeIn)
{
//	cout << "\ndeleteNode " << endl;
//	cout << "root = " << root << endl;
//	cout << "treeIn = " << treeIn << endl;
//	cout << "treeIn->left = " << treeIn->left << endl;
//	cout << "treeIn->right = " << treeIn->right << endl;

	treeNode * currNode = treeIn;
	treeNode * prevNode = NULL;

	data * currData;

	if (!treeIn)
	{
//		cout << "empty tree " << endl;
		return NULL;
	}
	else if (!treeIn->right && !treeIn->left)
	{
//		cout << "leaf " << endl;
//		delete treeIn->vendorData;
		delete treeIn;
		treeIn = NULL;
		return treeIn; 
	}
	else if (!treeIn->right)
	{
//		cout << "left child only " << endl; 
		currNode = treeIn->left;
//		delete treeIn->vendorData;
		delete treeIn;
		treeIn = NULL;
		return currNode; 
	}
	else if (!treeIn->left)
	{
//		cout << "right child only " << endl; 
		currNode = treeIn->right;
//		delete treeIn->vendorData;
		delete treeIn;
		treeIn = NULL;
		return currNode; 
	}
	else
	{
//		cout << "left and right children " << endl;
		currNode = treeIn->right;
		prevNode = NULL;
		while (currNode->left) // Find in-order successor
		{
			prevNode = currNode;
			currNode = currNode->left;
		}

		treeIn->vendorData = currNode->vendorData;
//		cout << "treeIn->vendorData = " << treeIn->vendorData << endl;

		if (!prevNode)
		{
			treeIn->right = currNode->right;
                }
                else
                {
                        prevNode->left = currNode->right;
                }

		currNode->right = NULL;

// 	 	delete currNode->vendorData;
	    	delete currNode;
		return treeIn;
	}

	treeSize--;

//	return root;
	
}
	
void collection::destroyTable()
{
//	cout << "\ncollection destroyTable " << endl;
//	cout << "capacity = " << capacity << endl;

	for (int i = 0; i < capacity; i++)
	{
		cout << "i = " << i << endl;

		hashNode * head = table[i];
		hashNode * currNode = NULL; 

		while(head)
		{
			cout << "head " << endl;
			currNode = head->next;
			head->next = NULL;
//			delete head->vendorData; // Valgrind errors
			delete head;
			head = currNode;
		}
	}

	delete [] table;
}

void collection::destroyTree(treeNode *& root)
{
//	cout << "\ncollection destroyTree " << endl;

	if (root)
	{
		destroyTree(root->left);
		destroyTree(root->right);
//		delete root->vendorData;
		delete root;
		root = NULL;
	}
}

void collection::displayName() 
{
//	cout << "\ncollection displayName " << endl;
//	cout << "Vendor data by name: " << endl;
//	cout << "root = " << root << endl;
//	cout << "Vendor data by name: " << endl;
	
	displayNameHelper(root);
}

void collection::displayNameHelper(treeNode * treeIn)
{
//	cout << "collection displayNameHelper " << endl;
//	cout << "treeIn = " << treeIn << endl;

	if (treeIn)
	{
		if (treeIn->left)
		{
//			cout << "left " << endl;
			displayNameHelper(treeIn->left);
		}
//
		data * tempData = treeIn->vendorData;
		cout << *tempData << endl;
//		cout << treeIn->vendorData << endl;

		if (treeIn->right)
		{

//			cout << "right " << endl;
			displayNameHelper(treeIn->right);
		}
	}
}

void collection::displayProduct(void) const
{
//	cout << "\ncollection displayProduct " << endl;
//	cout << "capacity = " << capacity << endl;
//	cout << "table = " << table << endl;

	hashNode * currNode = NULL;
//	cout << "currNode vendorData  = " << currNode->vendorData << endl;

//	cout << "Vendor data by product: " << endl;

	for(int i = 0; i < capacity; i++)
	{
//		cout << "i = " << i << endl;

		for(currNode = table[i]; currNode; currNode = currNode->next) // Seg faults
		{
			data * tempData = currNode->vendorData;
//			cout << "currNode = " << currNode << endl;
//			cout << currNode->vendorData << endl;
			cout << *tempData << endl;
		}
	}
}

int collection::getTreeSize()
{
//	cout << "\ncollection getTreeSize " << endl;
	return treeSize;
}

int collection::getTableSize()
{
//	cout << "\ncollection getHashSize " << endl;

	return tableSize;
}

void collection::initializeTable()
{
//	cout << "\ncollection initializeTable " << endl; 
//	cout << "capacity = " << capacity << endl;

	table = new hashNode*[capacity];
//	cout << "+++table = " << table << "+++" << endl;

	for (int i = 0; i < capacity; i++)
	{
		table[i] = NULL;
	}
}

void collection::insert(const data& dataIn)
{
//	cout << "\ncollection insert" << endl;
//	cout << "dataIn = " << dataIn << endl;

	char tempChar[100] = {'\0'};

	data * newData = new data(dataIn);
//	*newData = dataIn; 
//	cout << "newData = " << newData << endl;

	addTree(newData);
//	cout << "check " << endl;
	addTable(newData);
}

bool collection::remove(char * nameIn)
{
//	cout << "\ncollection remove " << endl;
//	cout << "nameIn = " << nameIn << endl;

	bool delStatus = false;

	root = removeTree(root,nameIn,delStatus);

//	cout << "delStatus return = " << delStatus << endl;

/*	if (root->left)
	{
		cout << "root->left return = " << root->left << endl;
		cout << "root->left->left = " << root->left->left << endl;
		cout << "root->left->right = " <<  root->left->right << endl;
	}

	if (root->right)
	{
		cout << "root return data = " << root->vendorData << endl;
		cout << "root->right->left = " << root->right->left << endl;
		cout << "root->right->right = " << root->right->right << endl;
	}
*/
	if (delStatus)
	{
		return true;
	}
	else
		return false;
}

bool collection::removeTable(char * productIn)
{
	cout << "\ncollection removeTable " << endl;
//	cout << "productIn = " << productIn << endl;

	int index = calculateHash(productIn);

	hashNode * currNode = table[index];
	hashNode * prevNode = NULL;
	char product[100] = {'\0'};

	while(currNode)
	{
		currNode->vendorData->getProduct(product);

		if (strcmp(productIn, product) == 0)
		{
			if (!prevNode)
			{
				table[index] = currNode->next;
			}
			else
			{
				prevNode->next = currNode->next;
			}

			currNode->next = NULL;
//			delete currNode->vendorData;
			delete currNode;

			tableSize--;
//			cout << "tableSize = " << tableSize << endl;

			return true;
		}
		else
		{
			prevNode = currNode;
			currNode = currNode->next;
		}
	}

	return false;
}

treeNode* collection::removeTree(treeNode*& treeIn, char * nameIn, bool& delStatusIn)
{
//	cout << "\ncollection removeTree " << endl;
//	cout << "root = " << root << endl;
//	cout << "treeIn = " << treeIn << endl;
//	cout << "nameIn = " << nameIn << endl;
//	cout << "delStatusIn = " << delStatusIn << endl;

	char name[100] = {'\0'};
	char product[100] = {'\0'};

	if(!treeIn)
	{
//		cout << "!treeIn " << endl;
		delStatusIn = false;
		return NULL;
	}
	else
	{
		treeIn->vendorData->getName(name);
//		cout << "name = " << name << endl;

		int temp = strcmp(name, nameIn);
//		cout << "temp = " << temp << endl;

		if(temp == 0)
		{
//			cout << "match " << endl;

			treeIn->vendorData->getProduct(product);
//			cout << "product = " << product << endl;
			removeTable(product);

			if (treeIn == root)
			{
//				cout << "treeIn = root " << endl;
				root = deleteNode(treeIn);
			}
			else
				treeIn = deleteNode(treeIn);

			delStatusIn = true;
			return treeIn;
		}
		else if(temp < 0)
		{
//			cout << "right " << endl;

			treeIn->right = removeTree(treeIn->right, nameIn, delStatusIn);
			return treeIn;
		}
		else
		{
//			cout << "left " << endl;

			treeIn->left = removeTree(treeIn->left, nameIn, delStatusIn);
			return treeIn;
		}
	}

//	cout << "root = " << root << endl;
//	return root;
}

int collection::retrieveProduct(data dataRtn[], char * productIn, int dataItemsRtn) const
{
//	cout << "\ncollection retrieveProduct " << endl;
//	cout << "productIn = " << productIn << endl;
//	cout << "dataItemsRtn " << dataItemsRtn << endl;

	int dataItems = 0;

	int strCmp = 0;
	char compString[100] = {'0'};

	int index = calculateHash(productIn);
	cout << "index = " << index << endl;
	int i = 0;

	hashNode * currNode = table[index];

	if (currNode)
	{
		while (currNode)
		{
//			cout << "currNode = " << currNode << endl;
			data * tempData = currNode->vendorData;

			dataRtn[dataItems] = *tempData;
//			dataRtn[dataItems] = currNode->vendorData;
			dataItems++;
//			cout << "dataItems = " <<  dataItems << endl;
			currNode = currNode->next;
		}

		dataItemsRtn = dataItems;
//		cout << "dataItemsRtn " << dataItemsRtn << endl;

		return dataItems;
	}
	else
		return 0;

}

bool collection::retrieveName(data& dataRtn, char * nameIn) const
{
//	cout << "\ncollection retrieveName " << endl;
//	cout << "root = " << root << endl;
//	cout << "dataRtn = " << dataRtn << endl; // Seg faults without reference

	return retrieveNameHelper(root, dataRtn, nameIn);
}

bool collection::retrieveNameHelper(treeNode * treeIn, data& dataRtn, char * nameIn) const
{
//	cout << "\ncollection retrieveNameHelper " << endl;
//	cout << "treeIn = " << treeIn << endl;
//	cout << "dataRtn = " << dataRtn << endl; // Seg faults without reference
//	cout << "nameIn = " << nameIn << endl;

	char name[100] = {'\0'};

	if(!treeIn)
	{
//		cout << "!treeIn " << endl;
		return false;
	}
	else
	{
//		cout << "treeIn " << endl;
		treeIn->vendorData->getName(name);
//		cout << "name = " << name << endl;

		int temp = strcmp(name, nameIn);
//		cout << "temp = " << temp << endl;

		if(temp == 0)
		{
//			cout << "match " << endl;
//			cout << "vendorData = " << treeIn->vendorData << endl;
			data * tempData = treeIn->vendorData;
			dataRtn = *tempData;
//			dataRtn = treeIn->vendorData;
//			cout << "dataRtn " << dataRtn << endl;
			return true;
		}
		else if(temp < 0)
		{
//			cout << "right " << endl;
			return retrieveNameHelper(treeIn->right, dataRtn, nameIn);
		}
		else
		{
//			cout << "left " << endl;
			return retrieveNameHelper(treeIn->left, dataRtn, nameIn);
		}
	}

}

void collection::writeOut (char * fileName)
{
//	cout << "collection writeOut " << endl; 

	char events[100] = {'\0'};
	char name[100] = {'\0'};
	char number[100] = {'\0'};
	char products[100] = {'\0'};

	hashNode * currNode;

	ofstream outFile;
	outFile.open(fileName);

	for(int i = 0; i < capacity; i++)
	{
		for(currNode = table[i]; currNode; currNode = currNode->next)
		{
			currNode->vendorData->getName(name);
			currNode->vendorData->getNumber(number);
			currNode->vendorData->getProduct(products);
			currNode->vendorData->getEvents(events);

			outFile << name << ";";
			outFile << number << ";";
			outFile << products << ";";
			outFile << events << ";";
			outFile << '\n';
		}
	}

	outFile.close();
}

void collection::setRightChild(treeNode * treeIn, treeNode * childIn)
{
//	cout << "\ncollection setRightChild " << endl;
//	cout << "treeIn = " << treeIn << endl;
//	cout << "childIn = " << childIn << endl;

	treeIn->right = childIn;
//	cout << "right = " << right << endl;
}

void collection::setLeftChild(treeNode * treeIn, treeNode * childIn)
{
//	cout << "\ncollection setLeftChild " << endl;
//	cout << "treeIn = " << treeIn << endl;
//	cout << "childIn = " << childIn << endl;

	treeIn->left = childIn;
//	cout << "left = " << left << endl;
}
