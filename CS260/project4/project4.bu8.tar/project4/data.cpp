/*
// Private Data Members:
	char * vendorName;
	int * phoneNumber;
	char * productType;
	char * eventNotes;  
*/
#include <cstring>
#include "data.h" 

using namespace std;

data::data():vendorName(NULL), phoneNumber(NULL), productType(NULL), eventNotes(NULL)
{
//	cout << "\ndata default constructor " << endl;

	vendorName = {'\0'};
	phoneNumber = {'\0'}; 
	productType = {'\0'};
	eventNotes = {'\0'};  
}

data::data(const data& dataIn):vendorName(NULL), phoneNumber(NULL), productType(NULL), eventNotes(NULL)
{
//	cout << "\ndata copy constructor " << endl;

	setName(dataIn.vendorName);
	setNumber(dataIn.phoneNumber);
	setProduct(dataIn.productType);
	setEvents(dataIn.eventNotes);
}

data::data(char * vendorNameIn, char * phoneNumberIn, char * productTypeIn, char * eventTypeIn):vendorName(NULL), phoneNumber(NULL), productType(NULL), eventNotes(NULL)
{
//	cout << "\ndata input constructor " << endl;

	setName(vendorNameIn);
	setNumber(phoneNumberIn);
	setProduct(productTypeIn);
	setEvents(eventTypeIn);
}

data& data::operator=(const data& dataIn)
{
//	cout << "\ndata assignment operator overload " << endl;

	if (this != &dataIn)
	{
		setName(dataIn.vendorName);
		setNumber(dataIn.phoneNumber);
		setProduct(dataIn.productType);
		setEvents(dataIn.eventNotes);
	}

	return *this;
}

ostream& operator<<(ostream& out, const data& dataIn)
{
//	cout << "\n<< overload " << endl;
	out << dataIn.vendorName << '\t' << dataIn.phoneNumber << '\t' << dataIn.productType << '\t' << dataIn.eventNotes << '\t' << endl;   

	return out;
}
data::~data()
{
//	cout << "\ndata deconstructor " << endl;

	if (vendorName)
		delete [] vendorName;
	if (phoneNumber)
		delete [] phoneNumber;
	if (productType)
		delete [] productType;
	if (eventNotes)
		delete [] eventNotes;

//	clear();

}

void data::clear()
{
//	cout << "\ndata clear " << endl;

//	if(this)
//	{
	if (vendorName)
		delete [] vendorName;
	if (phoneNumber)
		delete [] phoneNumber;
	if (productType)
		delete [] productType;
	if (eventNotes)
		delete [] eventNotes;
//	}
}

void data::getName(char * nameIn)const
{
//	nout << "\ngetName " << endl;

	strcpy(nameIn, this->vendorName);
//	cout << "nameIn = " << nameIn << endl;
}

int data::getNumber(char * numIn)const
//int data::getNumber()const
{
//	cout << "\ngetNumber " << endl;
	
	strcpy(numIn, this->phoneNumber);
//	return phoneNumber;
}

void data::getProduct(char * productIn)const
{
//	cout << "\ngetProduct " << endl;

	strcpy(productIn, this->productType);
}

void data::getEvents(char * eventIn)const
{
//	cout << "\ngetEvents " << endl;

	strcpy(eventIn, this->eventNotes);
}

void data::setName(const char * nameIn)
{
//	cout << "\nsetName " << endl;
//	cout << "nameIn = " << nameIn << endl;

	if (this->vendorName)
	{
//		cout << "delete this->vendorName " << endl;
		delete [] this->vendorName;
	}

	this->vendorName = new char[strlen(nameIn)+1];
	strcpy(this->vendorName, nameIn);
}

void data::setNumber(const char * numIn)
{
//	cout << "\nsetNumber " << endl;
//	cout << "numIn = " << numIn << endl;

	if (this->phoneNumber)
	{
//		cout << "delete this->phoneNumber " << endl;
		delete [] this->phoneNumber;
	}

	this->phoneNumber = new char[strlen(numIn)+1];
	strcpy(this->phoneNumber, numIn);
}

void data::setProduct(const char * productIn)
{
//	cout << "\nsetProduct " << endl;
//	cout << "productIn = " << productIn << endl;

	if(this->productType)
	{
//		cout << "delete this->productType " << endl;
		delete [] this->productType;
	}

	this->productType = new char[strlen(productIn)+1];
	strcpy(this->productType, productIn);
}

void data::setEvents(const char * eventIn)
{
//	cout << "\nsetEvents " << endl;
//	cout << "eventIn = " << eventIn << endl;

	if(this->eventNotes)
	{
//		cout << "delete this->eventNotes " << endl;
		delete [] this->eventNotes;
	}

	this->eventNotes = new char[strlen(eventIn)+1];
	strcpy(this->eventNotes, eventIn);
}
