#ifndef COLLECTION_H
#define COLLECTION_H

#include <iostream>
#include "data.h"

using namespace std;

struct treeNode
{
	data * vendorData;
	treeNode * left;
	treeNode * right;

	treeNode(data * dataIn)
	{
//		cout << "\ntreeNode copy constructor " << endl;
		vendorData = dataIn;
//		cout << "vendorData = " << vendorData << endl;
		left = NULL;
		right = NULL;
	}
};

struct hashNode
{
	data * vendorData;
	hashNode * next;

	hashNode(data * dataIn)
	{
//		cout << "\nhashNode copy constructor " << endl;
		vendorData = dataIn;
//		cout << "vendorData = " << vendorData << endl;
		next = NULL;
	}
};

struct node
	{
		data * vendorData;
		node * next;
		
		node(data * dataIn)
		{
//			cout << "\nnode copy constructor " << endl;
			vendorData = dataIn;
			next = NULL;
		}	
	};

class collection 
{
	node * head;
	treeNode * root;
	hashNode ** table;
	int tableSize;
	int treeSize;
	int capacity;
	const static int DEFAULT_CAPACITY = 11;

	void addTable(data * dataIn);
	void addTree(data * dataIn);
	treeNode* addTreeHelper(data * dataIn, treeNode *& treeIn);
//	treeNode* addTreeHelper(data * dataIn, treeNode *& root);
//	void addTreeHelper(data * dataIn, treeNode *& root);
//	void addTreeHelper(data * dataIn, treeNode *& treeIn);
	int calculateHash(char * key) const;
	void copyTable(hashNode *& newTable, hashNode * tableIn);
	void copyTree(treeNode *& newRoot, treeNode * treeIn);
	treeNode* deleteNode(treeNode *& root);
//	void deleteNode(treeNode *& treeIn);
	void destroyTable();
	void destroyTree(treeNode *& treeIn);
//	void destroyTree(treeNode *& root);
	void displayNameHelper(treeNode * treeIn);
//	void displayNameHelper(treeNode * treeIn) const;
	void initializeTable();
	bool removeTable(char * nameIn);
	treeNode* removeTree(treeNode*& treeIn, char * nameIn, bool& delStatusIn);
//	treeNode* removeTree(treeNode*& root, char * nameIn);
//	bool removeTree(treeNode*& root, char * nameIn);
	bool removeTree(treeNode * treeIn, char * nameIn);
	bool retrieveNameHelper(treeNode * treeIn, data& dataRtn, char * nameIn) const;
//	bool retrieveNameHelper(treeNode * treeIn, data * dataRtn, char * nameIn) const;
public:
	collection();
	collection(char * fileName);
	collection(const collection&);
	const collection& operator= (const collection&);
	~collection();
	void displayName();
//	void displayName(void) const;
	void displayProduct(void) const;
	int getTableSize();
	int getTreeSize();
	void insert(const data&);
	void monitor(); // Needs built
	bool remove(char * nameIn);
	int retrieveProduct(data dataRtn[], char * productIn, int dataItemsRtn) const;
//	bool retrieveProduct(hashNode * searchNode, char * productIn) const;
//	bool retrieveProduct(node * searchNode, char * productIn) const;
//	bool retrieveProduct(data& dataRtn, char * productIn) const;
//	bool retrieveProduct(data * dataRtn, char * productIn) const;
	bool retrieveName(data& dataIn, char * nameIn) const;
//	bool retrieveName(data * dataIn, char * nameIn) const;
	void writeOut(char * fileName);
}; 

#endif
