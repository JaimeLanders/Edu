#include <cstring>
#include <iomanip>
#include <iostream>
#include "data.h"

using namespace std;

data::data ()
{
//	cout << "\ndata default constructor " << endl;

	tickerSymbol = {'\0'};
	stockName = {'\0'};
	assetValue = 0.0;
	dateValue = {'\0'};
	ytdReturn = 0.0;
} 

data::~data ()
{
//	cout << "\ndata deconstructor " << endl;

	if (tickerSymbol)
		delete [] tickerSymbol; // Valgrind: Invalid read error
	if (stockName)
		delete [] stockName;
	if (dateValue)
		delete [] dateValue;
} 

data::data(const data& dataIn)
{
//	cout << "data copy constructor " << endl;

	setTicker(dataIn.tickerSymbol);
	setName(dataIn.stockName);
	setValue(dataIn.assetValue);
	setDate(dataIn.dateValue);
	setReturn(dataIn.ytdReturn);
}

const data& data::operator=(const data& dataIn)
{
//	cout << "data = overload " << endl;

	if (this != &dataIn)
	{
		setTicker(dataIn.tickerSymbol);
		setName(dataIn.stockName);
		setValue(dataIn.assetValue);
		setDate(dataIn.dateValue);
		setReturn(dataIn.ytdReturn);
	}

	return *this;
}

ostream& operator<< (ostream& out, const data& dataIn)
{
//	cout << "\n<< overload " << endl;
//	cout << "dataIn address = " << &dataIn << endl;

out << showpoint << setprecision(4) << dataIn.tickerSymbol << "\t\t" << dataIn.stockName << "\t" << "$" << dataIn.assetValue << "\t"<< dataIn.dateValue << "\t" << dataIn.ytdReturn << "%" << endl;
//	cout << "<< check " << endl;
	return out;
}

void data::getDate (char * dateValue) const
{
//	cout << "\ngetDate " << endl;
//	cout << "dateValue = " << this->dateValue << endl;

	strcpy(dateValue, this->dateValue);
}

void data::getName (char * stockName) const
{
//	cout << "\ngetName " << endl;
//	cout << "stockName = " << this->stockName << endl;

	strcpy(stockName, this->stockName);
}

float data::getReturn (void) const
{
//	cout << "\ngetReturn " << endl;

	return ytdReturn;
}

void data::getTicker (char * tickerSymbol) const
{
//	cout << "\ngetTicker " << endl;
//	cout << "tickerSymbol = " << this->tickerSymbol << endl;

	strcpy(tickerSymbol, this->tickerSymbol);
}

float data::getValue (void) const
{
//	cout << "\ngetValue " << endl;

	return assetValue;
}

bool data::setDate (const char * dateIn)
{
//	cout << "\nsetDate " << endl;
//	cout << "dateIn = " << dateIn << endl;

	if (this->dateValue)
	{
//		cout << "delete dateValue " << endl;
		delete [] this->dateValue;
	}

	dateValue = new char[strlen(dateIn)+1]; 
	strcpy (dateValue, dateIn);	
//	cout << "dateValue = " << dateValue << endl;

	return 0;
}

bool data::setName (const char * nameIn)
{
//	cout << "\nsetName " << endl;
//	cout << "nameIn = " << nameIn << endl;

	if (this->stockName)
	{
//		cout << "delete stockName " << endl;
		delete [] this->stockName;
	}

	stockName = new char[strlen(nameIn)+1]; 
	strcpy (stockName, nameIn);	
//	cout << "stockName = " << stockName << endl;

	return 0;
}

bool data::setReturn (const float returnIn)
{
//	cout << "\nsetReturn " << endl;
//	cout << "returnIn = " << returnIn << endl;

	ytdReturn = returnIn;
//	cout << "ytdReturn = " << ytdReturn << endl;

	return 0;
}

bool data::setTicker (const char * tickerIn)
{
//	cout << "\nsetTicker " << endl;
//	cout << "tickerIn = " << tickerIn << endl;

//	cout << "check " << endl;

	if (this->tickerSymbol) // Valgrind: Use of uninitialized value error
	{
//		cout << "delete tickerSymbol " << endl;
		delete [] this->tickerSymbol;
	}

	this->tickerSymbol = new char[strlen(tickerIn)+1]; 
	strcpy (this->tickerSymbol, tickerIn);	
//	cout << "tickerSymbol = " << this->tickerSymbol << endl;

	return 0;
}

bool data::setValue (const float valueIn)
{
//	cout << "\nsetValue " << endl;
//	cout << "valueIn = " << valueIn << endl;

	assetValue = valueIn;
//	cout << "assetValue = " << assetValue << endl;

	return 0;
}

