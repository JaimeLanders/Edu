#ifndef linkedqueue_h
#define linkedqueue_h

using namespace std;

#include "data.h"
//#include "linkedstack.h"

//template <class ItemType>
class queue 
{
//friend class stack;
private:
	struct node
	{
		data queueHouse; // Stores house object
		node * next; // Stores next pointer
	};
	node * front;  // Stores front of queue 
//	data * front;  // Stores front of queue 
	node * end;  // Stores end of queue 
//	data * end;  // Stores end of queue 
	int queueNum; // Stores number of items in queue; 
public:
	queue(char * fileName); // Default constructor
//	queue(); // Default constructor
	~queue(); // Deconstructor
	queue(const queue& queueIn); // Copy constructor
	const queue& operator =(const queue& queueIn); // Assignment Overload
	bool dequeue(data& houseIn); // Remove item from front of queue 
//	bool dequeue(data * houseIn); // Remove item from front of queue 
//	bool dequeue(data houseIn); // Remove item from front of queue 
//	void display(node& houseIn) const; // Display item in queue  
//	void display(node * houseIn) const; // Display item in queue  
//	void display(data * houseIn) const; // Display item in queue  
	void display(data& houseIn) const; // Display item in queue  
//	void display(); // Display entire queue 
	void displayAll() const; // Display entire queue 
	void enqueue(const data& houseIn); // Store new item at end of queue 
//	void enqueue(const data * houseIn); // Store new item at end of queue 
//	void enqueue(data * houseIn); // Store new item at end of queue 
//	void enqueue(); // Store new item at end of queue 
	bool isEmpty() const; // Checks if queue is empty
//	data& peek() const; // Returns pointer to front of queue  
//	node* peek() const; // Returns pointer to front of queue  
	bool peek(data& houseIn) const; // Returns pointer to front of queue  
//	data* peek() const; // Returns pointer to front of queue  
//	const data* peek(); // View front item without modifying 
//	void peek(); // View front item without modifying 
};

#endif
