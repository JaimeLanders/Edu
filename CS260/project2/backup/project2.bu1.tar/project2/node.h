#ifndef "node_h"
#define "node_h"

#include "data.h"

class node
{
	data * head; // Stores head of linkedlist
	int nodeNum; // Stores number of items in linkedlist

public:
	node(); // Default constructor
	bool isEmpty() // Returns true if empty, false if not
	data* void getHead(); // Gets head of linkedlist
	void setHead(); // Sets head of linkedlist
}

#endif
