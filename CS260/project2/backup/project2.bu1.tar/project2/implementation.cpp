#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>

using namespace std;

#include "data.h"
#include "linkedstack.h"
#include "linkedqueue.h"

data::data() // Data default constructor
{
	cout << "\ndata default constructor " << endl;

//	head = NULL;
	next = NULL;
	address = {'\0'};
	squareFeet = 0;
	roomCount = 0;
	bathCount = 0.0;
	notes = {'\0'};
}

data::data(const data& houseIn) // Data copy constructor
{
	cout << "\ndata copy constructor " << endl;
//	cout << "houseIn = " << houseIn << endl;
	next = houseIn.next;
	address = houseIn.address;
	squareFeet = houseIn.squareFeet;
	roomCount = houseIn.roomCount;
	bathCount = houseIn.bathCount;
	notes = houseIn.notes;
}

data* data::operator=(const data& houseIn)
//data::operator=(const data& houseIn)
{
	cout << "\ndata = operator overload " << endl;
/*
	if (this != &houseIn)
	{
		this->clear();
		next = houseIn.next;
		address = houseIn.address;
		squareFeet = houseIn.squareFeet;
		roomCount = houseIn.roomCount;
		bathCount = houseIn.bathCount;
		notes = houseIn.notes;
	}

	return this;
*/}

ostream& operator<<(ostream& outputStream, const data& houseIn)
{
	cout << "\n<< overload " << endl;
//	cout << "houseIn = " << houseIn << endl;

	outputStream << houseIn.getAddress() << ", " ; 
	outputStream << houseIn.getSquareFeet() << ", " ; 
	outputStream << houseIn.getRoomCount() << ", " ; 
	outputStream << houseIn.getBathCount() << ", " ; 
	outputStream << houseIn.getNotes() << endl; 

	return outputStream;
}

data::~data() // Data deconstructor
{
	cout << "\ndata deconstructor " << endl;

/*	while (this != NULL)
	{
	next = NULL;
	address = {'\0'};
	squareFeet = 0;
	roomCount = 0;
	bathCount = 0.0;
	notes = {'\0'};

	delete this;
	}
*/}

void data::clear()
{
	cout << "data clear " << endl;

	next = NULL;
	address = {'\0'};
	squareFeet = 0;
	roomCount = 0;
	bathCount = 0.0;
	notes = {'\0'};

	delete this;

	return;
}

data* data::getNext() const
//data* data::getNext(data * houseIn)
{
//	cout << "\ndata getNext " << endl;
//	cout << "houseIn = " << houseIn << endl;
//	cout << "this = " << this << endl;
	
	return next;
//	return this->next;
//	return houseIn->next;
}

char* data::getAddress () const
//char* data::getAddress (data * houseIn)
{
//	cout << "\ndata getAddress " << endl;

	return address;
//	return this->address;
//	return houseIn->address;
}

int data::getSquareFeet () const
//int data::getSquareFeet (data * houseIn)
{
//	cout << "\ndata getSquareFeet " << endl;

	return squareFeet;
//	return this->squareFeet;
//	return houseIn->squareFeet;
}
int data::getRoomCount () const
//int data::getRoomCount (data * houseIn)
{
//	cout << "\ndata getRoomCount " << endl;

	return roomCount;
//	return this->roomCount;
//	return houseIn->roomCount;
}
int data::getBathCount () const
//int data::getBathCount (data * houseIn)
{
//	cout << "\ndata getBathCount " << endl;

	return bathCount;
//	return this->bathCount;
//	return houseIn->bathCount;
}
char * data::getNotes () const
//char * data::getNotes (data * houseIn)
{
//	cout << "\ndata getNotes " << endl;

	return notes;
//	return this->notes;
//	return houseIn->notes;
}

//void data::setAddress(data& houseIn, char tempString[])
void data::setAddress(char tempStringIn[])
//void data::setAddress(data * houseIn, char tempString[])
{
	cout << "\ndata setAddress " << endl;
//	cout << "houseIn = " << houseIn << endl;
//	cout << "address = " << address << end;
	int stringSize = strlen(tempStringIn);
//	cout << "stringSize = " << stringSize << endl;
//	houseIn->address = address;
//	houseIn->address = new char[stringSize + 1]

//	houseIn.address = new char[stringSize + 1]; 
	address = new char[stringSize + 1]; 
//	houseIn->address = new char[stringSize + 1]; 
//	strncpy(houseIn.address, tempString, stringSize);
	strncpy(address, tempStringIn, stringSize);
//	strncpy(houseIn->address, tempString, stringSize);
//	houseIn.address[stringSize] = '\0';
	address[stringSize] = '\0';
//	houseIn->address[stringSize] = '\0';
//	cout << "address = " << houseIn.address << endl;
	cout << "address = " << address << endl;
//	cout << "address = " << houseIn->address << endl;

	return;
}

void data::setBathCount(float bathCountIn)
//void data::setBathCount(data * houseIn, float bathCount)
{
	cout << "\ndata setBathCount " << endl;
//	cout << "houseIn = " << houseIn << endl;
	bathCount = bathCountIn;
//	houseIn->bathCount = bathCount;
//	cout << "bathCount = " << houseIn->bathCount << endl;
}

//void data::setNext(data& nextIn)
//void data::setNext(data& houseIn, data * nextIn)
void data::setNext(data * nextIn)
//void data::setNext(data * houseIn, data * nextIn)
{
	cout << "\ndata setNext " << endl;
//	cout << "houseIn = " << houseIn << endl;
	cout << "nextIn = " << nextIn << endl;

//	houseIn.next = nextIn;
//	next = &nextIn;
	next = nextIn;
//	houseIn->next = nextIn;
//	cout << "next = " << houseIn.next << endl;
	cout << "next = " << next << endl;
//	cout << "next = " << houseIn->next << endl;

	return;
}

void data::setNotes(char tempStringIn[])
//void data::setNotes(data * houseIn, char tempString[])
{
	cout << "\ndata setNote " << endl;
//	cout << "houseIn = " << houseIn << endl;

	int stringSize = strlen(tempStringIn);
//	cout << "stringSize = " << stringSize << endl;

	notes = new char[stringSize + 1]; 
//	houseIn->notes = new char[stringSize + 1]; 
	strncpy(notes, tempStringIn, stringSize);
//	strncpy(houseIn->notes, tempString, stringSize);
	notes[stringSize] = '\0';
//	houseIn->notes[stringSize] = '\0';
//	cout << "notes = " << houseIn->notes << endl;
}

void data::setRoomCount(int roomCountIn)
//void data::setRoomCount(data * houseIn, int roomCount)
{
	cout << "\ndata setRoomCount " << endl;
//	cout << "houseIn = " << houseIn << endl;
	roomCount = roomCountIn;
//	houseIn->roomCount = roomCount;
//	cout << "roomCount = " << houseIn->roomCount << endl;
}

void data::setSquareFeet(int squareFeetIn)
//void data::setSquareFeet(data * houseIn, int squareFeet)
{
	cout << "\ndata setSquareFeet " << endl;
//	cout << "houseIn = " << houseIn << endl;
	squareFeet = squareFeetIn;
//	houseIn->squareFeet = squareFeet;
//	cout << "squareFeet = " << houseIn->squareFeet << endl;
}

queue::queue(char * fileName) // Queue default constructor
//queue::queue() // Queue default constructor
{
	cout << "\nqueue default constructor " << endl;
	cout << "fileName = " << fileName << endl;

	front = NULL;
	end = NULL;
//	next = NULL;
	queueNum = 0;

	char charEat = '\0';
	char tempString[100] = {'\0'};
	float tempFloat = 0.0;
	int tempInt = 0;
//	int stringSize = 0;
//	int i = 0;

	ifstream inFile;	
	inFile.open(fileName);
	inFile.peek();

	while(!inFile.eof() && !inFile.fail())
	{
		data n;
//		data * n = new data;
//		cout << "n = " << n << endl;
		inFile.getline(tempString,100,';');
//		cout << "tempString = " << tempString << endl;

//		stringSize = strlen(tempString);
//		cout << "stringSize = " << stringSize << endl;
		n.setAddress(tempString);
//		n->setAddress(n, tempString);
//		n->address = new char[stringSize + 1]; 
//		strncpy(n->address, tempString, stringSize);
//		n->address[stringSize] = '\0';
//		cout << "address = " << n->address << endl;
//		tempString = '\0';
//		stringSize = 0;

//		inFile >> charEat; 
		inFile >> tempInt;
		n.setSquareFeet(tempInt);
//		n->setSquareFeet(n, tempInt);
//		inFile >> n->squareFeet;
//		cout << "squareFootage = " << n->squareFootage << endl;	
		inFile >> charEat; 
		inFile >> tempInt;
		n.setRoomCount(tempInt);
//		n->setRoomCount(n, tempInt);
//		inFile >> n->roomCount;
//		cout << "roomCount = " << n->roomCount << endl;	
		inFile >> charEat; 
		inFile >> tempFloat;
		n.setBathCount(tempFloat);
//		n->setBathCount(n, tempFloat);
//		inFile >> n->bathCount;
//		cout << "bathCount = " << n->bathCount << endl;	
		inFile >> charEat; 

		inFile.getline(tempString,100);
//		cout << "tempString = " << tempString << endl;
//		stringSize = strlen(tempString);
//		cout << "stringSize = " << stringSize << endl;
		n.setNotes(tempString);
//		n->setNotes(n, tempString);
//		n->notes = new char[stringSize + 1]; 
//		strncpy(n->notes, tempString, stringSize);
//		n->notes[stringSize] = '\0';
//		cout << "notes = " << n->notes << endl;
//		tempString = '\0';
//		stringSize = 0;

		inFile.peek();

		enqueue (n);
		cout << "check " << endl;

//		enqueue (n);

//		delete n;

	} // Closes while

	cout << "front = " << front << endl;

} // Closes data constructor 

queue::~queue() // Queue deconstructor
{
	cout << "\nqueue deconstructor " << endl;
}  

bool queue::dequeue(data& houseIn)
//bool queue::dequeue(data * houseIn)
//bool queue::dequeue(data houseIn)
{
	cout << "\nqueue dequeue " << endl;

	if (!isEmpty())
	{
		cout << "front dequeued " << endl;
		front = front->getNext();
//		front = front->getNext(front);
//		front = front->next;
		cout << "front = " << front << endl;

		queueNum--;
		cout << "queueNum = " << queueNum << endl;

		return true;
	}
	else
	{
		cout << "queue empty " << endl;

		return false;
	}

} // Closes queue dequeue

//void queue::display(data& houseIn) const
void queue::display(data * houseIn) const
//void queue::display()
{
	cout << "\nqueue display " << endl;
	cout << "houseIn = " << houseIn << endl;

	if (!isEmpty())
	{
		cout << "not empty" << endl;
		cout << "\nAddress: \t" << houseIn->getAddress() << endl;
		cout << "Square Feet: \t" << houseIn->getSquareFeet() << endl;
		cout << "Bedrooms: \t" << houseIn->getRoomCount() << endl;
		cout << "Bathrooms: \t" << houseIn->getBathCount() << endl;
		cout << "Notes: \t\t" << houseIn->getNotes() << endl;
		cout << "\n===== " << endl;
	}
	else
		cout << "empty" << endl;
	
	return;
} // Closes queue display all

void queue::displayAll() const
{
	cout << "\nqueue displayAll " << endl;

//	data current = front; 
//	data * current = end; 
	data * current = front; 
	cout << "current = " << current << endl;

//	while(!isEmpty())
	while(current != NULL) 
	{
		display(current);
//		current = next;
		current = current->getNext();
//		current = current->getNext(current);
		cout << "current = " << current << endl;
//		current = current->next;
	}

	return;

} // Closes queue display all

void queue::enqueue(const data& houseIn)
//void queue::enqueue(const data * houseIn)
//void queue::enqueue(data * houseIn)
{
	cout << "\nqueue enqueue " << endl;
//	cout << "houseIn = "  << houseIn << endl;

//	data n = data(houseIn);
	data * n = new data(houseIn);
//	data n;// = new data; 
//	n = houseIn;
//	data n = houseIn;
//	data * n = houseIn;
	cout << "n = " << &n << endl;

	if (isEmpty()) // Queue empty
//		if (front == NULL) // Queue empty
		{
			cout << "new queue " << endl;
//			front = &n;
			front = n;
//			end = &n;
			end = n;
//			next = NULL;
//			n.setNext(NULL);
			n->setNext(NULL);
			queueNum++;
			cout << "front = " << front << endl;
			cout << "queueNum = " << queueNum << endl;
		}
		else // End of queue
		{
			cout << "end of queue " << endl;
//			data * current = front;
//			end->setNext(&n);
			end->setNext(n);
//			end = &n;
			end = n;
//			end = end->getNext();
			end->setNext(NULL);
			cout << "end = " << end << endl;

//			data * current = end;

//			while (next != NULL)
/*			while (current->getNext() != NULL)
//			while (current->getNext(current) != NULL)
//			while (current->next != NULL)
			{
				current = current->getNext();
//				current = current->getNext(current);
//				current = next;
//				current = current->next;
			} // Closes while

//			next = n;
			current->setNext(&n);
//			current->setNext(n);
//			current->setNext(current,n);
//			current->next = n;
			end = &n;
//			end = n;
//			next = NULL;
			n.setNext(NULL);
//			n->setNext(NULL);
//			n->setNext(n,NULL);
//			n->next = NULL;

*/			queueNum++;
			cout << "queueNum = " << queueNum << endl;
		}

		cout << "check " << endl;
	return;
}

bool queue::isEmpty() const
{
//	cout << "\nqueue isEmpty" << endl;

	if (front == NULL)
		return true; 
	else
		return false;
}

//const data* queue::peek()
//data& queue::peek() const
data* queue::peek() const
//void queue::peek()
{
	cout << "\nqueue peek " << endl;
//	cout << "front = " << front << endl;

	if (!isEmpty())
	{
		return front;
	}
//	else
//		return NULL;

//	return;
}

/*void queue::setNext(data * houseIn)
{
	cout << "\nqueue setNext " << endl;
	cout << "houseIn = " << houseIn << endl;

//	data * current;   
//	current->setNext(current,houseIn);
//	current->next = houseIn;

	return;
}
*/
stack::stack() // Stack default constructor
{
	cout << "\nstack default constructor " << endl;

	top = NULL;
//	next = NULL;
}  

stack::~stack() // Stack deconstructor
{
	cout << "\nstack deconstructor " << endl;
}

void stack::display(data * houseIn) const
{
	cout << "\nstack display " << endl;
	if (!isEmpty())
	{
		cout << "\nAddress: \t" << houseIn->getAddress() << endl;
		cout << "Square Feet: \t" << houseIn->getSquareFeet() << endl;
		cout << "Bedrooms: \t" << houseIn->getRoomCount() << endl;
		cout << "Bathrooms: \t" << houseIn->getBathCount() << endl;
		cout << "Notes: \t\t" << houseIn->getNotes() << endl;
		cout << "\n===== " << endl;
	}
} // Closes stack display

bool stack::isEmpty() const
{
//	cout << "\nstack isEmpty " << endl;

	if (top == NULL)
		return true; 
	else
		return false;
}

//data stack::peek() const
data* stack::peek() const
//void stack::peek()
{
	cout << "\nstack peek " << endl;

 	if (!isEmpty())
		return top;
	else
		return NULL;
}

//bool stack::pop(data& houseIn)
bool stack::pop(data * houseIn)
//bool stack::pop(data houseIn)
{
	cout << "\nstack pop " << endl;

//	top = houseIn.getNext();
	top = houseIn->getNext();

	stackNum--;
	cout << "stackNum = " << stackNum << endl;

	return 0;
}

//bool stack::push(data& houseIn)
//bool stack::push(const data * houseIn)
bool stack::push(data * houseIn)
//bool stack::push(data houseIn)
{
	cout << "\nstack push " << endl;
//	cout << "houseIn = " << houseIn << endl;
//	cout << "this = " << this << endl;
//	cout << "front = " << front << endl;

	if (isEmpty())
	{
		cout << "new stack " << endl;
		top = houseIn;
		top->setNext(NULL);
//		top->setNext(top,NULL);
//		top->next = NULL;
		cout << "top = " << top << endl;

		return true;
	}
	else 
	{
		cout << "top " << endl;
		houseIn->setNext(top);
//		houseIn->setNext(houseIn,top);
//		houseIn->next = top;
		top = houseIn;
		cout << "top = " << top << endl;

		return true;

/*		while (current->next != NULL)
		{
			current = current->next;
		}

		top = current;
*/	}

	return false;
}

//void stack::setNext(data * houseIn)
/*void stack::setNext(data * houseIn)
{
	cout << "\nstack setNext " << endl;

	return;
}
*/
