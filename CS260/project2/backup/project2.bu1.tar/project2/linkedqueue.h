#ifndef linkedqueue_h
#define linkedqueue_h

using namespace std;

#include "data.h"
#include "linkedstack.h"

//template <class ItemType>
class queue 
{
friend class stack;
private:
	data * front;  // Stores front of queue 
	data * end;  // Stores end of queue 
	int queueNum; // Stores number of items in queue; 
public:
	queue(char * fileName); // Default constructor
//	queue(); // Default constructor
	~queue(); // Deconstructor
	bool dequeue(data& houseIn); // Remove item from front of queue 
//	bool dequeue(data * houseIn); // Remove item from front of queue 
//	bool dequeue(data houseIn); // Remove item from front of queue 
//	void display(data& houseIn) const; // Display item in queue  
	void display(data * houseIn) const; // Display item in queue  
//	void display(); // Display entire queue 
	void displayAll() const; // Display entire queue 
	void enqueue(const data& houseIn); // Store new item at end of queue 
//	void enqueue(const data * houseIn); // Store new item at end of queue 
//	void enqueue(data * houseIn); // Store new item at end of queue 
//	void enqueue(); // Store new item at end of queue 
	bool isEmpty() const; // Checks if queue is empty
//	data& peek() const; // Returns pointer to front of queue  
	data* peek() const; // Returns pointer to front of queue  
//	const data* peek(); // View front item without modifying 
//	void peek(); // View front item without modifying 
};

#endif
