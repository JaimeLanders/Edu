/*
TODO:

1) Setup data types
	a. data.h
	b. linkedqueue.h
	c. linkedstack.h
2) 
3)
4)
5)

*/

#ifndef data_h
#define data_h

using namespace std;

//#include "linkedqueue.h"
//#include "linkedstack.h"

//template<class itemType>
class data 
{
//	data * head; // Head pointer
	char * address; // Stores adress
	int squareFeet; // Stores square footage
	int roomCount; // Stores number of rooms
	float bathCount; // Stores number of bathrooms
	char * notes; // Special notes/features about house
	data * next; // Next pointer
public:
	data (); // Default constructor
	data (const data&  houseIn); // Copy constructor
//	data& operator=(const data&); // Assignment overload
	data* operator=(const data&); // Assignment overload
//	template<class friendItemType> 
	friend ostream& operator<<(ostream& outputStream, const data& houseIn); // Output stream overload
	~data (); // Deconstructor
	void clear (); // Clears data
	char* getAddress () const;
	int getSquareFeet () const;
	int getRoomCount () const;
	int getBathCount () const;
	data* getNext () const;
	char * getNotes () const;
//	void setAddress (data& houseIn, char tempString[]);
	void setAddress (char tempString[]);
//	void setAddress (data * houseIn, char tempString[]);
	void setSquareFeet (int squareFeet);
//	void setSquareFeet (data * houseIn, int squareFeet);
	void setRoomCount (int roomCount);
//	void setRoomCount (data * houseIn, int roomCount);
	void setBathCount (float bathCount);
//	void setBathCount (data * houseIn, float bathCount);
//	void setNext (data& houseIn, data * nextIn);
//	void setNext (data& nextIn);
	void setNext (data * nextIn);
//	void setNext (data * houseIn, data * nextIn);
	void setNotes (char tempString[]);
//	void setNotes (data * houseIn, char tempString[]);
};

#endif
