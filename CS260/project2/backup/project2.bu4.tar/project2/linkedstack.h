#ifndef linkedstack_h
#define linkedstack_h

using namespace std;

#include "data.h"
#include "linkedqueue.h"

//template <class ItemType>
class stack
{
friend class queue;
private:
	struct node
	{
		data stackHouse;
		node * next; // Stores next item in stack 
	};	
	node * top; // Stores top of stack
	int stackNum; // Stores number of itmes in stack
public:
	stack(); // Default constructor
	~stack(); // Deconstructor
//	void display(data& houseIn) const; // Display item in stack
	void display(data * houseIn) const; // Display item in stack
	bool isEmpty() const; // Checks if stack is empty
//	data peek() const; // Return top of stack  
	bool peek(data& houseIn) const; // Return top of stack  
//	data* peek() const; // Return top of stack  
//	void peek(); // Return top of stack  
	bool pop(data& houseIn); // Store new item on stack
//	bool pop(data * houseIn); // Store new item on stack
//	bool pop(data houseIn); // Store new item on stack
	bool push(const data& houseIn); // Store new item on stack
//	bool push(data * houseIn); // Store new item on stack
//	bool push(data houseIn); // Store new item on stack
//	void setNext(data * houseIn); // Sets next pointer
//	void setNext(data houseIn); // Sets next pointer
};

#endif
