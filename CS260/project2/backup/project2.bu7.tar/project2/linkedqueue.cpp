#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>

using namespace std;

//#include "data.h"
//#include "linkedstack.h"
#include "linkedqueue.h"

queue::queue(char * fileName) // Queue default constructor
//queue::queue() // Queue default constructor
{
//	cout << "\nqueue default constructor " << endl;
//	cout << "fileName = " << fileName << endl;

	front = NULL;
	end = NULL;
//	next = NULL;
	queueNum = 0;

	char charEat = '\0';
	char tempString[100] = {'\0'};
	char * passString = {'\0'};
	float tempFloat = 0.0;
	int tempInt = 0;
	int stringSize = 0;
//	int i = 0;

	ifstream inFile;	
	inFile.open(fileName);
	inFile.peek();

	while(!inFile.eof() && !inFile.fail())
	{
		data n;
//		data * n = new data;
//		cout << "n = " << n << endl;
		inFile.getline(tempString,100,';');
//		cout << "tempString = " << tempString << endl;
//		stringSize = strlen(tempString);
//		cout << "stringSize = " << stringSize << endl;
//		passString = new char[stringSize + 1];
//		strncpy(passString, tempString, stringSize);
//		passString[stringSize] = '\0';
//		n.setAddress(passString);
		n.setAddress(tempString);

//		n->setAddress(n, tempString);
//		n->address = new char[stringSize + 1]; 
//		strncpy(n->address, tempString, stringSize);
//		n->address[stringSize] = '\0';
//		cout << "address = " << n->address << endl;
//		delete [] passString;
//		passString = '\0';
//		tempString = '\0';
//		stringSize = 0;

//		inFile >> charEat; 
		inFile >> tempInt;
		n.setSquareFeet(tempInt);
//		n->setSquareFeet(n, tempInt);
//		inFile >> n->squareFeet;
//		cout << "squareFootage = " << n->squareFootage << endl;	
		inFile >> charEat; 
		inFile >> tempInt;
		n.setRoomCount(tempInt);
//		n->setRoomCount(n, tempInt);
//		inFile >> n->roomCount;
//		cout << "roomCount = " << n->roomCount << endl;	
		inFile >> charEat; 
		inFile >> tempFloat;
		n.setBathCount(tempFloat);
//		n->setBathCount(n, tempFloat);
//		inFile >> n->bathCount;
//		cout << "bathCount = " << n->bathCount << endl;	
		inFile >> charEat; 

		inFile.getline(tempString,100);
//		passString = new char[strlen(tempString) + 1]
//		passString = new char[stringSize + 1];
//		strncpy(passString, tempString, stringSize);
//		passString[stringSize] = '\0';

//		strcpy(passString, tempString);
//		cout << "tempString = " << tempString << endl;
//		stringSize = strlen(tempString);
//		cout << "stringSize = " << stringSize << endl;
//		n.setNotes(passString);
		n.setNotes(tempString);
//		n->setNotes(n, tempString);
//		n->notes = new char[stringSize + 1]; 
//		strncpy(n->notes, tempString, stringSize);
//		n->notes[stringSize] = '\0';
//		cout << "notes = " << n->notes << endl;
//		tempString = '\0';
		passString = '\0';
//		stringSize = 0;
//		delete [] passString;

		inFile.peek();

		enqueue (n);
//		n.clear();

//		cout << "check " << endl;

//		enqueue (n);

//		delete n;

	} // Closes while

//	cout << "front = " << front << endl;

} // Closes data constructor 

queue::queue(const queue& queueIn)
{
//	cout << "queue copy constructor " << endl;
//	cout << "queueIn = " << queueIn << endl;
	if (queueIn.front == NULL)
	{
		front = NULL;
		end = NULL;
	}
	else
	{
		front = new node;
		front->queueHouse = queueIn.front->queueHouse;

		node * dest = front;
		node * source = queueIn.front->next;

		while (source != NULL)
		{
			dest->next = new node;
			dest = dest->next;
			dest->queueHouse = source->queueHouse;

			source = source->next;
		}

		dest->next = NULL;

		end = dest;
	}
}

const queue& queue::operator =(const queue& queueIn)
{
//	cout << " queue assignment overload " << endl;
//	cout << "queueIn = " << queueIn << endl;
	if (this != &queueIn)
	{
		return *this;
	}
	else
	{
		node * current = front;

		while(front)
		{
			current = front->next;
			delete front;
			front = current;
		}

		if (queueIn.front == NULL)
		{
			front = NULL;
			end = NULL;
		}
		else
		{
			front = new node;
			front->queueHouse = queueIn.front->queueHouse;

			node * dest = front;
			node * source = queueIn.front->next;
			while(source != NULL)
			{
				dest->next = new node;
				dest = dest->next;
				dest->queueHouse = source->queueHouse;

				source = source->next;
			}
			dest->next = NULL;

			end = dest;
		}

		return * this;

	}
}


queue::~queue() // Queue deconstructor
{
//	cout << "\nqueue deconstructor " << endl;

	node * current = front;

//	if (current != NULL)
	while (front)
//	while (current != NULL)
	{
		current = front->next;
//		front->queueHouse.clear(); // Fix?
//		delete [] front->queueHouse.address;
		delete front;	
		front = current;
	}

	front = end = NULL;
}  

bool queue::dequeue(data& houseIn)
//bool queue::dequeue(data * houseIn)
//bool queue::dequeue(data houseIn)
{
//	cout << "\nqueue dequeue " << endl;

	if (!isEmpty())
	{
//		cout << "front dequeued " << endl;
		node * temp = front;
//		data * temp = front;
//		node * temp;
//	       	temp->queueHouse = front;
//		front = front->getNext();
//		front = front->getNext(front);
		front = front->next;
//		temp.setNext(NULL);
//		temp->setNext(NULL);
		houseIn = temp->queueHouse;
//		temp->queueHouse.clear(); // Fix?
//		delete [] temp->queueHouse.address;
		delete temp; //Valgrind errors
//		cout << "front = " << front << endl;

		queueNum--;
//		cout << "queueNum = " << queueNum << endl;

		return true;
	}
	else
	{
//		cout << "queue empty " << endl;

		return false;
	}

} // Closes queue dequeue

//void queue::display(node& houseIn) const
//void queue::display(node * houseIn) const
//void queue::display(data * houseIn) const
void queue::display(data& houseIn) const
//void queue::display()
{
//	cout << "\nqueue display " << endl;
//	cout << "houseIn = " << houseIn << endl;

	if (!isEmpty())
	{
//		cout << "not empty" << endl;
		cout << "Address: \t" << houseIn.getAddress() << endl;
//		cout << "\nAddress: \t" << houseIn->getAddress() << endl;
		cout << "Square Feet: \t" << houseIn.getSquareFeet() << endl;
//		cout << "Square Feet: \t" << houseIn->getSquareFeet() << endl;
		cout << "Bedrooms: \t" << houseIn.getRoomCount() << endl;
//		cout << "Bedrooms: \t" << houseIn->getRoomCount() << endl;
		cout << "Bathrooms: \t" << houseIn.getBathCount() << endl;
//		cout << "Bathrooms: \t" << houseIn->getBathCount() << endl;
		cout << "Notes: \t\t" << houseIn.getNotes() << endl;
//		cout << "Notes: \t\t" << houseIn->getNotes() << endl;
		cout << "\n===== " << endl;
	}
//	else
//		cout << "empty" << endl;
	
	return;
} // Closes queue display all

void queue::displayAll() const
{
//	cout << "\nqueue displayAll " << endl;

//	data current = front; 
//	data * current = end; 
	node *  current = front; 
//	data * current = front; 
//	cout << "current = " << current << endl;

//	while(!isEmpty())
	while(current != NULL) 
	{
		cout << current->queueHouse << endl;
//		display(current);
		current = current->next;
//		current = current->getNext();
//		current = current->getNext(current);
//		cout << "current = " << current << endl;
//		current = current->next;
	}

	return;

} // Closes queue display all

void queue::enqueue(const data& houseIn)
//void queue::enqueue(const data * houseIn)
//void queue::enqueue(data * houseIn)
{
//	cout << "\nqueue enqueue " << endl;
//	cout << "houseIn = "  << houseIn << endl;

//	data * n = new data(houseIn);
	node * n = new node();
	n->queueHouse = houseIn;
	n->next = NULL;
//	n = houseIn;
//	data * n = new data(houseIn);
//	data n;// = new data; 
//	n = houseIn;
//	data n = houseIn;
//	data * n = houseIn;
//	cout << "n = " << &n << endl;

	if (isEmpty()) // Queue empty
//		if (front == NULL) // Queue empty
		{
//			cout << "new queue " << endl;
			front = n;
//			front = n;
//			end = &n;
			end = n;
//			n->next = NULL;
//			n.setNext(NULL);
//			n->setNext(NULL);
			queueNum++;
//			cout << "front = " << front << endl;
//			cout << "queueNum = " << queueNum << endl;
		}
		else // End of queue
		{
//			cout << "end of queue " << endl;
//			data * current = front;
			end->next = n; 
//			end->setNext(&n);
//			end->setNext(n);
//			end = &n;
			end = n;
//			end = end->getNext();
//			end->next = NULL;
//			end->setNext(NULL);
//			cout << "end = " << end << endl;

//			data * current = end;

//			while (next != NULL)
/*			while (current->getNext() != NULL)
//			while (current->getNext(current) != NULL)
//			while (current->next != NULL)
			{
				current = current->getNext();
//				current = current->getNext(current);
//				current = next;
//				current = current->next;
			} // Closes while

//			next = n;
			current->setNext(&n);
//			current->setNext(n);
//			current->setNext(current,n);
//			current->next = n;
			end = &n;
//			end = n;
//			next = NULL;
			n.setNext(NULL);
//			n->setNext(NULL);
//			n->setNext(n,NULL);
//			n->next = NULL;

*/			queueNum++;
//			cout << "queueNum = " << queueNum << endl;
		}

//		cout << "check " << endl;
	return;
}

bool queue::isEmpty() const
{
//	cout << "\nqueue isEmpty" << endl;

	if (front == NULL)
		return true; 
	else
		return false;
}

//const data* queue::peek()
//data& queue::peek() const
bool queue::peek (data& houseIn) const
//data* queue::peek() const
//void queue::peek()
{
//	cout << "\nqueue peek " << endl;
//	cout << "front = " << front << endl;

	if (!isEmpty())
	{
		houseIn = front->queueHouse; 
		return true;
//		return front;
	}
//	else
//		return NULL;

//	return;
}

/*void queue::setNext(data * houseIn)
{
	cout << "\nqueue setNext " << endl;
	cout << "houseIn = " << houseIn << endl;

//	data * current;   
//	current->setNext(current,houseIn);
//	current->next = houseIn;

	return;
}
*/
