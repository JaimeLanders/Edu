#include <cstring>
#include <iomanip>
#include <iostream>
#include <fstream>

using namespace std;

//#include "data.h"
#include "linkedstack.h"
//#include "linkedqueue.h"

stack::stack() // Stack default constructor
{
//	cout << "\nstack default constructor " << endl;

	top = NULL;
//	next = NULL;
	stackNum = 0;
}  

stack::stack(const stack& stackIn)
{ 
//	cout << "stack copy constructor " << endl;

	if (stackIn.top == NULL)
	{
		top = NULL;
	}
	else
	{
		top = new node;
		top->stackHouse = stackIn.top->stackHouse;

		node * dest = top;
		node * source = stackIn.top->next;
		while (source != NULL)
		{
			dest->next = new node;
			dest = dest->next;
			dest->stackHouse = source->stackHouse;
			source = source->next;
		}
		dest->next = NULL;
	}
}

const stack& stack::operator= (const stack& stackIn)
{
//	cout << "assignment overload " << endl;

	if (this == &stackIn)
	{
		return *this;
	}
	else
	{
		node * current = top;

		while(top)
		{
			current = top->next;
			delete top;
			top = current;
		}

		if (stackIn.top == NULL)
		{
			top = NULL;
		}
		else
		{
			top = new node;
			top->stackHouse = stackIn.top->stackHouse;

			node * dest = top;
			node * source = stackIn.top->next;
			while(source != NULL)
			{
				dest->next = new node;
				dest = dest->next;
				dest->stackHouse = source->stackHouse;

				source = source->next;
			}
			dest->next = NULL;
		}

		return *this;
	}
}

stack::~stack() // Stack deconstructor
{
//	cout << "\nstack deconstructor " << endl;

	node * current = top;

	while (current != NULL)
	{
		current = current->next;
		top->next = NULL;
//		top->stackHouse.clear(); // Fix?
		delete top;
		top = current;
	}
}

void stack::display(data * houseIn) const
{
//	cout << "\nstack display " << endl;
	if (!isEmpty())
	{
		cout << "\nAddress: \t" << houseIn->getAddress() << endl;
		cout << "Square Feet: \t" << houseIn->getSquareFeet() << endl;
		cout << "Bedrooms: \t" << houseIn->getRoomCount() << endl;
		cout << "Bathrooms: \t" << houseIn->getBathCount() << endl;
		cout << "Notes: \t\t" << houseIn->getNotes() << endl;
		cout << "\n===== " << endl;
	}
} // Closes stack display

bool stack::isEmpty() const
{
//	cout << "\nstack isEmpty " << endl;

	if (top == NULL)
		return true; 
	else
		return false;
}

//data stack::peek() const
bool stack::peek(data& houseIn) const
//data* stack::peek() const
//data* stack::peek() const
//void stack::peek()
{
//	cout << "\nstack peek " << endl;

 	if (!isEmpty())
	{
		houseIn = top->stackHouse;
		return true;
//		return top;
	}
	else
		return NULL;
}

bool stack::pop(data& houseIn)
//bool stack::pop(data * houseIn)
//bool stack::pop(data houseIn)
{
//	cout << "\nstack pop " << endl;

	node * temp = top;// = new node;

	if (isEmpty())
		return false;
	else
	{
		top = top->next;
//		top = top->getNext();
	}

	if (temp != NULL)
//	if (top != NULL)
	{
		temp->next = NULL;
//		temp->stackHouse = houseIn;
		houseIn = temp->stackHouse;
//		top->stackHouse.clear(); // Fix?
		delete temp;

//		top = houseIn.getNext();
//		top = houseIn->getNext();

		stackNum--;
//		cout << "stackNum = " << stackNum << endl;

		return true;
	}
}

bool stack::push(const data& houseIn)
//bool stack::push(const data * houseIn)
//bool stack::push(data * houseIn)
//bool stack::push(data houseIn)
{
//	cout << "\nstack push " << endl;
//	cout << "houseIn = " << houseIn << endl;
//	cout << "this = " << this << endl;
//	cout << "front = " << front << endl;
	node * n = new node;//(houseIn); 
	n->stackHouse = houseIn;
	n->next = NULL;

	if (isEmpty())
	{
//		cout << "new stack " << endl;
		top = n;//ew node(houseIn);
//		top = new data(houseIn);
//		top = houseIn;
//		top->setNext(NULL);
//		top->setNext(top,NULL);
		top->next = NULL;
//		cout << "top = " << top << endl;

		stackNum++;
//		cout << "stackNum = " << stackNum << endl;

		return true;
	}
	else 
	{
//		cout << "top " << endl;
//		node * n = new node;//(houseIn); 
//		data * n = new data(houseIn); 
//		top->setNext(n);
//		top->next = n;
//		cout << "top->next = " << top->next << endl;
		n->next = top;
		top = n;
//		top->next = NULL;
//		top->setNext(NULL);
//		top->setNext(&houseIn);
//		top = new data(houseIn);
//		houseIn->setNext(top);
//		houseIn->setNext(houseIn,top);
//		houseIn->next = top;
//		top = houseIn;
//		cout << "top = " << top << endl;

		stackNum++;
//		cout << "stackNum = " << stackNum << endl;

		return true;

/*		while (current->next != NULL)
		{
			current = current->next;
		}

		top = current;
*/	}

	return false;
}

//void stack::setNext(data * houseIn)
/*void stack::setNext(data * houseIn)
{
	cout << "\nstack setNext " << endl;

	return;
}
*/
