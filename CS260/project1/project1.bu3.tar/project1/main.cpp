#include <iostream>

#include "project1.h"

using namespace std;

/*
void add(wineryOps currentOps)
//void add(wineryOps *n)
{
//	wineryOps currentOps; 	
//	cout << "nameHead = " << currentOps.nameHead << endl;

	char tempName[] = {'\0'};
	char tempLocale[] = {'\0'};
	int nameSize = 0;
	int townSize = 0;

	wineryInfo * n;
	n = new wineryInfo;
	cout << "n = " << n << endl;

	cout << "What is the name of the winery?: ";
	cin.ignore();
	cin.getline(tempName, STRINGSIZE); 
	cout << "tempName = " << tempName << endl;
	nameSize = strlen(tempName);
	cout << "nameSize = " << nameSize << endl;
	n->wineryName = tempName;
	n->wineryName[nameSize] = '\0';
	cout << "wineryName = " << n->wineryName << endl;

	cout << "Where is the winery located (city)?: ";
	cin.ignore();
	cin.getline(tempLocale, STRINGSIZE);
	cout << "tempLocale = " << tempLocale << endl;
	townSize = strlen(tempLocale);
	cout << "townSize = " << townSize << endl;
	n->wineryLocale = tempLocale;
	n->wineryLocale[townSize] = '\0';
	cout << "wineryLocale = " << n->wineryLocale << endl;

	cout << "What is the year the winery started?: ";
	cin.ignore();
	cin  >> n->wineryYear; 
	cout << "wineryYear = " << n->wineryYear << endl;

	cout << "How many acres is the winery ?: ";
	cin.ignore();
	cin >> n->wineryAcres;
	cout << "wineryAcres = " << n->wineryAcres << endl;

	cout << "What is the overall success rating of the winery?: ";
	cin.ignore();
	cin >> n->wineryRating;
	cout << "wineryRating = " << n->wineryRating << endl;

	currentOps.addWinery(n);
}
*/
int main ()
{
	wineryOps currentOps; 	
//	wineryOps currentOps2(currentOps);  // For testing copy constructor 	

	cout << "check " << endl;

	currentOps.loadFile();

	char userChoice = '\0';
/*	char tempName[] = {'\0'};
	char tempLocale[] = {'\0'};
	int nameSize = 0;
	int townSize = 0;
*/
/*	wineryInfo * n;
	n = new wineryInfo;
	cout << "n = " << n << endl;
*/
	cout << "Welcome to Winery Tracker 1.0! " << endl;

	while (userChoice != 'x')
	{
		cout << "\nChoose from the following menu: " << endl;

		cout << "\na) Add a new winery " << endl;
		cout << "d) Delete a winery " << endl;
		cout << "n) Display wineries by name " << endl;
		cout << "r) Display wineries by rating " << endl;
		cout << "s) Search wineries by name " << endl;
		cout << "x) Exit program and save changes " << endl; 

		cout << "\nSelection: ";
		cin >> userChoice;
//		cout << "userChoice = " << userChoice << endl;

		if (userChoice == 'a')
		{
//			add (currentOps);
//
//			cout << "rateHead = " << rateHead << endl;
//			cout << "nameHead = " << nameHead << endl;

			wineryInfo * n;
			n = new wineryInfo;
			cout << "n = " << n << endl;

			char tempName[STRINGSIZE] = {'\0'};
			char tempLocale[STRINGSIZE] = {'\0'};
			int nameSize = 0;
			int townSize = 0;
//			int userNum = 0;

			cout << "What is the name of the winery?: ";
//			cin.ignore();
			cin.ignore(200, '\n');
			cin.getline(tempName, STRINGSIZE); 
			cout << "tempName = " << tempName << endl;
			nameSize = strlen(tempName);
			cout << "nameSize = " << nameSize << endl;
			n->wineryName = new char[nameSize + 1];
			strncpy(n->wineryName, tempName, nameSize);
			n->wineryName[nameSize] = '\0';
//			cout.clear();
			cout << "wineryName = " << n->wineryName << endl;

			cout << "Where is the winery located (city)?: ";
//			cin.ignore();
//			cin.ignore(200, '\n');
			cin.getline(tempLocale, STRINGSIZE);
			cout << "tempLocale = " << tempLocale << endl;
			townSize = strlen(tempLocale);
			cout << "townSize = " << townSize << endl;
			n->wineryLocale = new char[townSize + 1];
			strncpy(n->wineryLocale, tempLocale, townSize);
			n->wineryLocale[townSize] = '\0';
//			cout.clear();
			cout << "wineryLocale = " << n->wineryLocale << endl;

			cout << "What is the year the winery started?: ";
			cin >> n->wineryYear; 
//			cin.ignore();
			cin.ignore(200, '\n');
			cout << "wineryYear = " << n->wineryYear << endl;

			cout << "How many acres is the winery ?: ";
			cin >> n->wineryAcres;
//			cin.ignore();
			cin.ignore(200, '\n');
			cout << "wineryAcres = " << n->wineryAcres << endl;

			cout << "What is the overall success rating of the winery?: ";
			cin >> n->wineryRating;
//			cin.ignore();
			cin.ignore(200, '\n');
			cout << "wineryRating = " << n->wineryRating << endl;

			currentOps.addWinery(n);
		}
		else if (userChoice == 'd')
		{
			cout << "Name of winery to delete: " ;
			char delName[STRINGSIZE] = {'\0'};

			cin.ignore();
			cin.getline(delName, STRINGSIZE);
			cout << "delName = " << delName << endl;

			currentOps.deleteWinery(delName);
		}
		else if (userChoice == 'n')
		{
			currentOps.viewByName();
		}
		else if (userChoice == 'r')
		{
			currentOps.viewByRating();
		}
		else if (userChoice == 's')
		{
			cout << "Name of winery to search: " ;
			char searchName[STRINGSIZE] = {'\0'};

			cin.ignore();
			cin.getline(searchName, STRINGSIZE);
			cout << "searchName = " << searchName << endl;

			currentOps.searchName(searchName);
		}
		else if (userChoice == 'x')
		{
			cout << "\nGoodbye!" << endl;

			currentOps.saveFile();
		}
		else
		{
			cout << "\nYou did not enter a valid selection, try again... " << endl;
		}

//		cout << "\n===== " << endl;

	} // Closes while loop


	return 0;
}
