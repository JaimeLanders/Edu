#include "project1.h" 

wineryInfo::wineryInfo()
{
	cout << "wineryInfo Default Constructor " << endl;

	wineryName = NULL;
	wineryLocale = NULL;
	wineryYear = 0;
	wineryAcres = 0;
	wineryRating = 0;
	nextName = NULL;
	nextRating = NULL;

	cout << "check " << endl;
}

wineryInfo::wineryInfo(const wineryInfo& source )
{
	cout << "wineryInfo Copy Constructor " << endl;

}

wineryInfo& wineryInfo::operator=(const wineryInfo& source)
{
	cout << "wineryInfo overloaded = operator " << endl;
}

wineryOps::wineryOps()
{
	cout << "wineryOps Default Constructor " << endl;

	nameHead = NULL;
	cout << "nameHead = " << nameHead << endl;

	rateHead = NULL;
	cout << "rateHead = " << rateHead << endl;

//	wineryName = NULL;
//	wineryLocale = NULL;

}

wineryOps::wineryOps(const wineryOps& source)
{

	cout << "wineryOps Copy Constructor " << endl;

	wineryInfo * curChain;
	curChain = nameHead;
//	wineryOps * current;
//    	current->nameHead = nameHead;

	if (curChain == NULL)
	{
		nameHead = NULL;
		rateHead = NULL;

		return;
	}
	else
	{
		nameHead = new wineryInfo();    
		nameHead->nextName = curChain->nextName;
		rateHead->nextRating = curChain->nextRating;

		wineryInfo * curChain;
		wineryInfo * newChain;
//		wineryOps * n;
		curChain = curChain->nextName;
		newChain = nameHead;

		while (curChain != NULL)
		{
			wineryInfo *nextName = curChain->nextName;
			wineryInfo *nextRating = curChain->nextRating;
			wineryInfo * n;
			n = new wineryInfo;

			newChain = newChain->nextName;
			curChain = curChain->nextName;
		}

		newChain->nextName = NULL;
	}

}

wineryOps& wineryOps::operator=(const wineryOps& source)
{
	cout << "wineryOps Overloaded = Operator " << endl;

	if (this != &source)
	{
		wineryInfo * current; 
		current = nameHead;

		while (current != NULL)
		{
			current = current->nextName;
			delete nameHead;
			nameHead = current;
		}

		if (source.nameHead == NULL)
		{
			nameHead = NULL;
			rateHead = NULL;
		}
		else
		{
			nameHead = new wineryInfo;

			nameHead->wineryLocale = source.nameHead->wineryLocale;
			nameHead->wineryYear = source.nameHead->wineryYear;
			nameHead->wineryAcres = source.nameHead->wineryAcres;
			nameHead->wineryRating = source.nameHead->wineryRating;
			nameHead->wineryName = source.nameHead->wineryName;
			nameHead->nextName = source.nameHead->nextName;
			nameHead->nextRating = source.nameHead->nextRating;

//			wineryInfo * curHead;
			wineryInfo * source;
			current = nameHead;
			source = source->nextName;

			while (source != NULL)
			{
				current->nextName = new wineryInfo; 

				current = current->nextName;

				current->wineryLocale = source->wineryLocale;
				current->wineryYear = source->wineryYear;
				current->wineryAcres = source->wineryAcres;
				current->wineryRating = source->wineryRating;
				current->wineryName = source->wineryName;
				current->nextName = source->nextName;
				current->nextRating = source->nextRating;

				source = source->nextName;

			}

			current->nextName = NULL;
		}
	}

	       return *this;	

}

wineryOps::~wineryOps()
{
	cout << "\nwineryOps Deconstructor " << endl;

	wineryInfo * current;
	wineryInfo * previous;
	current = nameHead;
	previous = NULL;

	while (current != NULL)
	{
		delete[] current->wineryName;
		delete[] current->wineryLocale;
		previous = current;
		current = current->nextName;
		delete previous;
	}

}

void wineryOps::addWinery(wineryInfo * n)
{
	cout << "addWinery working" << endl;
	cout << "n = " << n << endl;
	cout << "wineryName = " << n->wineryName << endl;
	cout << "nameHead = " << nameHead << endl;
	cout << "rateHead = " << rateHead << endl;

	wineryInfo * current;
	wineryInfo * previous;
	current = NULL;
	previous = NULL;
	cout << "current = " << current << endl;

	if (rateHead == NULL) // List is empty
	{
		cout << "Creating list" << endl;
	       	rateHead = n;	
	       	rateHead->nextRating = NULL;
		cout << "rateHead = " << rateHead << endl;
	}
	else if (rateHead->wineryRating < n->wineryRating)
	{
		cout << "n is new rateHead " << endl;
		n->nextRating = rateHead;
		rateHead = n; 
	}
	else
	{
		cout << "n after rateHead" << endl;
		current = rateHead;
		previous = rateHead; 
		cout << "current = " << current << endl;

		while (current != NULL)
		{
			if (current->wineryRating < n->wineryRating)
			{
				cout << "n > current " << endl;	
				previous->nextRating = n;
				n->nextRating = current;
				break;		
			}
			else if (current->nextRating == NULL)
			{
				cout << "n is last " << endl;
				current->nextRating = n;
				n->nextRating = NULL;
				break;
			}
			else 
			{
				cout << "next rating " << endl;
				previous = current;
				current = current->nextRating;

				cout << "current = " << current << endl;
			}

		}

	}

	if (nameHead == NULL) // List is empty
	{
		cout << "Creating list" << endl;
	       	nameHead = n;	
	       	nameHead->nextName = NULL;
		cout << "nameHead = " << nameHead << endl;
	}
	else if (strcmp (n->wineryName,nameHead->wineryName) < 0 ) // N is new head
//	else if (nameHead->wineryName > n->wineryName) // N is new head
	{
		cout << "n is new nameHead " << endl;
		n->nextName = nameHead;
		nameHead = n; 
	}
	else // Insert n somewhere after head
	{
		cout << "n after nameHead" << endl;
		current = nameHead;
		previous = nameHead;

		while (current != NULL)
		{
			if (strcmp (n->wineryName,current->wineryName) < 0 )
//			if (curName->nextName != NULL && curName > n)
			{
				cout << "current > n " << endl;
				previous->nextName = n;
				n->nextName = current;
				break;		
			}
			else if (current->nextName == NULL)
			{
				cout << "n is end " << endl;
				current->nextName = n;
				n = NULL;
				break;
			}
			else
			{
				cout << "next name" << endl;
				current = current->nextName;
			}
		}
	}

	return;
}

void wineryOps::deleteWinery(char delName[STRINGSIZE])
{
	cout << "\ndeleteWinery working" << endl;
	cout << "delName passed = " << delName << endl;

	wineryInfo * current;
	wineryInfo * previous;
	current = NULL;
	previous = NULL;
	cout << "current = " << current << endl;

	if (strcmp (nameHead->wineryName,delName) == 0 && strcmp (nameHead->wineryName,delName) != 0)
	{
		cout << "nameHead deleted " << endl;

		current = nameHead;
		nameHead = nameHead->nextName;
		delete[] current->wineryName;
		delete[] current->wineryLocale;
		delete current;
	}
	else if (strcmp (rateHead->wineryName,delName) == 0 && strcmp (rateHead->wineryName,delName) != 0)
	{
		cout << "rateHead deleted " << endl;

		current = rateHead;
		rateHead = rateHead->nextRating;
		delete[] current->wineryName;
		delete[] current->wineryLocale;
		delete current;
	}
	else if (strcmp (rateHead->wineryName,delName) == 0 && strcmp (rateHead->wineryName,delName) == 0)
	{
		cout << "nameHead and rateHead deleted " << endl;

		current = nameHead;
		nameHead = nameHead->nextName;
		rateHead = rateHead->nextRating;
		delete[] current->wineryName;
		delete[] current->wineryLocale;
		delete current;
	}
	else
	{
		current = nameHead;
		previous = nameHead;

		while (current != NULL)
		{
			if (strcmp (current->wineryName,delName) == 0 )
			{
				cout << delName << " deleted " << endl;		

				previous->nextName = current->nextName;
				previous->nextRating = current->nextRating;

				delete[] current->wineryName;
				delete[] current->wineryLocale;
				delete current;
			}
			else if (current->nextName == NULL)
			{
				previous->nextName = NULL;

				delete[] current->wineryName;
				delete[] current->wineryLocale;
				delete current;
			}
			else
			{
				cout << "next " << endl;

				previous = current;
				current = current->nextName;
			}
		}
	}

	return;
}

void wineryOps::loadFile()
{
	cout << "loadFile working " << endl;

	ifstream inFile;
	inFile.open(FILENAME);
//	inFile.open("data.dat");
	inFile.peek();

	char charEat = '\0';
	char tempName[STRINGSIZE] = {'\0'};
	char tempLocale[STRINGSIZE] = {'\0'};
	int nameSize = 0;
	int townSize = 0;

	while (!inFile.fail() && !inFile.eof())
	{
//		cout << "n = " << n << endl;
		wineryInfo * n = NULL;
		n = new wineryInfo;
		cout << "n = " << n << endl;

/*		char charEat = '\0';
		char tempName[STRINGSIZE] = {'\0'};
		char tempLocale[STRINGSIZE] = {'\0'};
		int nameSize = 0;
		int townSize = 0;
*/
//		inFile.peek();
//		inFile.clear();
		inFile.getline(tempName, STRINGSIZE, ',');
		cout << "tempName = " << tempName << endl;
		nameSize = strlen(tempName);
		cout << "nameSize = " << nameSize << endl;
		n->wineryName = new char[nameSize + 1];
		strncpy(n->wineryName, tempName, nameSize);
		n->wineryName[nameSize] = '\0';
		cout << "n->wineryName = " << n->wineryName << endl;

		inFile.getline(tempLocale, STRINGSIZE, ',');
		cout << "tempLocale = " << tempLocale << endl;
		townSize = strlen(tempLocale);
		cout << "townSize = " << townSize << endl;
		n->wineryLocale = new char[townSize + 1];
		strncpy(n->wineryLocale, tempLocale, townSize);
		n->wineryLocale[townSize] = '\0';
		cout << "n->wineryLocale = " << n->wineryLocale << endl;

		inFile >> n->wineryYear;
		inFile >> charEat;
		inFile >> n->wineryAcres;
		inFile >> charEat;
		inFile >> n->wineryRating;
//		if (nameHead == NULL) // Fix for missing char
		inFile.ignore();
//		inFile >> charEat;
//		cout << "charEat =" << charEat << endl;
//		inFile.ignore(1, '\n');

		inFile.peek();

		addWinery(n);
	}
	
	inFile.close();

	return;

}

void wineryOps::saveFile()
{
	cout << "saveFile working " << endl;

	ofstream outFile;
	outFile.open(FILENAME);
//	outFile.open("data.dat");

	wineryInfo * current;
	current = nameHead;

	int stringSize = 0;
	char tempString[STRINGSIZE] = {'\0'};

	while (current != NULL)
//	while (!outFile.eof() && current != NULL)
	{
		outFile << current->wineryName << ",";
		outFile << current->wineryLocale << ",";
		outFile << current->wineryYear << ",";
		outFile << current->wineryAcres << ",";
		outFile << current->wineryRating << endl;// "," << endl;

		current = current->nextName;
	}

	outFile.close();

	return;
}

void wineryOps::viewByName()
{
	cout << "\nviewByName working" << endl;
	cout << "nameHead = " << nameHead << endl;

	wineryInfo * current;   
	current = nameHead;
	cout << "current = " << current << endl;

	while (current != NULL)
	{
		cout << "\nWinery Name: \t\t" << current->wineryName << endl;
		cout << "Winery Location: \t" << current->wineryLocale << endl;
		cout << "Winery Established: \t" << current->wineryYear << endl;
		cout << "Winery Acres: \t\t" << current->wineryAcres << endl;
		cout << "Winery Rating: \t\t" << current->wineryRating << endl;
		cout << "\n===== " << endl;

		current=current->nextName;
	}

	return;
}

void wineryOps::viewByRating()
{
	cout << "\nviewByRating working" << endl;
	cout << "rateHead = " << rateHead << endl;

	wineryInfo * current;   
	current = rateHead;
	cout << "current = " << current << endl;

	while (current != NULL)
	{
		cout << "\nWinery Name: \t\t" << current->wineryName << endl;
		cout << "Winery Location: \t" << current->wineryLocale << endl;
		cout << "Winery Established: \t" << current->wineryYear << endl;
		cout << "Winery Acres: \t\t" << current->wineryAcres << endl;
		cout << "Winery Rating: \t\t" << current->wineryRating << endl;
		cout << "\n===== " << endl;

		current=current->nextRating;
	}

	return;
}

void wineryOps::searchName(char searchName[STRINGSIZE])
{
	cout << "\nsearchName working" << endl;
	cout << "searchName = " << searchName << endl;

	wineryInfo * current;
	current = nameHead;

	bool nameFound = false;

	while (current != NULL)
	{
		if (strcmp (current->wineryName,searchName) == 0)
		{
//			cout << searchName << " found " << endl;
			 
			nameFound = true;

			break;
		}
		else
		{
			current = current->nextName;
		}
	}

	if (nameFound == true)
	{
		cout << searchName << " found " << endl;

		cout << "\nWinery Name: \t\t" << current->wineryName << endl;
		cout << "Winery Location: \t" << current->wineryLocale << endl;
		cout << "Winery Established: \t" << current->wineryYear << endl;
		cout << "Winery Acres: \t\t" << current->wineryAcres << endl;
		cout << "Winery Rating: \t\t" << current->wineryRating << endl;
		cout << "\n===== " << endl;
	}
	else
	{
		cout << searchName << " not found.. " << endl;
	}


	return;
}
