#include "linkedlist.h"

node::node()
{
	linkedChar = '\0';

	return;
}
LinkedList::LinkedList()
{
//	cout << "LinkedList constructor " << endl;

	head = NULL;

	return;
}

LinkedList::~LinkedList()
{
//	cout << "LinkedList deconstructor " << endl;

	node * current;
	node * previous;

	current = head;
	previous = head;

	while (current != NULL)
	{
//		cout << "linkedChar = " << current->linkedChar;
		previous = current;
		current->linkedChar = '\0';
		current=current->next;
		delete previous;
	}

	return;
}

void LinkedList::add(char ch)
{
	cout << "===== " << endl; 
	cout << "add 1 " << endl;
	cout << "ch = " << ch << endl;

/*	node * n;//, *current;
	n = new node;
	cout << "n = " << n << endl;
	n->linkedChar = ch;
	add (n, ch);
*/	add (head, ch);
}


void LinkedList::add(node * nodeIn, char ch)
//void LinkedList::add(char ch)
{
	cout << "===== " << endl; 
	cout << "add 2 " << endl;
	cout << "ch = " << ch << endl;

	node * n;//, *current;
	node * current;
//	node * after;
//	node * previous;

	n = new node;
//	n->linkedChar = new char[MAXSTRING + 1];
	n->linkedChar = ch;
//	cout << "linkedChar = " << n->linkedChar << endl;

//	n = nodeIn;
//	previous = nodeIn;
	current = nodeIn;
//	after = nodeIn->next;
//	current = nodeIn->next;
//	current = NULL;
//	cout << "n = " << n << endl;
//	cout << "current = " << current << endl;
//	cout << "after = " << after << endl;
//	cout << "previous = " << previous << endl;

//	cout << "check " << endl;

	if (head == NULL)
	{
		cout << "creating list " << endl;
//		n = new node;
//		current = NULL;
//		cout << "n = " << n << endl;

/*		n->linkedChar = new char[MAXSTRING + 1];
		n->linkedChar[0] = ch;
		cout << "linkedChar = " << n->linkedChar[0] << endl;

*/ 		head = n;		
//		head = previous;
		head->next = NULL;
	}
	else if (n->linkedChar < head->linkedChar)
//	else if (n->linkedChar < head->linkedChar)
//`	else if (n < head)
	{
		cout << "new head " << endl;

		n->next = head;
		head = n; 
	}
	else if (current->next == NULL)
//	else if (current == NULL)
	{
		cout << "end " << endl;
		current->next = n;	
//		previous->next = n;	
		n->next = NULL;
	}
	else if (n->linkedChar < current->linkedChar) 
	{
		cout << "n < current " << endl;
//		previous->next = n;
		n->next = current;
	}
	else
	{
		cout << "next " << endl;
		delete n;
//
//		previous = current;
		current = current->next;
		
		add (current, ch);
	}

	return;
}

bool LinkedList::del(char ch)
//void LinkedList::del(char ch)
{
	cout << "===== " << endl; 
	cout << "delete 1" << endl;
	cout << "ch = " << ch << endl;

	del(head, ch);

	return 0;
}

bool LinkedList::del(node * nodeIn, char ch)
{
	cout << "===== " << endl; 
	cout << "delete 2" << endl;
	cout << "ch = " << ch << endl;

	node * current;
//	node * next;
	node * previous;
//	current = nodeIn;
	previous = nodeIn;
	current = nodeIn->next;
//	next = nodeIn->next;
//	current = NULL;
//	previous = NULL;
//	previous = NULL;
//	cout << "linkedChar = " << current->linkedChar << endl;

	bool chFound = false;

//	cout << "checking " << endl;
//	int i = 0;	
//	for (int i = 0; i++) 
//	if (ch == head->linkedChar[i])
	if (ch == head->linkedChar)
	{
//		cout << "head deleted " << endl;
		current = head;
		head = current->next;
		current->linkedChar = '\0';
		delete current;
		chFound = true; 
	}
	else
	{
//		cout << "after head " << endl;
//		current = head;
//		previous = head;

//		while (current != NULL)
//		{
//			cout << "current = " << current << endl;

//			if (ch == current->linkedChar[i])
			if (current == NULL)
			{
				chFound = false;
			}
//			else if (ch == next->linkedChar)
			else if (ch == current->linkedChar)
			{
//				cout << ch << " deleted " << endl;
				previous->next = current->next;
//				current->next = next->next;
				current->linkedChar = '\0';
//				delete next;
				delete current;
				chFound = true;

//				break;
			}
			else
			{
//				cout << "del next " << endl;
//				previous = current;
//				current = current->next;
				del(current, ch);
//				del(previous, ch);
//				del(next, ch);
			}
//		}

	}

	return chFound;
}


//void LinkedList::find(char ch)
bool LinkedList::find(char ch)
{
	cout << "===== " << endl; 
	cout << "find 1 " << endl;
	cout << "ch = " << ch << endl;

	bool chFoundPass;
     	chFoundPass = false;
	cout << "chFoundPass initial= " << chFoundPass << endl;

//	chFoundPass = find(head, ch);
//	chFoundPass = find(head, chFoundPass, ch);
//	find(head, ch);

//	cout << "chFoundPass out = " << chFoundPass << endl;
	return find(head, ch);
//	return find(head, chFoundPass, ch);
//	return chFoundPass;
//	return 1;
//	return 0;
}

//bool LinkedList::find(node * nodeIn, bool chFoundPass, char& ch)
//void LinkedList::find(node * nodeIn, char& ch)
bool LinkedList::find(node * nodeIn, char& ch)
//bool LinkedList::find(char& ch)
{
	cout << "===== " << endl; 
	cout << "find 2 " << endl;
	cout << "ch = " << ch << endl;
//	cout << "chFoundPass in = " << endl;

	node * current;
	current = nodeIn;
//	current = head;
//	cout << "current = " << current << endl;
//	cout << "linkedCh = " << current->linkedChar << endl;

//	bool chFoundPass = false;
	bool chFound;
     	chFound = false;
//     	chFound = chFoundPass;
//	cout << "chFound in = " << chFound << endl;

//	cout << "linkedCh = " << current->linkedChar << endl;
		
	if (current == NULL)
	{
		cout << "not found" << endl;

//		cout << "did not find " << ch << endl;
//		chFoundPass = false;
		chFound = false;

//		break;

//		return chFound;
//		return false;
	}
	else if (current->linkedChar == ch)
//	if (current->linkedChar == ch && current != NULL)
	{
		cout << "***found*** " << endl;
//		chFoundPass = true;
		chFound = true;

//		cout << "found " << ch << endl;

//		break;

//		return chFound;
//		return true;
	}
//	else if (current->linkedChar != ch)		
//	else if (current != NULL)
//	else if (current->next != NULL)
	else
	{
		cout << "next " << endl;

//		current = current->next;

//		find(current->next, chFound, ch);
//		find(current->next, chFoundPass, ch);
//		find(current, chFound, ch);
		find(current->next, ch);
	}
//	else


	cout << "check " << endl;
//	}

//	cout << "chFoundPass = " << chFoundPass << endl;
	cout << "chFound out = " << chFound << endl;
		
//	return true;
//	return chFoundPass;
	return chFound;
//	return 0;
//	return -1;
//	return;

/*	if (chFound == true)
		return true;
	else
		return false;
*/}

void LinkedList::print()
{
//	cout << "===== " << endl;
//	cout << "print 1 " << endl;

	print(head);
	return;
}

void LinkedList::print(node * nodeIn)
{
//	cout << "===== " << endl;
//	cout << "print 2 " << endl;

	node * current;
	current = nodeIn;
//	current = head;
//	cout << "current = " << current << endl;

	if (current != NULL)
//	while (current != NULL)
	{
//		cout << "ch = " << current->linkedChar << endl;
		cout << current->linkedChar;

//		current = current->next;

		print(current->next);
	}
	else
/*	{
//		print()
		return;
	}
*/		cout << "\n";// << endl;
	return;
}
