#include "a04.h"

using namespace std;

order_tracker::order_tracker() // Default constructor
{
//	cout << "order_tracker default constructor" << endl;
	current_tab = 0;
//	cout << "current_tab = " << current_tab << endl;
	tab_num = 0;
//	cout << "tab_num = " << tab_num << endl;

	for(int i = 0; i < MAX_TAB; i++)
	{
		tab_number[i].famous_qty = 0;
		tab_number[i].kahuna_qty = 0;
		tab_number[i].royal_qty = 0;
		tab_number[i].fry_qty = 0;
		tab_number[i].shake_qty = 0;
		tab_number[i].soda_qty = 0;
		tab_number[i].tab_ttl = 0.0;
		tab_number[i].order_name = NULL;
		tab_number[i].order_name = NULL;
//		tab_number[i].order_note = '\0';
//		tab_number[i].order_note = '\0';

//		cout << "i = " << i << endl;
//		cout << tab_number[i].famous_qty << "," << tab_number[i].kahuna_qty << "," << tab_number[i].royal_qty << "," << tab_number[i].fry_qty << "," << tab_number[i].shake_qty << "," << tab_number[i].soda_qty << endl;// << "," << tab_number[i].order_name << "," << tab_number[i].order_note << endl;

	} // Closes for loop

}

order_tracker::~order_tracker() // Deconstuctor
{
//	cout << "order_tracker deconstructor" << endl;
	for(int i = 0; i < current_tab; i++)
	{
//		cout << "order_name = " << tab_number[i].order_name << endl;
		delete[] tab_number[i].order_name;
//		cout << "order_name = " << tab_number[i].order_name << endl;

//		cout << "order_note = " << tab_number[i].order_note << endl;
		delete[] tab_number[i].order_note;
//		cout << "order_note = " << tab_number[i].order_note << endl;

	} // Closes for loop
}

//int order_tracker::current_tab = 0; // current_tab static definition
//int order_tracker::tab_num = 0; // current_tab static definition
//menu_items order_tracker::tab_number[MAX_TAB]; // tab_number static definition

void order_tracker::loadtab()
{
	char charEat = '\0';
	char temp_string[STRING_SIZE] = {'\0'};
	char user_selection = 0;
	double sales_total = 0.0;
	ifstream inFile; 
	int i = 0; 
	int primer = 0;
	int string_size = 0;

//	cout << "loadtab loaded\n" << endl;

	cout << "What file would you like to read and write orders to?: "; 

	cin.getline(file_name, STRING_SIZE);
//	cout << "file_name = " << file_name << endl;

	inFile.open(file_name);

	inFile.peek(); // Fix for loading empty files

	while (!inFile.fail() && !inFile.eof() && i < MAX_TAB)
	{
//		cout << "i = " << i << endl;

		if (inFile.eof())
			break;

		inFile >> tab_number[i].famous_qty; 
		inFile >> charEat; // Fix for comma input
		inFile >> tab_number[i].kahuna_qty; 
		inFile >> charEat; // Fix for comma input
		inFile >> tab_number[i].royal_qty; 
		inFile >> charEat; // Fix for comma input
		inFile >> tab_number[i].fry_qty; 
		inFile >> charEat; // Fix for comma input
		inFile >> tab_number[i].shake_qty;
		inFile >> charEat; // Fix for comma input
		inFile >> tab_number[i].soda_qty; 
		inFile >> charEat; // Fix for comma input

		inFile.getline(temp_string, STRING_SIZE, ',');
		string_size = strlen(temp_string);
		tab_number[i].order_name = new char[string_size + 1];
		strncpy(tab_number[i].order_name, temp_string, string_size);
		tab_number[i].order_name[string_size] = '\0'; 
		string_size = 0;

		inFile.getline(temp_string, STRING_SIZE/*, '\n'*/);
		string_size = strlen(temp_string);
		tab_number[i].order_note = new char[string_size + 1];
		strncpy(tab_number[i].order_note, temp_string, string_size);
		tab_number[i].order_note[string_size] = '\0'; 
		string_size = 0;

		inFile.peek(); // Sets eof flag, fix for extra loop 

		tab_number[i].tab_ttl = (tab_number[i].famous_qty * FAMOUS_COST) + (tab_number[i].kahuna_qty * KAHUNA_COST) + (tab_number[i].royal_qty * ROYAL_COST) + (tab_number[i].fry_qty * FRY_COST) + (tab_number[i].shake_qty * SHAKE_COST) + (tab_number[i].soda_qty * SODA_COST); 

//		cout << tab_number[i].famous_qty << "," << tab_number[i].kahuna_qty << "," << tab_number[i].royal_qty << "," << tab_number[i].fry_qty << "," << tab_number[i].shake_qty << "," << tab_number[i].soda_qty << "," << tab_number[i].order_name << "," << tab_number[i].order_note << endl;

	 	current_tab++;
//		cout << "current_tab = " << current_tab << endl; 

		i++;
	}
/*
	current_tab--; // Temp fix

	if (current_tab < 0) // Temp fix
	{
		current_tab = 0;
	}

	cout << "current_tab = " << current_tab << endl;
*/
//	inFile.clear(); // Clears error state 
	inFile.close();

	cout << "\nSuccessfully loaded " << current_tab << " orders from " << file_name << ". \n" << endl;

	return;
}

void order_tracker::newtab()
{
//	cout << "newtab working" << endl;
//	cout << "current_tab = " << current_tab << endl;

	int user_qty = 0;
	int string_size = 0;
	char temp_string[STRING_SIZE] = {'\0'};

	if (current_tab < MAX_TAB)
	{
		cout << "Entering order #" << current_tab + 1 << endl;
		
		cout << "What is customer's name?: ";

		cin.ignore();
		cin.getline (temp_string, STRING_SIZE); 	
//		cin.getline (tab_number[current_tab].order_name, STRING_SIZE); 	
//		cout << "temp_string = " << temp_string << endl;
		string_size = strlen(temp_string);
//		cout << "string_size = " << string_size << endl;
		tab_number[current_tab].order_name = new char[string_size +1];
		strncpy(tab_number[current_tab].order_name, temp_string, string_size);
//		cout << "order_name = " << tab_number[current_tab].order_name << endl;
		tab_number[current_tab].order_name[string_size] = '\0'; 
//		cout << "order_name = " << tab_number[current_tab].order_name << endl;
		string_size = 0;
//		tab_number[current_tab].order_name = '\0';	

//		cout << tab_number[current_tab].order_name << endl;

		cout << fixed << showpoint << setprecision(2); 
		cout << "Famous burgers are $" << FAMOUS_COST << " each. How many would you like?: "; //&& 
		while (!(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].famous_qty = user_qty;
// 		cout << "famous_qty = " << tab_number[current_tab].famous_qty << endl;
		user_qty = 0;

		cout << fixed << showpoint << setprecision(2); 
		cout << "Big Kahuna burgers are $" << KAHUNA_COST << " each. How many would you like?: ";// && 
		while (!(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].kahuna_qty = user_qty;
// 		cout << "kahuna_qty = " << tab_number[current_tab].kahuna_qty << endl;
		user_qty = 0;

		cout << fixed << showpoint << setprecision(2); 
		cout << "Royal burgers are $" << ROYAL_COST << " each. How many would you like?: "; //&& 
		while (!(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].royal_qty = user_qty;
// 		cout << "royal_qty = " << tab_number[current_tab].royal_qty << endl;
		user_qty = 0;

		cout << fixed << showpoint << setprecision(2); 
		cout << "Fries are $" << FRY_COST << " each. How many would you like?: "; //&& 
		while (!(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].fry_qty = user_qty;
// 		cout << "fry_qty = " << tab_number[current_tab].fry_qty << endl;
		user_qty = 0;

		cout << fixed << showpoint << setprecision(2); 
		cout << "Shakes are $" << SHAKE_COST << " each. How many would you like?: "; //&& 
		while (!(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].shake_qty = user_qty;
// 		cout << "shake_qty = " << tab_number[current_tab].shake_qty << endl;
		user_qty = 0;

		cout << fixed << showpoint << setprecision(2); 
		cout << "Sodas are $" << SODA_COST << " each. How many would you like?: "; //&& 
		while (!(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].soda_qty = user_qty;
// 		cout << "soda_qty = " << tab_number[current_tab].soda_qty << endl;
		user_qty = 0;

		cout << "Any special requests for the order?: ";
		cin.ignore();
		cin.getline (temp_string, STRING_SIZE); 	
//		cin.getline (tab_number[current_tab].order_note, STRING_SIZE); 	
//		cout << "temp_string = " << temp_string << endl;
		string_size = strlen(temp_string);
//		cout << "string_size = " << string_size << endl;
		tab_number[current_tab].order_note = new char[string_size +1];
		strncpy(tab_number[current_tab].order_note, temp_string, string_size);
//		cout << "order_note = " << tab_number[current_tab].order_note << endl;
		tab_number[current_tab].order_note[string_size] = '\0'; 
//		cout << "order_note = " << tab_number[current_tab].order_note << endl;
		string_size = 0;
//		tab_number[current_tab].order_note = '\0';	

//		cout << tab_number[current_tab].order_note << endl;

		tab_number[current_tab].tab_ttl = (tab_number[current_tab].famous_qty * FAMOUS_COST) + (tab_number[current_tab].kahuna_qty * KAHUNA_COST) + (tab_number[current_tab].royal_qty * ROYAL_COST) + (tab_number[current_tab].fry_qty * FRY_COST) + (tab_number[current_tab].shake_qty * SHAKE_COST) + (tab_number[current_tab].soda_qty * SODA_COST); 
// 		cout << "tab_ttl = " << tab_number[current_tab].tab_ttl << endl;

		cout << "\nThank you for your order ";  
		cout << tab_number[current_tab].order_name << ". \n" << endl;

		viewtab(current_tab);

		current_tab++;
		return/* current_tab*/;

	} // closes do while

	else if (current_tab >= MAX_TAB)
	{
		cout << "You have entered the maximum amount of orders for the day, please exit the program to clear memory and start over... " << endl;

		return/* current_tab*/;
	}

	return;
} // closes newtab

void order_tracker::searchtab()
{
//	cout << "searchtab working" << endl;

	int user_tab = 0;
	char search_name[STRING_SIZE];
	bool match_found = false;
	
	if (current_tab <= 0)
	{
		cout << "There are not any orders yet, enter an order before viewing...\n" << endl;
		return;
	}

	cout << "Searching orders by name, please enter the name: ";
	cin.ignore();
	cin.getline(search_name, STRING_SIZE);
//	cout << "search_name = " << search_name << endl;

	for (int i = 0; i < current_tab; i++)
	{
//		cout << "i = " << i << endl;
//		cout << "order_name = " << tab_number[i].order_name << endl;

		while (strcmp (search_name, tab_number[i].order_name) == 0)
		{
//			cout << "Match found!" << endl;
			match_found = true;
			tab_num = i;
			break;
		}
	}

	if (match_found == true)
	{			
		match_found = false;
		cout << "\nHere is the order for " << search_name << "\n" << endl; 
		viewtab(tab_num);
	}
	else if (match_found != true)
	{
	cout << "\nNo match for " << search_name << endl;

	return;
	}

/*	cout << "There have been " << current_tab << " orders today, what tab would you like to view? ";
	cin >> user_tab;

	if (user_tab > current_tab || user_tab <= 0) 
	{
		cout << user_tab << " is not a valid choice, returing to menu...\n" << endl;
	}
	else
	{
		cout << "\nHere is information for order #" << user_tab  << ".\n" << endl;
		
		tab_num = user_tab - 1;

		viewtab(tab_num);
//		order_tracker.viewtab(current_tab);
	}
*/
	return;
} // closes searchtab

void order_tracker::totaltab()
{
//	cout << "totaltab working" << endl;

	int i = 0; 
	double sales_total = 0.0;
//	char file_name[STRING_SIZE];
	char user_selection = 0;
	ofstream outFile; 

	cout << "Would you like to save todays data to " << file_name << "? (Y)es to save: " ;
	cin.ignore();
	cin.get(user_selection);
//	cout << "user_selection = " << user_selection << endl;

	if (user_selection == 'y' || user_selection == 'Y')
	{
//		cout << "Enter the name of the file to save: ";
//		cin.ignore();
//		cin.getline(file_name, STRING_SIZE);
//		cout << "file_name = " << file_name << endl;
		outFile.open(file_name);

		for(int i = 0; i < current_tab; i++)
		{
//			cout << "i = " << i << endl;

			outFile << tab_number[i].famous_qty << "," << tab_number[i].kahuna_qty << "," << tab_number[i].royal_qty << ","; 
			outFile << tab_number[i].fry_qty << "," << tab_number[i].shake_qty << "," << tab_number[i].soda_qty << ","; 
			outFile << tab_number[i].order_name << "," << tab_number[i].order_note << endl;
		}
	}
/*
	else if (user_selection == 'n' || user_selection == 'N')
	{
		cout << " user chose no" << endl; 
	}
*//*	for (i = 0; i < current_tab; i++)
	{
		sales_total += tab_number[i].tab_ttl; 
	}

	cout << "There were " << current_tab << " total customer(s) today and $" << fixed << showpoint << setprecision(2) << sales_total << " dollars made total. \n" << endl;  
*/	
	outFile.close();

	return;

} // closes totaltab

void order_tracker::viewtab(int tab_num)
{
//	cout << "viewtab working" << endl;
	cout << "Customer Name: " << tab_number[tab_num].order_name << endl;
//	cout << "kahuna_qty = " << tab_number[tab_num].kahuna_qty << endl;

	if (tab_number[tab_num].famous_qty == 1)
	{
		cout << tab_number[tab_num].famous_qty << " Famous burger at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << FAMOUS_COST << ", charge = $" << tab_number[tab_num].famous_qty * FAMOUS_COST << endl;

	}

	else if (tab_number[tab_num].famous_qty > 1)
	{
		cout << tab_number[tab_num].famous_qty << " Famous burgers at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << FAMOUS_COST << ", charge = $" << tab_number[tab_num].famous_qty * FAMOUS_COST << endl;
	}

	if (tab_number[tab_num].kahuna_qty == 1)
	{
		cout << tab_number[tab_num].kahuna_qty << " Big Kahuna burger at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << KAHUNA_COST << ", charge = $" << tab_number[tab_num].kahuna_qty * KAHUNA_COST << endl;
	}

   	else if (tab_number[tab_num].kahuna_qty > 1)
	{
		cout << tab_number[tab_num].kahuna_qty << " Big Kahuna burgers at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << KAHUNA_COST << ", charge = $" << tab_number[tab_num].kahuna_qty * KAHUNA_COST << endl;
	}

	if (tab_number[tab_num].royal_qty == 1)
	{
		cout << tab_number[tab_num].royal_qty << " Royal burger at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << ROYAL_COST << ", charge = $" << tab_number[tab_num].royal_qty * ROYAL_COST << endl;
	}

	else if (tab_number[tab_num].royal_qty > 1)
	{
		cout << tab_number[tab_num].royal_qty << " Royal burgers at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << ROYAL_COST << ", charge = $" << tab_number[tab_num].royal_qty * ROYAL_COST << endl;
	}

	if (tab_number[tab_num].fry_qty == 1)
	{
		cout << tab_number[tab_num].fry_qty << " fry at $"; 
		cout << fixed << showpoint << setprecision(2);
		cout << FRY_COST << ", charge = $" << tab_number[tab_num].fry_qty * FRY_COST << endl;
	}

	else if (tab_number[tab_num].fry_qty > 1)
	{
		cout << tab_number[tab_num].fry_qty << " fries at $";
		cout << fixed << showpoint << setprecision(2);
		cout << FRY_COST << ", charge = $" << tab_number[tab_num].fry_qty * FRY_COST << endl;
	}

	if (tab_number[tab_num].shake_qty == 1)
	{
		cout << tab_number[tab_num].shake_qty << " shake at $"; 
		cout << fixed << showpoint << setprecision(2);
	       	cout << SHAKE_COST << ", charge = $" << tab_number[tab_num].shake_qty * SHAKE_COST << endl;
	}

	else if (tab_number[tab_num].shake_qty > 1)
	{
		cout << tab_number[tab_num].shake_qty << " shakes at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << SHAKE_COST << ", charge = $" << tab_number[tab_num].shake_qty * SHAKE_COST << endl;
	}

	if (tab_number[tab_num].soda_qty == 1)
	{
		cout << tab_number[tab_num].soda_qty << " soda at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << SODA_COST << ", charge = $" << tab_number[tab_num].soda_qty * SODA_COST << endl;
	}

	else if (tab_number[tab_num].soda_qty > 1)
	{
		cout << tab_number[tab_num].soda_qty << " sodas at $"; 
		cout << fixed << showpoint << setprecision(2); 
		cout << SODA_COST << ", charge = $" << tab_number[tab_num].soda_qty * SODA_COST << endl;
	}

	cout << fixed << showpoint << setprecision(2); 
	cout << "\nTotal charge = $" << tab_number[tab_num].tab_ttl << "\n" << endl;

	cout << "Order Notes: " <<  tab_number[tab_num].order_note << endl;

	return;

} // closes viewtab
