#include "a02.h"

using namespace std;

int main ()
{
	order_tracker todays_orders;
//	int order_tracker::current_tab = 0;
//	todays_orders.current_tab = 0;
//	cout << "current_tab constuctor return = " << todays_orders.current_tab << endl;

	char user_choice = 0;
//	int current_tab = 0;
//	menu_items tab_number [100];

	cout << "Welcome to Jackrabbit Slims' Burgers and Fries! \n" << endl;
	
	while (user_choice != 'q')
	{	
		cout << "What would you like to do: (e)nter a new tab, (v)iew previous tab, or (q)uit? ";
		cin >> user_choice; 
		cout << "\n";

		if (user_choice == 'e')
		{
			todays_orders.newtab();
//			todays_orders.current_tab = todays_orders.newtab(todays_orders.tab_number, todays_orders.current_tab);
//			cout << "current_tab return = " << todays_orders.current_tab << endl;
//			current_tab = newtab(tab_number, current_tab);
		}
		else if (user_choice == 'v')
		{
			todays_orders.searchtab();
//			viewtab(tab_number, current_tab);
		}
		else if (user_choice == 'q')
		{
			todays_orders.totaltab();
//			totaltab(tab_number, current_tab);
		}
		else 
		{
			cout << "You did not enter a valid selection, try again... \n" << endl;
		}

		cout << "===== \n" << endl;

	} // closes menu

	return 0;

} // closes main
