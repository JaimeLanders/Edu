#include "a02.h"

using namespace std;

order_tracker::order_tracker()
{
//	cout << "order_tracker default constructor" << endl;
	int current_tab = 0;
	int tab_num = 0;
//	cout << "current_tab = " << /*order_tracker.*/current_tab << endl;
}
/*
int Orders::~Orders()
{
//	cout << "order_tracker deconstructor" << endl;
	int current_tab = 0;
//	cout << "current_tab = " << *//*order_tracker.*//*current_tab << endl;
}
*/

int order_tracker::current_tab = 0; // current_tab definition
int order_tracker::tab_num = 0; // current_tab definition
menu_items order_tracker::tab_number[MAX_TAB]; // tab_number definition

void order_tracker::newtab()
{
//	cout << "newtab working" << endl;
//	cout << "current_tab = " << current_tab << endl;

	int user_qty = 0;

	if (current_tab < MAX_TAB)
	{
		cout << "Entering order #" << current_tab + 1 << endl;
		
		cout << "What is customer's name? " << endl;

		cin.getline (tab_number[current_tab].order_name, STRING_SIZE); 	
		cin.getline (tab_number[current_tab].order_name, STRING_SIZE); // Temporary fix  	

//		cout << tab_number[current_tab].order_name << endl;

		while (cout << fixed << showpoint << setprecision(2) << "Big Kahuna burgers are $" << KAHUNA_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].kahuna_qty = user_qty;
// 		cout << "kahuna_qty = " << tab_number[current_tab].kahuna_qty << endl;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Famous burgers are $" << FAMOUS_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].famous_qty = user_qty;
// 		cout << "famous_qty = " << tab_number[current_tab].famous_qty << endl;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Royal burgers are $" << ROYAL_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].royal_qty = user_qty;
// 		cout << "royal_qty = " << tab_number[current_tab].royal_qty << endl;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Fries are $" << FRY_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].fry_qty = user_qty;
// 		cout << "fry_qty = " << tab_number[current_tab].fry_qty << endl;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Shakes are $" << SHAKE_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].shake_qty = user_qty;
// 		cout << "shake_qty = " << tab_number[current_tab].shake_qty << endl;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Sodas are $" << SODA_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].soda_qty = user_qty;
// 		cout << "soda_qty = " << tab_number[current_tab].soda_qty << endl;
		user_qty = 0;

		cout << "Any special requests for the order?" << endl;
		cin.getline (tab_number[current_tab].order_note, STRING_SIZE); 	
		cin.getline (tab_number[current_tab].order_note, STRING_SIZE); // Temporary fix  	

//		cout << tab_number[current_tab].order_note << endl;

		tab_number[current_tab].tab_ttl = (tab_number[current_tab].famous_qty * FAMOUS_COST) + (tab_number[current_tab].kahuna_qty * KAHUNA_COST) + (tab_number[current_tab].royal_qty * ROYAL_COST) + (tab_number[current_tab].fry_qty * FRY_COST) + (tab_number[current_tab].shake_qty * SHAKE_COST) + (tab_number[current_tab].soda_qty * SODA_COST); 
// 		cout << "tab_ttl = " << tab_number[current_tab].tab_ttl << endl;

		cout << "\nThank you for your order ";  
		cout << tab_number[current_tab].order_name << "." << endl;

		viewtab(current_tab);

		current_tab++;
		return/* current_tab*/;

	} // closes do while

	else if (current_tab >= MAX_TAB)
	{
		cout << "You have entered the maximum amount of orders for the day, please exit the program to clear memory and start over... " << endl;

		return/* current_tab*/;
	}

//	current_tab++;
	return /*current_tab*/;
} // closes newtab

void order_tracker::searchtab()
//void order_tracker::viewtab(menu_items tab_number[MAX_TAB], int current_tab)
//void order_tracker::viewtab(menu_items tab_number[100], int current_tab)
{
//	cout << "searchtab working" << endl;

//	int search_tab = 0; // Temp fix for viewtab
	int user_tab = 0;
	
	if (current_tab <= 0)
	{
		cout << "There are not any orders yet, enter an order before viewing...\n" << endl;
		return;
	}
	cout << "There have been " << current_tab << " orders today, what tab would you like to view? ";
	cin >> user_tab;

	if (user_tab > current_tab || user_tab <= 0) 
	{
		cout << user_tab << " is not a valid choice, returing to menu...\n" << endl;
	}
	else
	{
		cout << "\nHere is information for order #" << user_tab  << ".\n" << endl;
		
		tab_num = user_tab - 1;

		viewtab(tab_num);
//		order_tracker.viewtab(current_tab);
	}
}

void order_tracker::totaltab()
{
	cout << "totaltab working" << endl;
/*
	int i = 0; 
	double sales_total = 0.0;

	for (i = 0; i < current_tab; i++)
	{
		sales_total += tab_number[i].tab_ttl; 
	}

	cout << "There were " << current_tab << " total customer(s) today and $" << fixed << showpoint << setprecision(2) << sales_total << " dollars made total. \n" << endl;  
	
	return;
*/
} // closes totaltab

void order_tracker::viewtab(int tab_num)
{
//	cout << "viewtab working" << endl;

//	cout << "\nHere is information for order #" << tab_num + 1 << "." << endl;

	cout << "Customer Name: " << tab_number[tab_num].order_name << endl;
/*
	if (tab_number[tab_num].kahuna_qty = 1)
	{
		cout << tab_number[tab_num].royal_qty << " Big Kahuna burger at $" << fixed << showpoint << setprecision(2) << KAHUNA_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].kahuna_qty * KAHUNA_COST << endl;
	}
*/
//	if (tab_number[tab_num].kahuna_qty > 1)
	if (tab_number[tab_num].kahuna_qty > 0)
	{
		cout << tab_number[tab_num].kahuna_qty << " Big Kahuna burgers at $" << fixed << showpoint << setprecision(2) << KAHUNA_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].kahuna_qty * KAHUNA_COST << endl;
	}
/*
	if (tab_number[tab_num].famous_qty = 1)
	{
		cout << tab_number[tab_num].famous_qty << " Famous burger at $" << fixed << showpoint << setprecision(2) << FAMOUS_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].famous_qty * FAMOUS_COST << endl;
	}
*/
//	if (tab_number[tab_num].famous_qty > 1)
	if (tab_number[tab_num].famous_qty > 0)
	{
		cout << tab_number[tab_num].famous_qty << " Famous burgers at $" << fixed << showpoint << setprecision(2) << FAMOUS_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].famous_qty * FAMOUS_COST << endl;
	}

/*
	if (tab_number[tab_num].royal_qty = 1)
	{
		cout << tab_number[tab_num].royal_qty << " Royal burger at $" << fixed << showpoint << setprecision(2) << ROYAL_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].royal_qty * ROYAL_COST << endl;
	}
*/
//	if (tab_number[tab_num].royal_qty > 1)
	if (tab_number[tab_num].royal_qty > 0)
	{
		cout << tab_number[tab_num].royal_qty << " Royal burgers at $" << fixed << showpoint << setprecision(2) << ROYAL_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].royal_qty * ROYAL_COST << endl;
	}
/*
	if (tab_number[tab_num].fry_qty = 1)
	{
		cout << tab_number[tab_num].fry_qty << fixed << showpoint << setprecision(2) << " fry at $" << FRY_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].fry_qty * FRY_COST << endl;
	}
*/
//	if (tab_number[tab_num].fry_qty > 1)
	if (tab_number[tab_num].fry_qty > 0)
	{
		cout << tab_number[tab_num].fry_qty << fixed << showpoint << setprecision(2) << " fries at $" << FRY_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].fry_qty * FRY_COST << endl;
	}
/*
	if (tab_number[tab_num].shake_qty = 1)
	{
		cout << tab_number[tab_num].shake_qty << " shake at $" << fixed << showpoint << setprecision(2) << SHAKE_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].shake_qty * SHAKE_COST << endl;
	}
*/
//	if (tab_number[tab_num].shake_qty > 1)
	if (tab_number[tab_num].shake_qty > 0)
	{
		cout << tab_number[tab_num].shake_qty << " shakes at $" << fixed << showpoint << setprecision(2) << SHAKE_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].shake_qty * SHAKE_COST << endl;
	}
/*
	if (tab_number[tab_num].soda_qty = 1)
	{
		cout << tab_number[tab_num].soda_qty << " soda at $" << fixed << showpoint << setprecision(2) << SODA_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].soda_qty * SODA_COST << endl;
	}
*/
//	if (tab_number[tab_num].soda_qty > 1)
	if (tab_number[tab_num].soda_qty > 0)
	{
		cout << tab_number[tab_num].soda_qty << " sodas at $" << fixed << showpoint << setprecision(2) << SODA_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[tab_num].soda_qty * SODA_COST << endl;
	}

	cout << fixed << showpoint << setprecision(2) << "Total charge = $" << tab_number[tab_num].tab_ttl << "\n" << endl;

	cout << "Order Notes: " <<  tab_number[tab_num].order_note << endl;

	return;

} // closes viewtab
