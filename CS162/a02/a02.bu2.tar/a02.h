/*
Name: Jaime Landers
Class: CS162
Assignement: 1
Date Started: 6/24/16 
Sources: http://www.isocpp.org for input failure guard on newtab function.  

TODO
1) Get functions working inside classes X
2) Add additional burgers  
3) Add names and  notes to orders X
4) Don't add 0 total items to bills
5) Correct singular/plural wording
6) Search order by name instead of number 
7) Output CSV file on exit

*/
//#pragma once

#include <iomanip>
#include <iostream>

const double FAMOUS_COST = 11.75;
const double KAHUNA_COST = 12.50;
const double ROYAL_COST = 9.25;
const double FRY_COST = 3.49;
const double SHAKE_COST = 5.65;
const double SODA_COST = 2.99;
const int MAX_TAB = 100;
const int STRING_SIZE = 100;

struct menu_items
{
	int famous_qty;
	int kahuna_qty;
	int royal_qty;
	int fry_qty;
	int shake_qty; 
	int soda_qty;
	double tab_ttl;
	char order_name[STRING_SIZE];
	char order_note[STRING_SIZE];
};

class order_tracker
{
private:
//	static int current_tab; 
//	static menu_items tab_number[MAX_TAB]; 
public:
	static int current_tab; 
	static int tab_num; 
	static menu_items tab_number[MAX_TAB]; 
	void newtab();
	void searchtab();
	void totaltab();
	void viewtab(int);
	order_tracker();
//	~Orders();
};

//order_tracker todays_orders;

//int order_tracker::current_tab;
//int order_tracker::tab_number[MAX_TAB] = 0;

/*
int newtab (menu_items[], int);
int totaltab (menu_items[], int);
int viewtab (menu_items[], int);
*/
