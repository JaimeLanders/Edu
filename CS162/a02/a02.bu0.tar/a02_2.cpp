#include "a02.h"

using namespace std;

order_tracker::order_tracker()
{
	cout << "Orders default constructor" << endl;
	int current_tab = 0;
/*	int famous_qty = 0;
	int kahuna_qty = 0;
	int royal_qty = 0;
	int fry_qty = 0;
	int shake_qty = 0;
	int soda_qty = 0;
*/
}
/*
int Orders::~Orders()
{
	cout << "Orders default constructor" << endl;
*//*	int famous_qty = 0;
	int kahuna_qty = 0;
	int royal_qty = 0;
	int fry_qty = 0;
	int shake_qty = 0;
	int soda_qty = 0;
*//*
}
*/
int order_tracker::newtab()
//int newtab (menu_items tab_number[100], int current_tab)
{
	cout << "newtab working" << endl;
/*
	int user_qty = 0;

	if (current_tab < MAX_TAB)
	{
		cout << "Entering order #" << current_tab + 1 << endl;

		while (cout << fixed << showpoint << setprecision(2) << "Royal burgers are $" << ROYAL_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].royal_qty = user_qty;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Fries are $" << FRY_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].fry_qty = user_qty;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Shakes are $" << SHAKE_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].shake_qty = user_qty;
		user_qty = 0;

		while (cout << fixed << showpoint << setprecision(2) << "Sodas are $" << SODA_COST << " each. How many would you like?: " && !(cin >> user_qty) || user_qty < 0)
		{
			cout << "You did not enter a valid number, try again... \n" << endl;
			cin.clear();
			cin.ignore(200, '\n');
		}
 		tab_number[current_tab].soda_qty = user_qty;
		user_qty = 0;

		tab_number[current_tab].tab_ttl = (tab_number[current_tab].royal_qty * ROYAL_COST) + (tab_number[current_tab].fry_qty * FRY_COST) + (tab_number[current_tab].shake_qty * SHAKE_COST) + (tab_number[current_tab].soda_qty * SODA_COST); 

		cout << "\nThank you for your order: " << endl;
		cout << tab_number[current_tab].royal_qty << " royal burgers at $" << fixed << showpoint << setprecision(2) << ROYAL_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].royal_qty * ROYAL_COST << endl;

		cout << tab_number[current_tab].fry_qty << fixed << showpoint << setprecision(2) << " fries at $" << FRY_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].fry_qty * FRY_COST << endl;

		cout << tab_number[current_tab].shake_qty << " shakes at $" << fixed << showpoint << setprecision(2) << SHAKE_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].shake_qty * SHAKE_COST << endl;

		cout << tab_number[current_tab].soda_qty << " soda at $" << fixed << showpoint << setprecision(2) << SODA_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].soda_qty * SODA_COST << endl;

		cout << fixed << showpoint << setprecision(2) << "Total charge = $" << tab_number[current_tab].tab_ttl << "\n" << endl;

		current_tab++;
		return current_tab;

	} // closes do while

	else if (current_tab >= MAX_TAB)
	{
		cout << "You have entered the maximum amount of orders for the day, please exit the program to clear memory and start over... " << endl;

		return current_tab;
	}
*/
	return 0;
} // closes newtab

void order_tracker::totaltab()
//void order_tracker::totaltab(menu_items tab_number[100], int current_tab)
{
	cout << "totaltab working" << endl;
/*
	int i = 0; 
	double sales_total = 0.0;

	for (i = 0; i < current_tab; i++)
	{
		sales_total += tab_number[i].tab_ttl; 
	}

	cout << "There were " << current_tab << " total customer(s) today and $" << fixed << showpoint << setprecision(2) << sales_total << " dollars made total. \n" << endl;  
	
	return;
*/
} // closes totaltab

void order_tracker::viewtab()
//void order_tracker::viewtab(menu_items tab_number[100], int current_tab)
{
	cout << "viewtab working" << endl;
/*
	int user_tab = 0;
	
	if (current_tab <= 0)
	{
		cout << "There are not any orders yet, enter an order before viewing...\n" << endl;
		return;
	}
	cout << "There have been " << current_tab << " orders today, what tab would you like to view? ";
	cin >> user_tab;

	if (user_tab > current_tab || user_tab <= 0) 
	{
		cout << user_tab << " is not a valid choice, returing to menu...\n" << endl;
	}
	else
	{
		current_tab = user_tab - 1;

		cout << "\nHere is information for order #" << current_tab + 1 << "." << endl;
		cout << tab_number[current_tab].royal_qty << " royal burgers at $" << fixed << showpoint << setprecision(2) << ROYAL_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].royal_qty * ROYAL_COST << endl;

		cout << tab_number[current_tab].fry_qty << " fries at $" << fixed << showpoint << setprecision(2) << FRY_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].fry_qty * FRY_COST << endl;

		cout << tab_number[current_tab].shake_qty << " shakes at $" << fixed << showpoint << setprecision(2) << SHAKE_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].shake_qty * SHAKE_COST << endl;

		cout << tab_number[current_tab].soda_qty << " soda at $" << fixed << showpoint << setprecision(2) << SODA_COST << ", ";
		cout << fixed << showpoint << setprecision(2) << "charge = $" << tab_number[current_tab].soda_qty * SODA_COST << endl;

		cout << fixed << showpoint << setprecision(2) << "Total charge = $" << tab_number[current_tab].tab_ttl << "\n" << endl;

	} // closes else

	return;
*/
} // closes viewtab
