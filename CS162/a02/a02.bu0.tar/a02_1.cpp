#include "a02.h"

using namespace std;

int main ()
{
	char user_choice = 0;
	int current_tab = 0;
//	menu_items tab_number [100];
	order_tracker todays_orders;

	cout << "Welcome to Jackrabbit Slims' Burgers and Fries! \n" << endl;
	
	while (user_choice != 'q')
	{	
		cout << "What would you like to do: (e)nter a new tab, (v)iew previous tab, or (q)uit? ";
		cin >> user_choice; 
		cout << "\n";

		if (user_choice == 'e')
		{
			todays_orders.newtab();
//			current_tab = newtab(tab_number, current_tab);
		}
		else if (user_choice == 'v')
		{
			todays_orders.viewtab();
//			viewtab(tab_number, current_tab);
		}
		else if (user_choice == 'q')
		{
			todays_orders.totaltab();
//			totaltab(tab_number, current_tab);
		}
		else 
		{
			cout << "You did not enter a valid selection, try again... \n" << endl;
		}

		cout << "===== \n" << endl;

	} // closes menu

	return 0;

} // closes main
